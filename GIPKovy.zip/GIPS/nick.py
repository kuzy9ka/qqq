import requests
from pystyle import Colors, Colorate

SOCIAL_SEARCHER_API_KEY = '9247244760ecaa017777eb6be96de598'

def social_search(query):
    try:
        url = f"https://api.social-searcher.com/v2/search?q={query}&key={SOCIAL_SEARCHER_API_KEY}"
        response = requests.get(url)
        data = response.json()
        if data.get('posts'):
            return data['posts']
        else:
            print(Colorate.Horizontal(Colors.red_to_white, "Профили не найдены."))
            return None
    except requests.RequestException as e:
        print(Colorate.Horizontal(Colors.red_to_white, f"Ошибка при поиске профилей в соцсетях: {e}"))
        return None

query = input(Colorate.Horizontal(Colors.red_to_white, "Введите запрос для поиска в социальных сетях: "))
print(Colorate.Horizontal(Colors.red_to_white, "\nПоиск профилей в социальных сетях..."))
social_data = social_search(query)
if social_data:
    for i, post in enumerate(social_data, 1):
        print(Colorate.Horizontal(Colors.red_to_white, f"\nРезультат #{i}:"))
        print(Colorate.Horizontal(Colors.red_to_white, f"Платформа: {post['network']}"))
        print(Colorate.Horizontal(Colors.red_to_white, f"Текст поста: {post['text']}"))
        print(Colorate.Horizontal(Colors.red_to_white, f"Ссылка: {post['url']}"))
else:
    print(Colorate.Horizontal(Colors.red_to_white, "Профили в социальных сетях не найдены."))