import os
import random
import pystyle
from colorama import init
from pystyle import Colors, Colorate, Center
from fake_useragent import UserAgent
from colorama import Fore, Style
import phonenumbers
from phonenumbers import parse, is_valid_number, is_possible_number, carrier, geocoder, PhoneNumberFormat, format_number
import requests
import fake_useragent
import socket
import threading
import concurrent.futures
import urllib.request
from bs4 import BeautifulSoup
import time
from urllib.parse import urljoin, urlparse
from queue import Queue

init(autoreset=True)

def clear_console():
    if os.name == 'nt':  
        os.system('cls')
    else:  
        os.system('clear')

def display_banner():
    banner = """⠀
                                           ▄██████▄  ▄█     ▄███████▄    ▄████████ 
                                          ███    ███ ███    ███    ███   ███    ███ 
                                          ███    █▀  ███▌   ███    ███   ███    █▀  
                                         ▄███        ███▌   ███    ███   ███        
                                        ▀▀███ ████▄  ███▌ ▀█████████▀  ▀███████████ 
                                          ███    ███ ███    ███                 ███ 
                                          ███    ███ ███    ███           ▄█    ███ 
                                          ████████▀  █▀    ▄████▀       ▄████████▀  
                                                                                       ⠀⠀⠀
╭────────────────────────────────────╮  ╭────────────────────────────────────╮  ╭────────────────────────────────────╮
│  1  •  User-agent generator        │  │  4  •  HLR request                 │  │  7  •  Proxy Scraper               │ 
│  2  •  Mullvad generator           │  │  5  •  Web Crawler                 │  │  8  •  Dox template                │
│  3  •  Swat banword                │  │  6  •  Port scanner                │  │  9  •  Ген троль                   │
╰────────────────────────────────────╯  ╰────────────────────────────────────╯  ╰────────────────────────────────────╯

╭────────────────────────────────────╮  ╭────────────────────────────────────╮  ╭────────────────────────────────────╮
│ 10  •  DdoS   │ 13  •  Ascii banner│  │ 16  • СНОСЕР АККАУНТА (мб работает)│  │Создатель инструмента @DoxersToolkit│ 
│ 11  •  DdoS 2 │ 14  •  Спам кодами │  │ 17  • СНОСЕР КАНАЛА (МБ ВОРК)      │  │Я не несу ответственность за ваши   │
│ 12  •  DdoS 3 │ 15  •  bomber      │  │ 18  • СНОСЕР ЧАТА (МБ ВОРК)        │  │действие СОФТ НЕ ПЛАТНЫЙ НЕ ПОКУПАТЬ│ 
╰────────────────────────────────────╯  ╰────────────────────────────────────╯  ╰────────────────────────────────────╯



⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
    """
    centered_banner = Colorate.Horizontal(Colors.green_to_white, Center.XCenter(banner))
    print(centered_banner)

def create_dox_template():
    print("Создание шаблона докса\n")

    victim = input("Введите имя жертвы: ")
    reason = input("Введите причину: ")
    phone = input("Введите номер телефона: ")
    card = input("Введите номер карты: ")
    full_name = input("Введите ФИО: ")
    passport_data = input("Введите паспортные данные: ")
    parents = input("Введите информацию о родителях: ")
    work_parents = input("Введите информацию о работе родителей: ")
    school = input("Введите школу: ")
    school_email = input("Введите почту школы: ")
    director = input("Введите имя директора школы: ")
    job = input("Введите место работы жертвы: ")

    template = f"""
    ————————————————Dox————————————————
    
    ├ Жертва: {victim} 
    ├ Причина: {reason}
    ├ Телефон: {phone}
    ├ Карта: {card}
    ├ ФИО: {full_name}
    ├ Паспортные данные: {passport_data}
    ├ Родители: {parents}
    ├ Работа родителей: {work_parents}
    ├ Школа: {school}
    ├ Почта школы: {school_email}
    ├ Директор: {director}
    ├ Работа: {job}
    └
    ———————————————————————————————————
    """

    import os
    file_count = len([f for f in os.listdir('.') if f.startswith('dox_template') and f.endswith('.txt')])
    filename = f'dox_template{file_count + 1}.txt'

    with open(filename, 'w') as file:
        file.write(template)
    
    print(template)
    print(f"\nШаблон сохранён в файл {filename}")

def port_scanner():
    print_lock = threading.Lock()

    target = input(Fore.YELLOW + "Введите IP-адрес: " + Style.RESET_ALL)
    try:
        targetIP = socket.gethostbyname(target)
    except socket.gaierror:
        print(Fore.RED + f"Не удалось разрешить IP-адрес для {target}" + Style.RESET_ALL)
        return

    n_threads = 200
    input(Fore.YELLOW + "Для продолжения нажмите ENTER  " + Style.RESET_ALL)
    ports = range(1, 9999)
    open_ports = []

    def port_scan(port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.5)
            result = sock.connect_ex((targetIP, port))
            with print_lock:
                if result == 0:
                    print(Fore.GREEN + f"[+] Порт {port} открыт" + Style.RESET_ALL)
                    open_ports.append(port)
                else:
                    print(Fore.RED + f"[-] Порт {port} закрыт" + Style.RESET_ALL)
        except:
            pass
        finally:
            sock.close()

    def scan_thread():
        while True:
            port = ports_queue.get()
            port_scan(port)
            ports_queue.task_done()

    ports_queue = Queue()

    for t in range(n_threads):
        thread = threading.Thread(target=scan_thread)
        thread.daemon = True
        thread.start()

    for port in ports:
        ports_queue.put(port)

    ports_queue.join()

    print(f"Открытые порты на {targetIP}:")
    print(open_ports)

def proxy_checker():
    def user_agents():
        ua = fake_useragent.UserAgent()
        browser_types = ['chrome', 'firefox', 'safari', 'edge']
        random_browser = random.choice(browser_types)
        random_user_agent = getattr(ua, random_browser)
        return random_user_agent

    def fetch_and_check_proxies():
        try:
            timeout = "300"
            url = "https://api.proxyscrape.com/v3/free-proxy-list/get"
            url2 = "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt"
            ip_api_url = "http://ip-api.com/json/"

            querystring = {
                "request": "displayproxies",
                "protocol": "http",
                "timeout": f"{timeout}",
            }

            random_user_agent = user_agents()
            headers = {
                "accept": "text/plain, */*; q=0.01",
                "accept-language": "en-US,en;q=0.8",
                "user-agent": random_user_agent,
            }

            socket.setdefaulttimeout(3)

            def fetch_proxies():
                proxies = []
                try:
                    response = requests.get(url, headers=headers, params=querystring)
                    response.raise_for_status()
                    proxies.extend(response.text.split("\n"))

                    response2 = requests.get(url2, headers=headers)
                    response2.raise_for_status()
                    proxies.extend(response2.text.split("\n"))

                except requests.RequestException as e:
                    print(f"Ошибка при получении прокси: {e}")
                return proxies

            def is_bad_proxy(pip):
                try:
                    proxy_handler = urllib.request.ProxyHandler({"http": pip})
                    opener = urllib.request.build_opener(proxy_handler)
                    opener.addheaders = [("User-agent", "Mozilla/5.0")]
                    urllib.request.install_opener(opener)
                    return False
                except urllib.error.HTTPError as e:
                    print("Ошибка c urllib:" + str(e))
                    return e.code
                except Exception as e:
                    print("Ошибка:" + str(e))
                    return True

            def get_country(ip):
                try:
                    response = requests.get(ip_api_url + ip)
                    response.raise_for_status()
                    data = response.json()
                    return data.get('country')
                except requests.RequestException as e:
                    print(f"Ошибка при получении информации о стране: {e}")
                    return "Unknown"

            proxies = fetch_proxies()
            print(Colors.green + "[*] Найденные прокси:", len(proxies))

            working_proxies = []
            working_count = 0

            user_limit = input("[+] Введите количество нужных вам прокси: ")
            limit = int(user_limit)

            with concurrent.futures.ThreadPoolExecutor() as executor:
                results = executor.map(
                    lambda proxy: (proxy, get_country(proxy.split(':')[0])) if not is_bad_proxy(proxy) else (
                        None, None), proxies)
                for result, country in results:
                    if result:
                        ip_port = result.strip()
                        print(Colors.green + f"Рабочий прокси: {ip_port}, Страна: {country}")
                        working_proxies.append(ip_port + "\n")
                        working_count += 1
                        if working_count >= limit:
                            input(Colors.white + "[$] Нажмите Enter, чтобы завершить...")
                            exit(0)

        except EOFError:
            pass
        except Exception as e:
            print(Colors.red + "Ошибка отправки:", e)

    fetch_and_check_proxies()

def generate_user_agent():
    ua = UserAgent()
    user_agent = ua.random
    return user_agent  

def generate_mullvad_key():
    mullvad_key = ''.join([str(random.randint(0, 9)) for _ in range(16)])
    return mullvad_key        


def phoneinfo(phone):
    try:
        parsed_phone = parse(phone, None)
        if not is_valid_number(parsed_phone):
            print(f"\n{Fore.BLUE}[!] Произошла ошибка -> {Fore.WHITE}Недействительный номер телефона\n")
            return
        carrier_info = carrier.name_for_number(parsed_phone, 'en')
        country = geocoder.description_for_number(parsed_phone, 'en')
        region = geocoder.description_for_number(parsed_phone, 'ru')
        formatted_number = format_number(parsed_phone, PhoneNumberFormat.INTERNATIONAL)
        is_valid = is_valid_number(parsed_phone)
        is_possible = is_possible_number(parsed_phone)
        phone_info = (
            f"\n  {Fore.BLUE}[+] {Fore.WHITE}Номер телефона -> {formatted_number}"
            f"\n  {Fore.BLUE}───────────────────────────────────────────╯"
            f"\n  {Fore.BLUE}[+] {Fore.WHITE}Страна -> {country}"
            f"\n  {Fore.BLUE}───────────────────────────────────────────╯"
            f"\n  {Fore.BLUE}[+] {Fore.WHITE}Регион -> {region}"
            f"\n  {Fore.BLUE}───────────────────────────────────────────╯"
            f"\n  {Fore.BLUE}[+] {Fore.WHITE}Оператор -> {carrier_info}"
            f"\n  {Fore.BLUE}───────────────────────────────────────────╯"
            f"\n  {Fore.BLUE}[+] {Fore.WHITE}Активен -> {is_possible}"
            f"\n  {Fore.BLUE}───────────────────────────────────────────╯"
            f"\n  {Fore.BLUE}[+] {Fore.WHITE}Статус -> {is_valid}"
            f"\n  {Fore.BLUE}───────────────────────────────────────────╯\n"
        )
        print(phone_info)
    except Exception as e:
        print(f"\n{Fore.BLUE}[!] Произошла ошибка -> {Fore.WHITE}{str(e)}\n")

def phone():
    phone = input(f"\n{Fore.BLUE}[+] {Fore.WHITE}Введите номер телефона -> ")
    phoneinfo(phone)

def web_crwl():
    url = input("Введите URL для краулинга: ")
    user_agents = ['Mozilla/5.0', 'Chrome/88.0.4324.104', 'Safari/537.36']
    headers = {'User-Agent': random.choice(user_agents)}

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')
        links = soup.find_all('a')
        print("\nНайденные ссылки:\n")
        for link in links:
            print(link.get('href'))
    else:
        print(f"Ошибка при обращении к URL: {response.status_code}")
        

if __name__ == "__main__":
    while True:
        clear_console()  
        display_banner()

        choice = input("Введите номер действия: ")

        if choice == "1":
            print(Colorate.Horizontal(Colors.green_to_white, f"User agent:: {generate_user_agent()}"))
        elif choice == "2":
            print(Colorate.Horizontal(Colors.green_to_white, f"Mullvad key: {generate_mullvad_key()}"))
        elif choice == "3":
            def transform_text(input_text):
                translit_dict = {
                    "а": "@", "б": "Б", "в": "B", "г": "г", "д": "д", "е": "е", "ё": "ё", "ж": "ж", "з": "3",
                    "и": "u", "й": "й", "к": "K", "л": "л", "м": "M", "н": "H", "о": "0", "п": "п", "р": "P", 
                    "с": "c", "т": "T", "у": "y", "ф": "ф", "х": "X", "ц": "ц", "ч": "4", "ш": "ш", "щ": "щ", 
                    "ъ": "ъ", "ы": "ы", "ь": "ь", "э": "э", "ю": "ю", "я": "я", "А": "A", "Б": "6", "В": "V", 
                    "Г": "r", "Д": "D", "Е": "E", "Ё": "Ё", "Ж": "Ж", "З": "2", "И": "I", "Й": "Й", "К": "K", 
                    "Л": "Л", "М": "M", "Н": "H", "О": "O", "П": "П", "Р": "P", "С": "C", "Т": "T", "У": "Y", 
                    "Ф": "Ф", "Х": "X", "Ц": "Ц", "Ч": "Ч", "Ш": "Ш", "Щ": "Щ", "Ъ": "Ъ", "Ы": "bl", "Ь": "b", 
                    "Э": "Э", "Ю": "9Y", "Я": "9A"
                }
                transformed_text = []
                for char in input_text:
                    if char in translit_dict:
                        transformed_text.append(translit_dict[char])
                    else:
                        transformed_text.append(char)
                return "".join(transformed_text)
            input_text = pystyle.Write.Input("\nВведите текст -> ", pystyle.Colors.green_to_white, interval=0.005)
            transformed_text = transform_text(input_text)
            print()
            pystyle.Write.Print("Результат -> " + transformed_text + "\n", pystyle.Colors.green_to_white, interval=0.005)                    
        elif choice == "9":
            os.system("python nick.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню...")) 
        elif choice == "4":
            phone()
        elif choice == "5":
            web_crwl()
        elif choice == "6":
             port_scanner()
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню..."))                   
        elif choice == "7":
             proxy_checker()
        elif choice == "8":
             create_dox_template()                 
        elif choice == "10":
            os.system("python ddos1.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню..."))                   
        elif choice == "11":
            os.system("python ddos2.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню..."))                   
        elif choice == "12":
            os.system("python ddos3.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню..."))                   
        elif choice == "13":
            os.system("python text.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню..."))                   
        elif choice == "14":
            os.system("python decoded.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню...")) 
                               
        elif choice == "15":
            os.system("python account.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню..."))                   
        elif choice == "16":
            os.system("python channel.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню..."))                   
        elif choice == "17":
            os.system("python chat.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню...")) 
             
        