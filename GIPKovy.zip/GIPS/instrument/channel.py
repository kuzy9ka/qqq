import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import time
import random
from fake_useragent import UserAgent
from datetime import datetime
import platform
import socket
import colorama
import os
import base64
import itertools
from threading import Thread
green = colorama.Fore.LIGHTGREEN_EX
senders = {     "dlyabravla655@gmail.com": "kprn ihvr bgia vdys",     "huyznaet06@gmail.com": "cyebpnyiX!7663", "alabuga793@gmail.com": "tzukrehwY!7554" }

recievers = {
   "support@telegram.org",
    "dmca@telegram.org",
    "security@telegram.org",
    "sms@telegram.org",
    "info@telegram.org",
    "marta@telegram.org",
    "spam@telegram.org",
    "alex@telegram.org",
    "abuse@telegram.org",
    "pavel@telegram.org",
    "durov@telegram.org",
    "dmca@telegram.org",
    "elies@telegram.org",
    "ceo@telegram.org",
    "mr@telegram.org",
    "levlam@telegram.org",
    "perekopsky@telegram.org",
    "recover@telegram.org",
    "germany@telegram.org",
    "hyman@telegram.org",
    "qa@telegram.org",
    "stickers@telegram.org",
    "ir@telegram.org",
    "vadim@telegram.org",
    "shyam@telegram.org",
    "stopca@telegram.org",
    "u003esupport@telegram.org",
    "ask@telegram.org",
    "125support@telegram.org",
    "me@telegram.org",
    "dmca@telegram.org",
    "enquiries@telegram.org",
    "api_support@telegram.org",
    "marketing@telegram.org",
    "ca@telegram.org",
    "recovery@telegram.org",
    "http@telegram.org",
    "corp@telegram.org",
    "corona@telegram.org",
    "ton@telegram.org",
    "sticker@telegram.org",
    "support@telegram.org",
    "dmca@telegram.org",
    "security@telegram.org",
    "sms@telegram.org",
    "dmca@telegram.org",
    "info@telegram.org",
    "marta@telegram.org",
    "spam@telegram.org",
    "alex@telegram.org",
    "abuse@telegram.org",
    "pavel@telegram.org",
    "durov@telegram.org",
    "elies@telegram.org",
    "ceo@telegram.org",
    "mr@telegram.org",
    "levlam@telegram.org",
    "perekopsky@telegram.org",
    "recover@telegram.org",
    "germany@telegram.org",
    "hyman@telegram.org",
    "qa@telegram.org",
    "stickers@telegram.org", 
    "dmca@telegram.org",
    "ir@telegram.org",
    "vadim@telegram.org",
    "shyam@telegram.org",
    "stopca@telegram.org",
    "u003esupport@telegram.org",
    "ask@telegram.org",
    "125support@telegram.org",
    "me@telegram.org",
    "enquiries@telegram.org",
    "api_support@telegram.org",
    "marketing@telegram.org",
    "dmca@telegram.org",
    "ca@telegram.org",
    "recovery@telegram.org"}


def clear():
    os.system("clear" if os.name == "nt" else "cls")


def send_email(receiver, sender_email, sender_password, subject, body):
    for sender_email, sender_password in senders.items():
        try:
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = receiver
            msg['Subject'] = subject
            msg.attach(MIMEText(body, 'plain'))
            server = smtplib.SMTP('smtp.mail.ru', 587)
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver, msg.as_string())
            time.sleep(3)
            server.quit()
            return True
        except Exception as e:
            continue
    return False


def handle_complaint(senders, receivers):
    total_emails = len(senders) * len(receivers)
    sent_emails = 0

def send_email(receiver, sender_email, sender_password, subject, body):
    for sender_email, sender_password in senders.items():
        try:
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = receiver
            msg['Subject'] = subject
            msg.attach(MIMEText(body, 'plain'))
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver, msg.as_string())
            time.sleep(3)
            server.quit()
            return True
        except Exception as e:
            continue
    return False


def handle_complaint(senders, receivers):
    total_emails = len(senders) * len(receivers)
    sent_emails = 0

snostgk = green + """
[1] Снос за живодерство.

[2] Снос за публикацию личной информации. 

[3] Снос за стикеры с насилием. 

[4] Снос за детскую порнографию. 

[5] Снос за порнографию. 

[6] Снос за публикацию мануалов по доксу.
 
[7] Снос за публикацию мануалов по свату. 

[8] Снос за набор в тиму. 

[9] Снос за призывы к насилию. 

[10] Снос за оскорбления (не ебу снесет или нет). 

[11] Снос за продажу наркотиков.
 
[12] Снос за продажу оружия. 

[13] Снос за очень частую рекламу. 

[14] Снос за публикацию свата. 

[15] Снос за накрутку.

[16] Снос за продажу докс прог. 

"""

print(snostgk)
complaint_choice = input(green + "Выберите функцию :  ")

if complaint_choice in ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"]:
    clear()
    chat_link = input(green + "Введите ссылку канала : ")
    violation_chat_link = input(green + "Введите ссылку на нарушение :  ")
complaint_texts = {
    "1":
    f"Hello, I found a channel on Telegram: {chat_link} where videos/photos of animal abuse are being posted. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this channel!",
    "2":
    f"Hello, I found a channel on your Telegram platform: {chat_link} where personal and private data of Telegram users are being posted. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this channel!",
    "3":
    f"Hello, I found a channel on Telegram: {chat_link} where stickers containing violence are being posted. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this channel.",
    "4":
    f"Hello, I found a channel on your Telegram platform: {chat_link} where child pornography is being posted. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this channel.",
    "5":
    f"Hello, I found a channel on your Telegram platform: {chat_link} where pornographic material is being posted. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this channel!",
    "6":
    f"Hello, I found a channel: {chat_link} where manuals on how to properly do a de-anonymization are being posted. Link to the violation: {violation_chat_link}. I kindly request that this channel be blocked for violating Telegram rules. Thank you in advance!",
    "7":
    f"Hello, I found a channel: {chat_link} where manuals on how to conduct fake bomb threats (swatting) are being posted. Link to the violation: {violation_chat_link}. I kindly request that this channel be blocked for violating Telegram rules. Thank you in advance!",
    "8":
    f"Hello, I found a channel: {chat_link} where recruitment for an illegal group of doxxers and swatters is taking place. Link to the violation: {violation_chat_link}. I kindly request that this channel be blocked for violating the rules. Thank you in advance!",
    "9":
    f"Hello, I found a channel: {chat_link} where calls for violence are being posted. Link to the violation: {violation_chat_link}. I kindly request that this channel be blocked as it violates Telegram rules.",
    "10":
    f"Hello, I found a Telegram channel where posts with severe insults are being made. Link to the channel: {chat_link}, link to the violation: {violation_chat_link}. I kindly request that the channel be blocked!",
    "11":
    f"Hello, I found a channel: {chat_link} that is selling drugs. Link to the violation: {violation_chat_link}. I kindly request that this channel be blocked as soon as possible!",
    "12":
    f"Hello, I found a channel: {chat_link} that is selling weapons. Link to the violation: {violation_chat_link}. I kindly request that this channel be blocked as soon as possible!",
    "13":
    f"Hello, I found a channel: {chat_link} that posts excessive advertisements. Link to the violation: {violation_chat_link}. I kindly request that this channel be blocked as soon as possible!",
    "14":
    f"Hello, I found a channel: {chat_link} that is posting fake bomb threats (swatting). Link to the violation: {violation_chat_link}. I kindly request that this channel be blocked as soon as possible!",
    "15":
    f"Hello, I found a channel: {chat_link} that has inflated subscriber numbers. Link to the violation: {violation_chat_link}. I kindly request that this channel be blocked as soon as possible!",
    "16":
    f"Hello, I found a channel where programs for finding personal data of people are being sold. Link to the channel: {chat_link}, link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this channel."
}

for _ in range(len(senders) * len(recievers)):
    sender_email, sender_password = random.choice(list(senders.items()))
    receiver_email = random.choice(list(recievers))
    complaint_text = complaint_texts[complaint_choice]
    complaint_body = complaint_text.format(
        chat_link=chat_link.strip(), violation_chat_link=violation_chat_link.strip())
    send_email(receiver_email, sender_email, sender_password,
               "Очень важно!", complaint_body)
    print(green + "письмо отправлено")
    sent_email = 0
else:
    input(
        green +
        "Произошла ошибка! Нажмите Enter для возврата в меню\n"
    )
    clear()
    os.system("python main.py")

if __name__ == "__main__":
    handle_complaint(senders, recievers)