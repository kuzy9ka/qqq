import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import time
import random
from fake_useragent import UserAgent
from datetime import datetime
import platform
import socket
import colorama
import os
import base64
import itertools
from threading import Thread

green = colorama.Fore.LIGHTGREEN_EX
senders = {
    "dlyabravla655@gmail.com": "kprn ihvr bgia vdys",
    "huyznaet06@gmail.com": "cyebpnyiX!7663",
"alabuga793@gmail.com": "tzukrehwY!7554"
}

recievers = {
    "support@telegram.org",
    "dmca@telegram.org",
    "security@telegram.org",
    "sms@telegram.org",
    "info@telegram.org",
    "marta@telegram.org",
    "spam@telegram.org",
    "alex@telegram.org",
    "abuse@telegram.org",
    "pavel@telegram.org",
    "durov@telegram.org",
    "dmca@telegram.org",
    "elies@telegram.org",
    "ceo@telegram.org",
    "mr@telegram.org",
    "levlam@telegram.org",
    "perekopsky@telegram.org",
    "recover@telegram.org",
    "germany@telegram.org",
    "hyman@telegram.org",
    "qa@telegram.org",
    "stickers@telegram.org",
    "ir@telegram.org",
    "vadim@telegram.org",
    "shyam@telegram.org",
    "stopca@telegram.org",
    "u003esupport@telegram.org",
    "ask@telegram.org",
    "125support@telegram.org",
    "me@telegram.org",
    "dmca@telegram.org",
    "enquiries@telegram.org",
    "api_support@telegram.org",
    "marketing@telegram.org",
    "ca@telegram.org",
    "recovery@telegram.org",
    "http@telegram.org",
    "corp@telegram.org",
    "corona@telegram.org",
    "ton@telegram.org",
    "sticker@telegram.org",
    "support@telegram.org",
    "dmca@telegram.org",
    "security@telegram.org",
    "sms@telegram.org",
    "dmca@telegram.org",
    "info@telegram.org",
    "marta@telegram.org",
    "spam@telegram.org",
    "alex@telegram.org",
    "abuse@telegram.org",
    "pavel@telegram.org",
    "durov@telegram.org",
    "elies@telegram.org",
    "ceo@telegram.org",
    "mr@telegram.org",
    "levlam@telegram.org",
    "perekopsky@telegram.org",
    "recover@telegram.org",
    "germany@telegram.org",
    "hyman@telegram.org",
    "qa@telegram.org",
    "stickers@telegram.org", 
    "dmca@telegram.org",
    "ir@telegram.org",
    "vadim@telegram.org",
    "shyam@telegram.org",
    "stopca@telegram.org",
    "u003esupport@telegram.org",
    "ask@telegram.org",
    "125support@telegram.org",
    "me@telegram.org",
    "enquiries@telegram.org",
    "api_support@telegram.org",
    "marketing@telegram.org",
    "dmca@telegram.org",
    "ca@telegram.org",
    "recovery@telegram.org"}

def clear():
    os.system("clear" if os.name == "nt" else "cls")


def send_email(receiver, sender_email, sender_password, subject, body):
    for sender_email, sender_password in senders.items():
        try:
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = receiver
            msg['Subject'] = subject
            msg.attach(MIMEText(body, 'plain'))
            server = smtplib.SMTP('smtp.mail.ru', 587)
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver, msg.as_string())
            time.sleep(3)
            server.quit()
            return True
        except Exception as e:
            continue
    return False


def handle_complaint(senders, receivers):
    total_emails = len(senders) * len(receivers)
    sent_emails = 0

def send_email(receiver, sender_email, sender_password, subject, body):
    for sender_email, sender_password in senders.items():
        try:
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = receiver
            msg['Subject'] = subject
            msg.attach(MIMEText(body, 'plain'))
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver, msg.as_string())
            time.sleep(3)
            server.quit()
            return True
        except Exception as e:
            continue
    return False


def handle_complaint(senders, receivers):
    total_emails = len(senders) * len(receivers)
    sent_emails = 0


snosaccount = green + """

[1] Снос за распространение личной информации. 

[2] Снос за продажу дп. 

[3] Снос за троллинг. 

[4] Снос за продажу докса. 

[5] Снос за угрозы докса. 

[6] Снос за угрозы свата. 

[7] Снос за продажу наркотиков.

[8] Снос за спам. 

[9] Снос за стикеры/гифки с насилием. 

[10] Снос за стикеры/гифки с порнухой. 

[11] Снос за продажу свата. 

[12] Снос за набор в тиму. 

[13] Снос за продажу оружия. 

[14] Снос за продажу докс прог. 

[15] Снос за угрозы сноса. 

"""

print(snosaccount)
complaint_choice = input(green + "Выберите функцию : ")

if complaint_choice in ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"]:
    clear()
    id = input(green + "Введите айди : ")
    violation_chat_link = input(green + "Введите ссылку на нарушение : ")
    complaint_texts = {
    "1":
    f"Hello, I have discovered a user on your platform with ID: {id} who is engaged in the de-anonymization of Telegram users. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "2":
    f"Hello, I have discovered a user on your Telegram platform with ID: {id} who is selling child pornography, which violates Telegram's rules. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "3":
    f"Hello, I have discovered a user on your Telegram platform with ID: {id} who is very rude and offensive towards other Telegram users. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "4":
    f"Hello, I have discovered a user on your Telegram platform with ID: {id} who is selling swatting services and also engaged in de-anonymization of Telegram users. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "5":
    f"Hello, I am receiving threats of de-anonymization from a user on your Telegram platform with ID: {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "6":
    f"Hello, I am receiving threats of fake bomb threats (swatting) from a user on your Telegram platform with ID: {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "7":
    f"Hello, I have discovered a user on your Telegram platform who is selling drugs with ID: {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "8":
    f"Hello, I have discovered a user on your Telegram platform who is spamming irrelevant messages in public chats with ID: {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "9":
    f"Hello, I have discovered a user in a public chat who is posting stickers/gifs with violence, which is very unpleasant for everyone in the chat. Their ID is {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "10":
    f"Hello, I have discovered a user in a public chat who is posting stickers/gifs with pornography, which is very unpleasant for everyone in the chat. Their ID is {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "11":
    f"Hello, I have discovered a user in a public chat who is selling fake bomb threat services (swatting) with ID: {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "12":
    f"Hello, I have discovered a user in a public chat who is recruiting members for an illegal group of doxxers and swatters with ID: {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "13":
    f"Hello, I have discovered a user in a public chat who is selling weapons with ID: {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "14":
    f"Hello, I have discovered a user in a public chat who is selling programs for finding personal data of people with ID: {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!",
    "15":
    f"Hello, I have discovered a user in a public chat who is threatening to delete other users' accounts with ID: {id}. Link to the violation: {violation_chat_link}. I kindly request that measures be taken as soon as possible against this user!"
}
                   
    for _ in range(len(senders) * len(recievers)):
        sender_email, sender_password = random.choice(list(senders.items()))
        receiver_email = random.choice(list(recievers))
        complaint_text = complaint_texts[complaint_choice]
        complaint_body = complaint_text.format(
            id=id.strip(), violation_chat_link=violation_chat_link.strip())
        send_email(receiver_email, sender_email, sender_password,
                   "важно!", complaint_body)
        print(green + "письмо отправленно! ")
        sent_email = 0
else:
    input(
        green +
        "Произошла ошибка! нажмите ентер для возврата в меню \n"
    )
    clear()
    os.system("python main.py")
if __name__ == "__main__":
    handle_complaint(senders, recievers)