import string
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import time
import random
from fake_useragent import UserAgent
from datetime import datetime
import platform
import socket
import colorama
import os
import base64
import itertools
from threading import Thread

green = colorama.Fore.LIGHTGREEN_EX
senders = {
    "dlyabravla655@gmail.com": "kprn ihvr bgia vdys",
    "huyznaet06@gmail.com": "cyebpnyiX!7663"
}

recievers = {
    "support@telegram.org",
    "dmca@telegram.org",
    "security@telegram.org",
    "sms@telegram.org",
    "info@telegram.org",
    "marta@telegram.org",
    "spam@telegram.org",
    "alex@telegram.org",
    "abuse@telegram.org",
    "pavel@telegram.org",
    "durov@telegram.org",
    "dmca@telegram.org",
    "elies@telegram.org",
    "ceo@telegram.org",
    "mr@telegram.org",
    "levlam@telegram.org",
    "perekopsky@telegram.org",
    "recover@telegram.org",
    "germany@telegram.org",
    "hyman@telegram.org",
    "qa@telegram.org",
    "stickers@telegram.org",
    "ir@telegram.org",
    "vadim@telegram.org",
    "shyam@telegram.org",
    "stopca@telegram.org",
    "u003esupport@telegram.org",
    "ask@telegram.org",
    "125support@telegram.org",
    "me@telegram.org",
    "dmca@telegram.org",
    "enquiries@telegram.org",
    "api_support@telegram.org",
    "marketing@telegram.org",
    "ca@telegram.org",
    "recovery@telegram.org",
    "http@telegram.org",
    "corp@telegram.org",
    "corona@telegram.org",
    "ton@telegram.org",
    "sticker@telegram.org",
    "support@telegram.org",
    "dmca@telegram.org",
    "security@telegram.org",
    "sms@telegram.org",
    "dmca@telegram.org",
    "info@telegram.org",
    "marta@telegram.org",
    "spam@telegram.org",
    "alex@telegram.org",
    "abuse@telegram.org",
    "pavel@telegram.org",
    "durov@telegram.org",
    "elies@telegram.org",
    "ceo@telegram.org",
    "mr@telegram.org",
    "levlam@telegram.org",
    "perekopsky@telegram.org",
    "recover@telegram.org",
    "germany@telegram.org",
    "hyman@telegram.org",
    "qa@telegram.org",
    "stickers@telegram.org", 
    "dmca@telegram.org",
    "ir@telegram.org",
    "vadim@telegram.org",
    "shyam@telegram.org",
    "stopca@telegram.org",
    "u003esupport@telegram.org",
    "ask@telegram.org",
    "125support@telegram.org",
    "me@telegram.org",
    "enquiries@telegram.org",
    "api_support@telegram.org",
    "marketing@telegram.org",
    "dmca@telegram.org",
    "ca@telegram.org",
    "recovery@telegram.org"}

def clear():
    os.system("clear" if os.name == "nt" else "cls")


def send_email(receiver, sender_email, sender_password, subject, body):
    for sender_email, sender_password in senders.items():
        try:
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = receiver
            msg['Subject'] = subject
            msg.attach(MIMEText(body, 'plain'))
            server = smtplib.SMTP('smtp.mail.ru', 587)
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver, msg.as_string())
            time.sleep(3)
            server.quit()
            return True
        except Exception as e:
            continue
    return False


def handle_complaint(senders, receivers):
    total_emails = len(senders) * len(receivers)
    sent_emails = 0

def send_email(receiver, sender_email, sender_password, subject, body):
    for sender_email, sender_password in senders.items():
        try:
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = receiver
            msg['Subject'] = subject
            msg.attach(MIMEText(body, 'plain'))
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver, msg.as_string())
            time.sleep(3)
            server.quit()
            return True
        except Exception as e:
            continue
    return False


def handle_complaint(senders, receivers):
    total_emails = len(senders) * len(receivers)
    sent_emails = 0


snosaccount = green + """

[1] Снос чата по продажам наркотиков. 

[2] Снос чата по продаже оружия

[3] Снос чата живодеров

[4] Снос чата троллей

[5] Снос чата доксеров

"""

print(snosaccount)
complaint_choice = input(green + "Выберите функцию : ")

if complaint_choice in ["1", "2", "3", "4", "5"]:
    clear()
    id = input(green + "Введите ссылку на чат : ")
    complaint_texts = {
    "1":
    f"Hello, I have discovered a public chat where drugs are being sold. Link to the chat: {id}. I kindly request that measures be taken as soon as possible against this chat.", 
    "2":
    f"Hello, I have discovered a public chat where firearms are being sold illegally. Link to the chat: {id}. I kindly request that measures be taken as soon as possible against this chat.", 
    "3":
    f"Hello, I have discovered a public chat where people are engaging in animal abuse. Link to the chat: {id}. I kindly request that measures be taken as soon as possible against this chat.", 
    "4":
    f"Hello, I have discovered a public chat where people are insulting the families of chat users. Link to the chat: {id}. I kindly request that measures be taken as soon as possible against this chat.", 
    "5":
    f"Hello, I have discovered a public chat where users are leaking personal data of Telegram users. Link to the chat: {id}. I kindly request that measures be taken as soon as possible against this chat."
}
               
    for _ in range(len(senders) * len(recievers)):
        sender_email, sender_password = random.choice(list(senders.items()))
        receiver_email = random.choice(list(recievers))
        complaint_text = complaint_texts[complaint_choice]
        complaint_body = complaint_text.format(
            id=id.strip())
        send_email(receiver_email, sender_email, sender_password,
                   "очень срочно!", complaint_body)
        print(green + "письмо отправленно! ")
        sent_email = 0
else:
    input(
        green +
        "Произошла ошибка! нажмите ентер для возврата в меню \n"
    )
    clear()
    os.system("python main.py")
if __name__ == "__main__":
    handle_complaint(senders, recievers)