import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))
        
def number_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('base', value)
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def inn_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('Pasport', value)
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def snils_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('Pasport', value)   
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def base_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('base', value)  
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def email_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('base', value)   
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def fio():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('Pasport', value)    
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def car_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('Car', value)      
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def telegram_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('Telegram', value)  
    
import urllib.request
import json
import os

def get_ip():
    getIP = input("\n[+] Введите IP адрес: ")
    url = f"https://ipinfo.io/{getIP}/json"
    try:
        getInfo = urllib.request.urlopen(url)
        infoList = json.load(getInfo)
    except:
        print('[!] Ошибка при запросе данных по IP. Ничего не найдено.')
        return

    def whoisIPinfo(ip):
        try:
            myCommand = f"whois {ip}"
            whoisInfo = os.popen(myCommand).read()
            return whoisInfo
        except Exception as e:
            return f"[!] Ошибка при выполнении whois: {str(e)}"

    print("\nИнформация о IP:")
    print(f"Айпи адрес: {infoList.get('ip', 'Не найдено')}")
    print(f"Город: {infoList.get('city', 'Не найдено')}")
    print(f"Регион: {infoList.get('region', 'Не найдено')}")
    print(f"Страна: {infoList.get('country', 'Не найдено')}")
    print(f"Часовой пояс: {infoList.get('timezone', 'Не найдено')}")
    print(f"Координаты города: {infoList.get('loc', 'Не найдено')}")
    print(f"Организация: {infoList.get('org', 'Не найдено')}")
    print(f"ASN: {infoList.get('asn', 'Не найдено')}")
    print(f"Hostname: {infoList.get('hostname', 'Не найдено')}")
    
    print("\nДополнительная информация через WHOIS:")
    whois_info = whoisIPinfo(getIP)
    print(whois_info)

if __name__ == '__main__':
    get_ip()        
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def discord_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('base', value)           
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def Vk_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('Vk', value)          
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def card_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('base', value)         
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def ok_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('Ok', value)            
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def whatsapp_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('base', value)      
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def telegram_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('Telegram', value)      
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def vin_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('Car', value)      
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def bin_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('car', value)      
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def ogrn_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('car', value)      
    
import os
import time
import glob
from pystyle import Colors, Colorate

text_formats = ['.csv', '.txt', '.sql', '.xlsx', '.json', '.log']

def dbsearch(db, value):
    found_results = []
    try:
        with open(db, 'r', encoding='utf-8') as f:
            Fline = f.readline()  
            
        with open(db, 'r', encoding='utf-8') as f:
            for line in f:
                if value in line:  
                    fdata = line.replace(',', ';').replace('\t', '    ').split(';')  
                    sdata = Fline.replace(',', ';').replace('\t', '    ').split(';')  
                    found_data = []
                    for i in range(len(fdata)):
                        if len(fdata[i]) < 80: 
                            if i < len(sdata):
                                key = sdata[i].strip()  
                                val = fdata[i].strip() if fdata[i].strip() else 'не найден'  
                                if key:  
                                    key_colored = Colorate.Horizontal(Colors.green_to_white, key)
                                    val_colored = Colorate.Horizontal(Colors.green_to_white, val)
                                    found_data.append(('  ├ ' + key_colored + ' -> ' + val_colored, '  ├ ' + key + ' -> ' + val))

                    found_data = [line for line in found_data if ': не найден' not in line[1]]  
                    if found_data:
                        db_colored = '└──│ База данных -> ' + db
                        found_data.insert(0, (db_colored, '└──│ База данных -> ' + db))
                        found_results.append(found_data)
    except BaseException as e:
        print(Colorate.Horizontal(Colors.green_to_white, '[ ! ] Ошибка: ' + str(e)))
    return found_results

def search_in_directory(directory, value):
    start_time = time.time()
    all_found_results = []
    db_files = []
    for ext in text_formats:
        db_files.extend(glob.glob(os.path.join(directory, '*' + ext)))
    db_files = [db for db in db_files if os.path.basename(db) != 'результаты_поиска.txt']

    try:
        for db in db_files:
            found_results = dbsearch(db, value)
            if found_results:
                all_found_results.extend(found_results)
                for result in found_results:
                    for colored_line, _ in result:
                        print(colored_line)
                    print('\n')
    except Exception as ex:
        print(ex)
    finally:
        end_time = time.time()
        elapsed_time = end_time - start_time
        summary_text = f'\n🔍 Поисковой запрос: {value}\n📊 Всего найдено результатов: {len(all_found_results)}\n'
        summary_text += f'⏳Затраченное время: {elapsed_time:.2f} секунд\n' if elapsed_time <= 60 else f'⏳Затраченное время: {elapsed_time / 60:.2f} минут\n'
        print(Colorate.Horizontal(Colors.green_to_white, summary_text))


def pts_search():
    value = input(Colorate.Horizontal(Colors.green_to_white, 'Введите поисковой запрос: '))
    search_in_directory('car', value)
    
import requests
from bs4 import BeautifulSoup

def search_on_website(url, search_term):
    response = requests.get(url)
    
    if response.status_code != 200:
        return f"Ошибка загрузки страницы: {response.status_code}"

    soup = BeautifulSoup(response.text, 'html.parser')
    occurrences = soup.body(text=lambda text: text and search_term.lower() in text.lower())
    
    if occurrences:
        return f"Найдено {len(occurrences)} вхождений слова '{search_term}'"
    else:
        return f"Слово '{search_term}' не найдено на странице."

def Site_search():
    url = input("Введите URL сайта: ")
    search_term = input("Введите слово для поиска: ")
    
    result = search_on_website(url, search_term)

    print(result)  
    
import requests
from geopy.geocoders import Nominatim 

def search_by_coordinates(latitude, longitude):

    geolocator = Nominatim(user_agent="geoapiExercises")
    
    location = geolocator.reverse((latitude, longitude), language="ru")
    
    if location:
        return f"Адрес: {location.address}"
    else:
        return "Адрес не найден для указанных координат."

def Coordinates_search():

    try:
        latitude = float(input("Введите широту: "))
        longitude = float(input("Введите долготу: "))
        

        result = search_by_coordinates(latitude, longitude)
        print(result)
    except ValueError:
        print("Ошибка: Введите правильные числовые значения для координат.") 
        
import requests

def check_company(platform, base_url, query):

    url = base_url.format(query)
    headers = {"User-Agent": "CompanySearchBot"}
    try:
        response = requests.get(url, headers=headers, allow_redirects=True)
        if response.status_code == 200:
            print(f"[+] Результаты найдены на {platform}: {url}")
        elif response.status_code == 404:
            print(f"[-] Информация не найдена на {platform}.")
        else:
            print(f"[?] Ошибка {response.status_code} при проверке {platform}.")
    except Exception as e:
        print(f"[!] Ошибка подключения к {platform}: {e}")

def search_company(query):

    platforms = {
        "ЕГРЮЛ/ЕГРИП": "https://egrul.nalog.ru/index.html?query={}",
    }
    print(f"Ищем информацию по запросу: {query}")
    for platform, base_url in platforms.items():
        check_company(platform, base_url, query)

def Egrul_search():

    query = input("Введите ИНН, ОГРН или название компании: ").strip()
    search_company(query)    
    
import requests

def check_company(platform, base_url, query):

    url = base_url.format(query)
    headers = {"User-Agent": "CompanySearchBot"}
    try:
        response = requests.get(url, headers=headers, allow_redirects=True)
        if response.status_code == 200:
            print(f"[+] Результаты найдены на {platform}: {url}")
        elif response.status_code == 404:
            print(f"[-] Информация не найдена на {platform}.")
        else:
            print(f"[?] Ошибка {response.status_code} при проверке {platform}.")
    except Exception as e:
        print(f"[!] Ошибка подключения к {platform}: {e}")

def search_company(query):

    platforms = {
        "Зачестный бизнес": "https://zachestnyibiznes.ru/search?query={}",
    }
    print(f"Ищем информацию по запросу: {query}")
    for platform, base_url in platforms.items():
        check_company(platform, base_url, query)

def biz_search():

    query = input("Введите ИНН, ОГРН или название компании: ").strip()
    search_company(query)       
    
import requests

def check_company(platform, base_url, query):
   
    url = base_url.format(query)
    headers = {"User-Agent": "CompanySearchBot"}
    try:
        response = requests.get(url, headers=headers, allow_redirects=True)
        if response.status_code == 200:
            print(f"[+] Результаты найдены на {platform}: {url}")
        elif response.status_code == 404:
            print(f"[-] Информация не найдена на {platform}.")
        else:
            print(f"[?] Ошибка {response.status_code} при проверке {platform}.")
    except Exception as e:
        print(f"[!] Ошибка подключения к {platform}: {e}")

def search_company(query):

    platforms = {
        "OpenCorporates": "https://opencorporates.com/companies?utf8=✓&q={}",
    }
    print(f"Ищем информацию по запросу: {query}")
    for platform, base_url in platforms.items():
        check_company(platform, base_url, query)

def corp_search():
  
    query = input("Введите ИНН, ОГРН или название компании: ").strip()
    search_company(query)                                                                                                                                              