import requests
from bs4 import BeautifulSoup

def check_case(platform, base_url, query, parse_function=None):
    """
    Проверяет информацию по делу на платформе и парсит результаты.
    """
    url = base_url.format(query)
    headers = {"User-Agent": "CaseSearchBot"}
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            if parse_function:
                parse_function(platform, response.text)
            else:
                print(f"[+] Результаты найдены на {platform}: {url}")
        elif response.status_code == 404:
            print(f"[-] Информация не найдена на {platform}.")
        else:
            print(f"[?] Ошибка {response.status_code} при проверке {platform}.")
    except Exception as e:
        print(f"[!] Ошибка подключения к {platform}: {e}")

def parse_kadarbitr(platform, html):
    """
    Парсит результаты с сайта Арбитражного суда.
    """
    soup = BeautifulSoup(html, "html.parser")
    results = soup.find_all("div", class_="search-result")
    if results:
        print(f"[+] Результаты на {platform}:")
        for result in results[:3]:  # Ограничиваем до 3 результатов
            case_name = result.find("a", class_="result-title").get_text(strip=True)
            case_details = result.find("div", class_="result-info").get_text(strip=True)
            print(f"Название дела: {case_name}\nДетали: {case_details}\n")
    else:
        print(f"[-] Нет результатов на {platform}.")

def search_case(query):
    platforms = {
        "Арбитражный суд": ("https://kad.arbitr.ru/Search/index", parse_kadarbitr),
    }
    print(f"Ищем информацию по делу: {query}")
    for platform, (base_url, parse_function) in platforms.items():
        check_case(platform, base_url, query, parse_function)

if __name__ == "__main__":
    print("Поиск информации по судебным делам")
    query = input("Введите номер дела или ключевые слова: ").strip()
    search_case(query)