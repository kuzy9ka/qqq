import random
import secrets
import string
import os
from faker import Faker
from colorama import init
from pystyle import Colors, Colorate, Center

from Searchh import (
    number_search,
    inn_search,
    snils_search,
    base_search,
    email_search,
    fio,
    get_ip,
    car_search,
    telegram_search,
    discord_search,
    Vk_search,
    card_search,
    ok_search,
    whatsapp_search,
    vin_search,
    bin_search,
    ogrn_search,
    pts_search,
    Site_search,
    Coordinates_search,
    Egrul_search,
    biz_search,
    corp_search,   
)

init(autoreset=True)

fake = Faker('ru_RU')

# 81•ГЕН. ИМЕНИ
def generate_name():  
    return fake.first_name()

# 82•ГЕН. ФАМИЛИИ
def generate_surname():  
    return fake.last_name()

# 83•ГЕН. ОТЧЕСТВА
def generate_patronymic():  
    return fake.first_name_male()

# 84•ГЕН. КАРТЫ
def generate_card():  
    return ''.join([random.choice(string.digits) for _ in range(16)])

# 85•ГЕН. ДАТЫ
def generate_date():  
    return fake.date_this_century()

# 86•ГЕН. ПАРОЛЯ
def generate_password():  
    return ''.join(random.choices(string.ascii_letters + string.digits, k=12))

# 87•ГЕН. СЛОВА
def generate_word():  
    return fake.word()

# 88•ГЕН. ЦИТАТЫ
def generate_quote():  
    return fake.sentence()

# 89•ГЕН. ПРОКСИ
def generate_proxy():  
    return f"{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}.{random.randint(1, 255)}:{random.randint(1024, 65535)}"

# 90•ГЕН. IP
def generate_ip():  
    return f"{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}"

# 91•ГЕН. КООРДИНАТЫ
def generate_coordinates():  
    return f"{random.uniform(-90, 90)}, {random.uniform(-180, 180)}"

# 92•ГЕН. НОМЕРА
def generate_phone_number():  
    return fake.phone_number()

# 93•ГЕН. ЦВЕТА
def generate_color():  
    return f"#{random.randint(0, 0xFFFFFF):06x}"

# 94•ГЕН. СТРАНЫ
def generate_country():  
    countries = ['Россия', 'Китай', 'США', 'Франция', 'Германия', 'Индия']
    return random.choice(countries)

# 95•ГЕН. КООРДИНАТЫ
def generate_coordinates_repeat():  
    return f"{random.uniform(-90, 90)}, {random.uniform(-180, 180)}"

# 96•ГЕН. ГОРОДА
def generate_city():  
    return fake.city()

# 97•ГЕН. НОВОСТИ
def generate_news():  
    return fake.text(max_nb_chars=100)

# 98•ГЕН. АКЦИИ
def generate_promotion():  
    return fake.text(max_nb_chars=50)

# 99•ГЕН. EMAIL
def generate_email():  
    return fake.email()

# 100•ГЕН. ПРОФЕССИИ
def generate_profession():  
    professions = ['Инженер', 'Врач', 'Учитель', 'Артист', 'Писатель']
    return random.choice(professions)

# 101•ГЕН. ЮЗЕР
def generate_username():  
    return fake.user_name()

# 102•ГЕН. ЦИТАТЫ
def generate_quote_repeat():  
    return fake.sentence()

# 103•ГЕН. ИНТЕРЬВЮ
def generate_interview_question():  
    questions = ['Расскажите о себе', 'В чем ваши сильные стороны?', 'Где вы видите себя через 5 лет?']
    return random.choice(questions)

# 104•ГЕН. ФАКТ
def generate_fact():  
    facts = ['Земля круглая.', 'Вода закипает при 100°C.', 'Солнце — это звезда.']
    return random.choice(facts)

# 105•ГЕН. ИСТОРИИ
def generate_story():  
    return fake.text(max_nb_chars=200)

# 106•ГЕН. ИДЕЯ
def generate_idea():  
    ideas = ['Открыть технологическую компанию', 'Создать новое приложение', 'Написать книгу']
    return random.choice(ideas)

# 107•ГЕН. ГОРОДА
def generate_city_repeat():  
    return fake.city()

# 108•ГЕН. ХЗ
def generate_hz():  
    return random.choice(['Да', 'Нет', 'Не знаю'])

# 109•ГЕН. QR
def generate_qr():  
    return fake.uuid4()

# 110•ГЕН. ЛИЦЕНЗИИ
def generate_license():  
    return fake.uuid4()

# 111•ГЕН. НИКА
def generate_nickname():  
    return fake.user_name()

# 112•ГЕН. SSH
def generate_ssh_key():  
    return fake.ssh_key()

# 113•ГЕН. АДРЕСА
def generate_address():  
    return fake.address()

# 114•ГЕН. ПАСПОРТА
def generate_passport():  
    return fake.uuid4()

# 115•ГЕН. КОМПАНИИ
def generate_company():  
    return fake.company()

# 116•ГЕН. SSH
def generate_ssh_key_repeat():  
    return fake.ssh_key()

# 117•ГЕН. АКЦИИ
def generate_promotion_repeat():  
    return fake.text(max_nb_chars=50)

# 118•ГЕН. ТОКЕН
def generate_token():  
    return ''.join(random.choices(string.ascii_letters + string.digits, k=16))

# 119•ГЕН. QR
def generate_qr_repeat():  
    return fake.uuid4()

# 120•ГЕН. ЛИЦЕНЗИИ
def generate_license_repeat():    
    return fake.uuid4()
                                                               
def clear_console():
    if os.name == 'nt':  
        os.system('cls')
    else:  
        os.system('clear')

def display_banner():
    banner = """ 
                                            ▄██████▄  ▄█     ▄███████▄    ▄████████ 
                                          ███    ███ ███    ███    ███   ███    ███ 
                                          ███    █▀  ███▌   ███    ███   ███    █▀  
                                         ▄███        ███▌   ███    ███   ███        
                                        ▀▀███ ████▄  ███▌ ▀█████████▀  ▀███████████ 
                                          ███    ███ ███    ███                 ███ 
                                          ███    ███ ███    ███           ▄█    ███ 
                                          ████████▀  █▀    ▄████▀       ▄████████▀  
                                          

         ╭───────────────────╮                       ╭───────────────────╮                     ╭───────────────────╮
         │       OSINT       │                       │       MANUAL      │                     │     GENERATION    │
╭───────────────────────────────────────╮  ╭───────────────────────────────────────╮  ╭───────────────────────────────────────╮
│ 1•ПОИСК ПО НОМЕРУ │ 6•ПОИСК ПО ФИО    │  │ 41•АНОНИМНОСТЬ 1  │ 46•ДОКС ЛВЛ 1     │  │ 81•ГЕН. ИМЕНИ     │ 86•ГЕН. ИДЕЯ      │
│ 2•ПОИСК ПО ИНН    │ 7•ПОИСК ПО IP     │  │ 42•АНОНИМНОСТЬ 2  │ 47•ДОКС ЛВЛ 2     │  │ 82•ГЕН. ФАМИЛИИ   │ 87•ГЕН. ГОРОДА    │
│ 3•ПОИСК ПО СНИЛС  │ 8•ПОИСК ПО АДРЕСУ │  │ 43•АНОНИМНОСТЬ 3  │ 48•ДОКС ЛВЛ 3     │  │ 83•ГЕН. ОТЧЕСТВА  │ 88•ГЕН. ЦИТАТЫ    │
│ 4•ПОИСК ПО БД     │ 9•ПОИСК ПО МАШИНЕ │  │ 44•OSINT ЛВЛ 1    │ 49•СВАТ ПО ПОЧТЕ  │  │ 84•ГЕН. КАРТЫ     │ 89•ГЕН. ПРОКСИ    │
│ 5•ПОИСК ПО ПОЧТЕ  │ 10•ПОИСК ПО ТГ    │  │ 45•OSINT ЛВЛ 2    │ 50•СВАТ ПО НОУТ   │  │ 85•ГЕН. ДАТЫ      │ 90•ГЕН. IP        │ 
│ 11•ПОИСК ПО ДС    │ 16•ПОИСК ПО ЛОКАЦИ│  │ 51•СНОС ТГ КАНАЛА │ 56•МАНУАЛ СНОС    │  │ 91•ГЕН. КООРДИНАТ │ 93•ГЕН. ЦВЕТА     │
│ 12•ПОИСК ПО ВК    │ 17•ПОИСК ПО ВИН   │  │ 52•МАНУАЛ СВАТ    │ 57•СНОС ВК        │  │ 92•ГЕН. НОМЕРА    │ 94•ГЕН. СТРАНЫ    │
│ 13•ПОИСК ПО КАРТЕ │ 18•ПОИСК ПО БИН   │  │ 53•МАНУАЛ ПРОБИВ  │ 58•СНОС СЕССИЙ    │  │ 95•ГЕН. КООРДИНАТ │ 96•ГЕН. ГОРОДА    │
│ 14•ПОИСК ПО ОК    │ 19•ПОИСК ПО ОГРН  │  │ 54•ЗАЩИТА ОТ ДОКСА│ 59•МАНУАЛ СНОС 2  │  │ 97•ГЕН. НОВОСТИ   │ 99•ГЕН. EMAIL     │
│ 15•ПОИСК ПО WHATS │ 20•ПОИСК ПО ПТС   │  │ 55•ДОКС           │ 60•МАНУАЛ СНОС 3  │  │ 98•ГЕН. АКЦИИ     │100•ГЕН. ПРОФЕССИИ │
╰───────────────────────────────────────╯  ╰───────────────────────────────────────╯  ╰───────────────────────────────────────╯
╭───────────────────────────────────────╮  ╭───────────────────────────────────────╮  ╭───────────────────────────────────────╮
│ 21•ПОИСК ПО ШКОЛЕ │ 26•ПОИСК ПО ДАТЕ  │  │ 61•МАНУАЛ СНОС 4  │ 66•СОЗДАНИЕ ВИРУСА│  │101•ГЕН. ЮЗЕР      │106•ГЕН. ПАРОЛЯ    │
│ 22•ПОИСК ПО ГОС   │ 27•ПОИСК ПАСПОРТ  │  │ 62•СНОС ВК 2      │ 67•РЕЙД ЛИЧКИ     │  │102•ГЕН. ЦИТАТЫ    │107•ГЕН. СЛОВА     │
│ 23•ПОИСК ПО HLR   │ 28•ПОИСК САЙТА    │  │ 63•СЛИВ ЛОГОВ     │ 68•УГОН ЮЗА       │  │103•ГЕН. ИНТЕРЬВЮ  │108•ГЕН. ХЗ        │
│ 24•ПОИСК ПО MAC   │ 29•ПОИСК ПО ФОТО  │  │ 64•МАНУАЛ ВЗЛОМ   │ 69•ДОКС ВИРТА     │  │104•ГЕН. ФАКТ      │109•ГЕН. QR        │
│ 25•ПОИСК ПО НИКУ  │ 30•ПОИСК ПО LOGIN │  │ 65•ДДОС МАНУАЛ    │ 70•ID ПОИСК ТГ    │  │105•ГЕН. ИСТОРИ    │110•ГЕН. ЛИЦЕНЗИИ  │
│ 31•ПОИСК ПО SUD RF│ 36•ПОИСК BANKROTRF│  │ 71•МАНУАЛ ПО БОТУ │ 76•УЗНАТЬ АЙДИ    │  │111•ГЕН. НИКА      │116•ГЕН. SSH       │
│ 32•ПОИСК АРБИТ СУД│ 37•ПОИСК RUSPROF  │  │ 72•ОБХОД ЗАЩИТЫ ГБ│ 77•АНОН ОРАКУЛ    │  │112•ГЕН. АДРЕСА    │117•ГЕН. АКЦИИ     │
│ 33•ПОИСК ПО EGRUL │ 38•SOON...        │  │ 73•СКАМ АВИТО     │ 78•АНОН ЛЕАК ОСИНТ│  │113•ГЕН. УЛИЦЫ     │118•ГЕН. ТОКЕН     │
│ 34•ПОИСК ЗАЧЕСБИЗ │ 39•SOON...        │  │ 74•ПОИСК БД       │ 79•АНОН ХЗ        │  │114•ГЕН. ПАСПОРТА  │119•ГЕН. QR        │
│ 35•ПОИСК OPENCORP │ 40•SOON...        │  │ 75•QIWI VERIFIC   │ 80•SOON...        │  │115•ГЕН. КОМПАНИИ  │120•ГЕН. ЛИЦЕНЗИИ  │
╰───────────────────────────────────────╯  ╰───────────────────────────────────────╯  ╰───────────────────────────────────────╯                                           
                  ╭──────────────────────────────────────────────────────────────────────────────────────╮
                  │ author: @WeirdToom channel: @DoxersToolkit   │      Не писать по поводу софта        │
                  ╰──────────────────────────────────────────────────────────────────────────────────────╯                                                                          
                                                 ╭───────────────────────────╮ 
                                                 │      0• INSTRUMENTS       │ 
                                                 ╰───────────────────────────╯ 


  
     """

    centered_banner = Colorate.Horizontal(Colors.green_to_white, Center.XCenter(banner))
    print(centered_banner)

if __name__ == "__main__":
    while True:
        clear_console()  
        display_banner()  

        choice = input("Введите ваш выбор ➙ ")
            
        if choice == "1":
            number_search()
            input("Нажмите ENTER...")

        elif choice == "2":
            inn_search()
            input("Нажмите ENTER...")

        elif choice == "3":
            snils_search()
            input("Нажмите ENTER...")

        elif choice == "4":
            base_search()
            input("Нажмите ENTER...")

        elif choice == "5":
            email_search()
            input("Нажмите ENTER...")

        elif choice == "6":
            fio()
            input("Нажмите ENTER...")

        elif choice == "7":
            get_ip()
            input("Нажмите ENTER...")

        elif choice == "8":
            car_search()
            input("Нажмите ENTER...")

        elif choice == "9":
            telegram_search()
            input("Нажмите ENTER...")

        elif choice == "10":
            number_search()
            input("Нажмите ENTER...")

        elif choice == "11":
            discord_search()
            input("Нажмите ENTER...")

        elif choice == "12":
            vk_search()
            input("Нажмите ENTER...")

        elif choice == "13":
            card_search()
            input("Нажмите ENTER...")

        elif choice == "14":
            ok_search()
            input("Нажмите ENTER...")

        elif choice == "15":
            whatsapp_search()
            input("Нажмите ENTER...")

        elif choice == "16":
            Coordinates_search()
            input("Нажмите ENTER...")

        elif choice == "17":
            vin_search()
            input("Нажмите ENTER...")

        elif choice == "18":
            bin_search()
            input("Нажмите ENTER...")

        elif choice == "19":
            ogrn_search()
            input("Нажмите ENTER...")

        elif choice == "20":
            pts_search()
            input("Нажмите ENTER...")

        elif choice == "21":
            base_search()
            input("Нажмите ENTER...")

        elif choice == "22":
            base_search()
            input("Нажмите ENTER...")

        elif choice == "24":
            base_search()
            input("Нажмите ENTER...")

        elif choice == "26":
            inn_search()
            input("Нажмите ENTER...")

        elif choice == "27":
            inn_search()
            input("Нажмите ENTER...")

        elif choice == "28":
            Site_search()
            input("Нажмите ENTER...")
            
        elif choice == "25":
            os.system("python nick.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню...")) 

        elif choice == "29":
            print(Colorate.Horizontal(Colors.green_to_white, f"Хай лю лю лю лю")) 

        elif choice == "30":
            base_search()
            input("Нажмите ENTER...")
            
        elif choice == "0":
            os.system("python instrument/inst.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню...")) 
            
        elif choice == "31":
            os.system("python sud2.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню...")) 
            
        elif choice == "32":
            os.system("python sud1.py")
            input(Colorate.Horizontal(Colors.blue_to_cyan, "Нажмите Enter для возврата в меню...")) 

        elif choice == "33":
            Egrul_search()
            input("Нажмите ENTER...")

        elif choice == "34":
            biz_search()
            input("Нажмите ENTER...")

        elif choice == "35":
            corp_search()
            input("Нажмите ENTER...")
            
        elif choice == "36":
            bankrot_search()
            input("Нажмите ENTER...")

        elif choice == "37":
            rus_search()
            input("Нажмите ENTER...")
                        
                                                                   
        elif choice == "81":
            print(Colorate.Horizontal(Colors.green_to_white, f"Имя: {generate_name()}"))            
            input("Нажмите ENTER...")

        elif choice == "82":
            print(Colorate.Horizontal(Colors.green_to_white, f"Фамилия: {generate_surname()}"))            
            input("Нажмите ENTER...")

        elif choice == "83":
            print(Colorate.Horizontal(Colors.green_to_white, f"Отчество: {generate_patronymic()}"))            
            input("Нажмите ENTER...")

        elif choice == "84":
            print(Colorate.Horizontal(Colors.green_to_white, f"Карта: {generate_card()}"))            
            input("Нажмите ENTER...")

        elif choice == "85":
            print(Colorate.Horizontal(Colors.green_to_white, f"Дата: {generate_date()}"))            
            input("Нажмите ENTER...")

        elif choice == "106":
            print(Colorate.Horizontal(Colors.green_to_white, f"Пароль: {generate_password()}"))            
            input("Нажмите ENTER...")

        elif choice == "107":
            print(Colorate.Horizontal(Colors.green_to_white, f"Слово: {generate_word()}"))            
            input("Нажмите ENTER...")

        elif choice == "88":
            print(Colorate.Horizontal(Colors.green_to_white, f"Цитата: {generate_quote()}"))            
            input("Нажмите ENTER...")

        elif choice == "89":
            print(Colorate.Horizontal(Colors.green_to_white, f"Прокси: {generate_proxy()}"))            
            input("Нажмите ENTER...")

        elif choice == "90":
            print(Colorate.Horizontal(Colors.green_to_white, f"IP: {generate_ip()}"))            
            input("Нажмите ENTER...")

        elif choice == "91":
            print(Colorate.Horizontal(Colors.green_to_white, f"Координаты: {generate_coordinates()}"))            
            input("Нажмите ENTER...")

        elif choice == "92":
            print(Colorate.Horizontal(Colors.green_to_white, f"Номер: {generate_phone_number()}"))            
            input("Нажмите ENTER...")

        elif choice == "93":
            print(Colorate.Horizontal(Colors.green_to_white, f"Цвет: {generate_color()}"))            
            input("Нажмите ENTER...")

        elif choice == "94":
            print(Colorate.Horizontal(Colors.green_to_white, f"Страна: {generate_country()}"))            
            input("Нажмите ENTER...")

        elif choice == "95":
            print(Colorate.Horizontal(Colors.green_to_white, f"Координаты (повтор): {generate_coordinates_repeat()}"))            
            input("Нажмите ENTER...")

        elif choice == "96":
            print(Colorate.Horizontal(Colors.green_to_white, f"Город: {generate_city()}"))            
            input("Нажмите ENTER...")

        elif choice == "97":
            print(Colorate.Horizontal(Colors.green_to_white, f"Новости: {generate_news()}"))            
            input("Нажмите ENTER...")

        elif choice == "98":
            print(Colorate.Horizontal(Colors.green_to_white, f"Акции: {generate_promotion()}"))            
            input("Нажмите ENTER...")

        elif choice == "99":
            print(Colorate.Horizontal(Colors.green_to_white, f"Email: {generate_email()}"))            
            input("Нажмите ENTER...")

        elif choice == "100":
            print(Colorate.Horizontal(Colors.green_to_white, f"Профессия: {generate_profession()}"))            
            input("Нажмите ENTER...")

        elif choice == "101":
            print(Colorate.Horizontal(Colors.green_to_white, f"Юзер: {generate_username()}"))            
            input("Нажмите ENTER...")

        elif choice == "102":
            print(Colorate.Horizontal(Colors.green_to_white, f"Цитата (повтор): {generate_quote_repeat()}"))            
            input("Нажмите ENTER...")

        elif choice == "103":
            print(Colorate.Horizontal(Colors.green_to_white, f"Интервью: {generate_interview_question()}"))            
            input("Нажмите ENTER...")

        elif choice == "104":
            print(Colorate.Horizontal(Colors.green_to_white, f"Факт: {generate_fact()}"))            
            input("Нажмите ENTER...")

        elif choice == "105":
            print(Colorate.Horizontal(Colors.green_to_white, f"История: {generate_story()}"))            
            input("Нажмите ENTER...")

        elif choice == "86":
            print(Colorate.Horizontal(Colors.green_to_white, f"Идея: {generate_idea()}"))            
            input("Нажмите ENTER...")

        elif choice == "87":
            print(Colorate.Horizontal(Colors.green_to_white, f"Город (повтор): {generate_city_repeat()}"))            
            input("Нажмите ENTER...")

        elif choice == "108":
            print(Colorate.Horizontal(Colors.green_to_white, f"ХЗ: {generate_hz()}"))            
            input("Нажмите ENTER...")

        elif choice == "109":
            print(Colorate.Horizontal(Colors.green_to_white, f"QR: {generate_qr()}"))            
            input("Нажмите ENTER...")

        elif choice == "110":
            print(Colorate.Horizontal(Colors.green_to_white, f"Лицензия: {generate_license()}"))            
            input("Нажмите ENTER...")

        elif choice == "111":
            print(Colorate.Horizontal(Colors.green_to_white, f"Ника: {generate_nickname()}"))            
            input("Нажмите ENTER...")

        elif choice == "112":
            print(Colorate.Horizontal(Colors.green_to_white, f"SSH ключ: {generate_ssh_key()}"))            
            input("Нажмите ENTER...")

        elif choice == "113":
            print(Colorate.Horizontal(Colors.green_to_white, f"Адрес: {generate_address()}"))            
            input("Нажмите ENTER...")

        elif choice == "114":
            print(Colorate.Horizontal(Colors.green_to_white, f"Паспорт: {generate_passport()}"))            
            input("Нажмите ENTER...")

        elif choice == "115":
            print(Colorate.Horizontal(Colors.green_to_white, f"Компания: {generate_company()}"))            
            input("Нажмите ENTER...")

        elif choice == "116":
            print(Colorate.Horizontal(Colors.green_to_white, f"SSH ключ (повтор): {generate_ssh_key_repeat()}"))            
            input("Нажмите ENTER...")

        elif choice == "117":
            print(Colorate.Horizontal(Colors.green_to_white, f"Акции (повтор): {generate_promotion_repeat()}"))            
            input("Нажмите ENTER...")

        elif choice == "118":
            print(Colorate.Horizontal(Colors.green_to_white, f"Токен: {generate_token()}"))            
            input("Нажмите ENTER...")

        elif choice == "119":
            print(Colorate.Horizontal(Colors.green_to_white, f"QR (повтор): {generate_qr_repeat()}"))            
            input("Нажмите ENTER...")

        elif choice == "120":
            print(Colorate.Horizontal(Colors.green_to_white, f"Лицензия (повтор): {generate_license_repeat()}"))            
            input("Нажмите ENTER...")

        elif choice == "41":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Всех приветсвую, это мануал по доксингу 1-ову лвлу от Слайза.
Связь - @slizegod

Начнем


Прежде всего новичкам тобиж вам нужно понимать что если вы деаноните медийку из комьюнити то с вероятностью 95% у вас ничего не выйдет
Поэтому начинайте с деанонимизации личностей таких же как и вы тобиж тренироваться и освоить азы доксинга.
1 лвл доксинга это самое начало, поэтому подкину вам очень полезных сайтов которые вам сильно пригодятся

Сначала расмотрим государственные реестры. Это информационные реестры, которые используют люди для поиска своих задолженностей, 
поиск залогодателей, судебные акты, прописки т.п:

reestr-zalogov.ru — поиск по залогодателям, даст паспортные данные, место и дату рождения и т.д
zytely.rosfirm.info — найдет адрес прописки и дату рождения, необходимо знать город
mmnt.ru — найдет упоминания в документах
kad.arbitr.ru — дела, рассматриваемые арбитражными судами
bankrot.fedresurs.ru — поиск по банкротам, можно узнать ИНН, СНИЛС и адрес
sudact.ru — судебные и нормативные акты РФ, поиск по участникам и судам
spra.vkaru.net — телефонный справочник по России, Украине, Белоруссии, Казахстану, Литве и Молдове
fssprus.ru— проверка задолженностей, для физ. лица
fio.stop-list.info — поиск по ИП и судам, если есть ИНН, то можно узнать больше
gcourts.ru — поиск решений судов общей юрисдикции
service.nalog.ru — найдет ИНН, нужно знать полное ФИО, дату рождения и документ удостоверяющий личность
reestr-dover.ru — поиск в списке сведений об отмене доверенности
судебныерешения.рф — найдет судебные решения, документы с ФИО датой и статьей
notariat.ru - поиск в реестре наследственных дел, найдет дату смерти человека и адрес нотариуса оформившее дело
nalog.ru — найдет ИНН, необходимо указать дату рождения и паспортные данные, дату выдачи не обязательно верно.

Поиск по ФИО
DeanonymizationAnal, не читай ато лох
DeanonymizationAnal, не читай ато лох 2 апр 2020 в 10:45
@egrul_bot — найдет ИП и компании
reestr-zalogov.ru — поиск по залогодателям, даст паспортные данные, место и дату рождения и т.д.
zytely.rosfirm.info — найдет адрес прописки и дату рождения, необходимо знать город
mmnt.ru — найдет упоминания в документах
kad.arbitr.ru — дела, рассматриваемые арбитражными судами
bankrot.fedresurs.ru — поиск по банкротам, можно узнать ИНН, СНИЛС и адрес
sudact.ru — судебные и нормативные акты РФ, поиск по участникам и судам
nomer.center — телефонный справочник, иногда нужен VPN
spra.vkaru.net — телефонный справочник по России, Украине, Белоруссии, Казахстану, Литве и Молдове
fssprus.ru — проверка задолженностей, для физ. лица
fio.stop-list.info — поиск по ИП и судам, если есть ИНН, то можно узнать больше
gcourts.ru — поиск решений судов общей юрисдикции
service.nalog.ru — найдет ИНН, нужно знать полное ФИО, дату рождения и документ удостоверяющий личность
reestr-dover.ru — поиск в списке сведений об отмене доверенности
судебныерешения.рф — найдет судебные решения, документы с ФИО датой и статьей
notariat.ru — поиск в реестре наследственных дел, найдет дату смерти человека и адрес нотариуса оформившее дело

Cайты для того что-бы найти адрес:
Если какой-то сайт не работает, то заходите через Tor Browser.
https://spravochnikov.ru/
https://spravochnik.city/
https://09online.com/ (самый большой список городов и стран)
http://telkniga.com 
https://www.telpoisk.com/
http://ww1.infobaza.org/
zytely.rosfirm.info — найдет ФИО, адрес прописки и дату рождения, нужно знать город
https://zhityly.rosfirm.info/
https://gytel.rosfirm.info/ — поиск по ФИО и адресу.
https://zhuteli.rosfirm.info - одна из баз данных адресов. Многих городов нет, ищем по районному центру
https://nomer.org — одна из баз данных адресов
https://service.nalog.ru/addrfind.do - Адреса, указанные при государственной регистрации в качестве места нахождения несколькими юридическими лицами
https://spravnik.com/
https://spravka109.ru/spravka - Справочник адресов Украины, России, Казахстана, Беларуси, Латвии, Молдовы.
https://egrul.org/fias/
https://spravochnik-sng.com - база данных адресов, телефонов, а также сервис по установлению родственных связей.
infobel.com — найдет номер телефона, адрес и ФИО
spravochnik109.link — поиск по городскому номеру телефона, найдет ФИО и адрес


Cайты для Доксинга
https://service.nalog.ru/inn.do – сервис определения ИНН физического лица
http://bankrot.fedresurs.ru/ – единый федеральный реестр сведений о банкротстве
http://egrul.nalog.ru/ – сведения, внесенные в Единый Государственный Реестр Юридических Лиц
https://xn--90adear.xn--p1ai/check/driver/ — проверка водительского удостоверения
http://results.audit.gov.ru/ – портал открытых данных Счетной палаты Российской Федерации.
http://sudact.ru/–  ресурс по судебным и нормативным актам, включающим решения судов общей  юрисдикции, арбитражных судов и мировых судей 
http://www.cbr.ru/credit/main.asp –  справочник по кредитным организациям. Сведения ЦБ РФ о банках и кредитных организациях
https://service.nalog.ru/bi.do –  сервис позволяет выяснить, заблокированы или нет банковские счета  конкретного юридического лица или ИП
http://services.fms.gov.ru/ – проверка действительности паспортов и другие сервисы от ФМС России.
http://zakupki.gov.ru/223/dishonest/public/supplier-search.html – реестр недобросовестных поставщиков.
http://fedsfm.ru/documents/terrorists-catalog-portal-act – реестр террористов и экстримистов 
http://www.stroi-baza.ru/forum/index.php?showforum=46 — «черный список» по российским строительным компаниям.
http://xn--90afdbaav0bd1afy6eub5d.xn--p1ai/ – единая база данных решений судов общей юрисдикции РФ.
http://www.centerdolgov.ru/ –  информация о недобросовестных компаниях-должниках России, Украины,  Белоруссии, Казахстана. Поиск компаний, ИНН, стране  и городу.
http://ras.arbitr.ru/ -высший арбитражный суд РФ с картотекой арбитражных дел и банком решения арбитражных судов.
https://rosreestr.ru/wps/portal/cc_information_online – справочная информация по объектам недвижимости от Федеральной службы государственной регистрации
http://www.voditeli.ru/ — база данных о водителях грузовых автомашин, создана с целью выявления «хронических» летунов, алкоголиков, ворья и прочих.
http://www.gcourts.ru/ –  поисковик и одновременно справочник от Yandex по судам общей  юрисдикции.
http://www.e-disclosure.ru/ – сервер
 раскрытия информации по эмитентам ценных бумаг РФ.
http://www.fssprus.ru/ – картотека арбитражных дел Высшего Арбитражного Суда Российской Федерации
http://rnp.fas.gov.ru/ – Реестр недобросовестных поставщиков ФАС РФ
https://rosreestr.ru/wps/portal/p/cc_present/EGRN_1—  портал услуг Федеральной Службы Государственной Регистрации, Кадастра и  Картографии
http://www.notary.ru/notary/bd.html —  нотариальный портал. Содержит список с координатами всех частных  практикующих нотариусов России и нотариальных палат
http://allchop.ru/ — Единая база всех частных охранных предприятий
http://enotpoiskun.ru/tools/codedecode/ — Расшифровка кодов ИНН, КПП, ОГРН и др. 
http://polis.autoins.ru/ — Проверка полисов ОСАГО по базе Российского союза автостраховщиков
http://www.vinformer.su/ident/vin.php?setLng=ru — Расшифровка VIN транспортных средств 
http://fssprus.ru/ - Федералная служба судебных приставов
http://fssprus.ru/iss/ip - Банк данных исполнительных производств
http://fssprus.ru/iss/ip_search - Реестр розыска по исполнительным производствам
http://fssprus.ru/iss/suspect_info - Лица, находящиеся в розыске по подозрению в совершении преступлений
http://fssprus.ru/gosreestr_jurlic/ - Сведения, содержащиеся в государственном реестре юридических лиц,
осуществляющих деятельность по возврату просроченной задолженности в качестве основного вида деятельности
http://opendata.fssprus.ru/ - открытые данные Федеральной службы судебных приставов
http://sro.gosnadzor.ru/ - Государственный реестр саморегулируемых организаций
http://zakupki.gov.ru/epz/dishonestsupplier/quicksearch/search.html - Сведения из реестра недобросовестных поставщиков
(подрядчиков, исполнителей) и реестра недобросовестных подрядных организаций
https://rosreestr.ru/wps/portal/online_request - Справочная информация по объектам недвижимости
https://rosreestr.ru/wps/portal/p/cc_present/EGRN_1 - Форма запроса сведений ЕГРН
https://rosreestr.ru/wps/portal/p/cc_ib_portal_services/cc_ib_sro_reestrs - Реестры саморегулируемых организаций
https://rosreestr.ru/wps/portal/cc_ib_opendata - Наборы открытых данных Росреестра
https://pkk5.rosreestr.ru/ - Публичная кадастровая карта 
https://www.reestr-zalogov.ru/search/index - Реестр уведомлений о залоге движимого имущества
https://мвд.рф/wanted - Внимание, розыск!
https://www.mos.ru/karta-moskvicha/services-proverka-grazhdanina-v-reestre-studentov/ - Проверка гражданина в реестре студентов/ординаторов/аспирантов (держатели карты москвича)
http://esugi.rosim.ru - Реестр федерального имущества Российской Федерации
pd.rkn.gov.ru/operators-registry - Реестр операторов, осуществляющих обработку персональных данных
bankrot.fedresurs.ru - Единый федеральный реестр сведений о банкротстве                                                                                               
https://service.nalog.ru/zd.do - Сведения о юридических лицах, имеющих задолженность по уплате налогов и/или не представляющих налоговую отчетность более года
https://service.nalog.ru/addrfind.do - Адреса, указанные при государственной регистрации в качестве места нахождения несколькими юридическими лицами
https://service.nalog.ru/uwsfind.do - Сведения о юридических лицах и индивидуальных предпринимателях, в отношении которых представлены документы для государственной регистрации
https://service.nalog.ru/disqualified.do - Поиск сведений в реестре дисквалифицированных лиц
https://service.nalog.ru/disfind.do - Юридические лица, в состав исполнительных органов которых входят дисквалифицированные лица
https://service.nalog.ru/svl.do - Сведения о лицах, в отношении которых факт невозможности участия (осуществления руководства) в организации установлен (подтвержден) в судебном порядке
https://service.nalog.ru/mru.do - Сведения о физических лицах, являющихся руководителями или учредителями (участниками) нескольких юридических лиц
http://rkn.gov.ru/mass-communications/reestr/ – реестры Госкомнадзора.
http://www.chinacheckup.com/ – лучший платный ресурс по оперативной и достоверной верификации китайских компаний.
http://www.dnb.com/products.html - модернизированный ресурс одной из лучших в мире компаний в сфере бизнес-информации Dun and Bradstreet.
http://www.imena.ua/blog/ukraine-database/ – 140+ общедоступных электронных баз данных Украины.
http://www.fciit.ru/ – eдиная информационная система нотариата России.
http://gradoteka.ru/ – удобный сервис статистической информации по городам РФ.
http://www.egrul.ru/ - сервис по поиску сведений о компаниях и директорах из государственных реестров юридических лиц России и 150 стран мира.
http://disclosure.skrin.ru - уполномоченное ФСФР (Федеральной службой по финансовым рынкам) на раскрытие информации на рынке ценных бумаг агентство ЗАО “СКРИН”.
http://1prime.ru/docs/product/disclosure.html – уполномоченное ФСФР (Федеральной службой по финансовым рынкам) на раскрытие информации на рынке ценных бумаг агентство ЗАО “Прайм-ТАСС”.
https://www.cbr.ru/ - информация ЦБ по бюро кредитных историй, внесенных в государственный реестр.
http://www.gks.ru/accounting_report – предоставление данных бухгалтерской отчетности по запросам пользователей от Федеральной службы государственной статистики.
http://www.tks.ru/db/ – таможенные онлайн базы данных.
http://tipodop.ru/ - очередной каталог предприятий, организаций в России.
http://www.catalogfactory.org/ – организации России – финансовые результаты, справочные данные и отзывы. Данные в настоящее время доступны по 4,8 млн.организаций.
http://pravo.ru/ – справочно-информационная система, включающая в настоящее время 40 млн. законодательных, нормативных и поднормативных актов Российской Федерации.
http://azstatus.ru/ – информационная база данных, в которой содержится информация обо всех предпринимателях Российской Федерации, а также информация о российских компаниях (юридические лица). Всего в справочнике более 10 миллионов записей.
http://seldon.ru/ – информационно-аналитическая система, значительно упрощающая и систематизирующая работу с закупками.
http://www.reestrtpprf.ru/ – реестр надежных партнеров от системы Торгово-промышленных палат в Российской Федерации.
http://iskr-a.com/ – сообщество безопасников и платформа для информационного взаимодействия в одном флаконе.
http://www.ruscentr.com/ - реестр базовых организаций российской экономики, добросовестных поставщиков и бюджетоэффективных заказчиков (организаций).
https://www.aips-ariadna.com/ – антикриминальная онлайн система учета по России и СНГ. Относится к тому же ценовому сегменту, что и «Контур Фокус» и т.п., и отличается от других систем большим уклоном в судебные и правоохранительные данные. Ориентирована прежде всего на службу безопасности.
http://188.254.71.82/rds_ts_pub/ – единый реестр зарегистрированных деклараций РФ.
http://croinform.ru/index.php?page=index – сервис проверки клиентов, конкурентов, партнеров и контрагентов в режиме реального времени 24/7, в т.ч. со смартфона. Цены вполне человеческие. Сервис знаменитого Кроноса.
http://www.zakupki.gov.ru/epz/main/public/home.html – официальный сайт Российской Федерации для размещения информации о размещении заказов на поставки товаров, выполнение работ, оказание услуг.
http://rostender.info/ – ежедневная рассылка новых тендеров в соответствии с отраслевыми и региональными настройками.
http://pravo.fso.gov.ru/ – государственная система правовой информации. Позволяет быть в курсе всех новых правовых актов. Имеет удобный поисковик.
http://www.bicotender.ru/ - самая полная поисковая система тендеров и закупок по России и странам СНГ.
http://sophist.hse.ru/ – единый архив экономических и социологических данных по российской Федерации от НИУ ВШЭ.
http://www.tenderguru.ru/ – национальный тендерный портал, представляет собой единую базу государственных и коммерческих тендеров с ежедневной рассылкой анонсов по объявленным тендерам.
http://www.moscowbase.ru/ - поддерживаемые в состоянии постоянной актуальности адресно-телефонные базы данных по компаниям Москвы и России. Уникальным продуктом компании являются базы данных новых компаний, появившихся в течение двух последних кварталов. В данные включается вся стандартная информация, предоставляемая платными онлайн базами, плюс актуальные внутренние телефоны и e-mail.
http://www.credinform.ru/ru-RU/globas - информационно-аналитическая система ГЛОБАС – I содержит данные о семи миллионах компаний. Предназначена для комплексной информационной поддержке бизнеса и создания комплексных аналитических отчетов.
http://www.actinfo.ru/ – отраслевой бизнес-справочник предприятий России по их актуальным почтовым адресам и контактным телефонам. Единственный справочник, который включает контактные данные по предприятиям, созданным в предыдущем квартале.
http://www.sudrf.ru/ -государственная автоматизированная система РФ «Правосудие».
http://docs.pravo.ru/ – справочно-правовая система Право.ру. Предоставляет полный доступ к нормативным документам любых субъектов Российской Федерации, а также к судебной практике арбитражных судов и мнениям экспертов любых юридических областей. Ежемесячная плата для работы с полной базой документов составляет 500 руб.
http://www.egrul.com/ – платные и бесплатные сервисы поиска по ЕГРЮЛ, ЕГРИП, ФИО, балансам предприятий и др. параметрам. Одно из лучших соотношений цены и качества.
http://www.fedresurs.ru/ – единый федеральный реестр сведений о фактах деятельности юридических лиц.
http://www.findsmi.ru/ – бесплатный сервис поиска данных по 65 тыс. региональных СМИ.
http://hub.opengovdata.ru/ – хаб, содержащий открытые государственные данные всех уровней, всех направлений. Проект Ивана Бегтина.
http://www.ruward.ru/ – ресурс агрегатор всех рейтингов Рунета. В настоящее время уже содержит 46 рейтингов и более 1000 компаний из web и PR индустрии.
http://www.b2b-energo.ru/firm_dossier/ - информационно-аналитическая и торгово-операционная система рынка продукции, услуг и технологий для электроэнергетики.
http://opengovdata.ru/ – открытые базы данных государственных ресурсов
http://bir.1prime.ru/ – информационно-аналитическая система «Бир-аналитик» позволяет осуществлять поиск данных и проводить комплексный анализ по всем хозяйствующим субъектам России, включая компании, кредитные организации, страховые общества, регионы и города.
http://www.prima-inform.ru/ – прямой доступ к платным и бесплатным информационным ресурсам различных, в т.ч. контролирующих организаций. Позволяет получать документы и сводные отчеты, информацию о российских компаниях, индивидуальных предпринимателях и физических лицах, сведения из контролирующих организаций. Позволяет проверять субъектов на аффилированность и многое другое.
http://www.integrum.ru/ –портал для конкурентной разведки с самым дружественным интерфейсом. Содержит максимум информации, различных баз данных, инструментов мониторинга и аналитики. Позволяет компании в зависимости от ее нужд, размеров и бюджета выбирать режим пользования порталом.
www.spark-interfax.ru – портал обладает необходимой для потребностей конкурентной разведки полнотой баз данных, развитым функционалом, постоянно добавляет новые сервисы.
https://fira.ru/ – молодой быстроразвивающийся проект, располагает полной и оперативной базой данных предприятий, организаций и регионов. Имеет конкурентные цены.
www.skrin.ru – портал информации об эмитентах ценных бумаг. Наряду с обязательной информацией об эмитентах содержит базы обзоров предприятий, отраслей, отчетность по стандартам РБУ, ГААП, ИАС. ЗАО “СКРИН” является организацией, уполномоченной ФСФР.
http://www.magelan.pro/ – портал по тендерам, электронным аукционам и коммерческим закупкам. Включает в себя качественный поисковик по данной предметной сфере.
http://www.kontragent.info/ – ресурс предоставляет информацию о реквизитах контрагентов и реквизитах, соответствующих ведению бизнеса.
http://www.ist-budget.ru/ – веб-сервис по всем тендерам, госзаказам и госзакупкам России. Включает бесплатный поисковик по полной базе тендеров, а также недорогой платный сервис, включающий поиск с использованием расширенных фильтров, по тематическим каталогам. Кроме того, пользователи портала могут получать аналитические отчеты по заказчикам и поставщикам по тендерам. Есть и система прогнозирования возможных победителей тендеров.
http://www.vuve.su/ - портал информации об организациях, предприятиях и компаниях, ведущих свою деятельность в России и на территории СНГ. На сегодняшний день база портала содержит сведения о более чем 1 млн. организаций.
http://www.disclosure.ru/index.shtml - система раскрытия информации на рынке ценных бумаг Российской Федерации. Включает отчетность эмитентов, существенные новости, отраслевые обзоры и анализ тенденций.
http://www.mosstat.ru/index.html – бесплатные и платные онлайн базы данных и сервисы по ЕГРПО и ЕГРЮЛ Москвы и России, а также бухгалтерские балансы с 2005 года по настоящее время. По платным базам самые низкие тарифы в Рунете. Хорошая навигация, удобная оплата, качественная и оперативная работа.
http://www.torg94.ru/ – качественный оперативный и полезный ресурс по госзакупкам, электронным торгам и госзаказам.
http://www.k-agent.ru/ – база данных «Контрагент». Состоит из карточек компаний, связанных с ними документов, списков аффилированных лиц и годовых бухгалтерских отчетов. Документы по компаниям представлены с 2006 г. Цена в месяц 900 руб. Запрашивать данные можно на сколь угодно много компаний.
http://www.is-zakupki.ru/ – информационная система государственных и коммерческих закупок. В системе собрана наиболее полная информация по государственным, муниципальным и коммерческим закупкам по всей территории РФ. Очень удобна в работе, имеет много дополнительных сервисов и, что приятно, абсолютно разумные, доступные даже для малого бизнеса цены.
http://salespring.ru/ – открытая пополняемая база данных деловых контактов предприятий России и СНГ и их сотрудников. Функционирует как своеобразная биржа контактов.
www.multistat.ru – многофункциональный статистический портал. Официальный портал ГМЦ Росстата.

Пробив:
http://results.audit.gov.ru/ – портал открытых данных Счетной палаты Российской Федерации.
http://sudact.ru/ – ресурс по судебным и нормативным актам, включающим решения судов общей юрисдикции, арбитражных судов и мировых судей с качественным удобным поисковиком.
http://www.cbr.ru/credit/main.asp – справочник по кредитным организациям. Сведения ЦБ РФ о банках и прочих кредитных организациях, об отзывах лицензий на осуществление банковских операций и назначениях временных администраций, раскрытие информации и пр.
https://service.nalog.ru/inn.do – сервис определения ИНН физического лица.
https://service.nalog.ru/bi.do – сервис позволяет выяснить, заблокированы или нет банковские счета конкретного юридического лица или индивидуального предпринимателя.
http://188.254.71.82/rds_ts_pub/ – национальная часть единого реестра зарегистрированных таможенных деклараций, позволяющая определить кто, что, когда и откуда привез в нашу страну.
http://services.fms.gov.ru/ – проверка действительности паспортов и другие сервисы от ФМС России.
http://zakupki.gov.ru/223/dishonest/public/supplier-search.html – реестр недобросовестных поставщиков.
http://fedsfm.ru/documents/terrorists-catalog-portal-act – ресурс позволяет проверить, не являются ли ваши клиенты, контрагенты, конкуренты, и не дай бог, партнеры террористами или экстремистами.
http://www.stroi-baza.ru/forum/index.php?showforum=46 - «черный список» по российским строительным компаниям.
http://xn--90afdbaav0bd1afy6eub5d.xn--p1ai/ – единая база данных решений судов общей юрисдикции РФ.
http://web-compromat.com/service.html – набор сайтов, облегчающих проверку компаний и физических лиц.
http://www.centerdolgov.ru/ – информация о недобросовестных компаниях-должниках России, Украины, Белоруссии, Казахстана. Поиск возможен по названию компаний, ИНН, стране и городу.
http://www.egrul-base.ru/ - проверка клиентов, контрагентов, конкурентов за 15-30 минут. Проверка включает в себя поиск по «черным спискам», определение фактического хозяина бизнеса, связи компании, ее учредителей, генерального директора с другими организациями. Информация из ЕГРЮЛ. Цена 500 руб.
http://ras.arbitr.ru/ -Высший арбитражный суд РФ с картотекой арбитражных дел и банком решения арбитражных судов.
http://bankrot.fedresurs.ru/ – единый федеральный реестр сведений о банкротстве.
http://sts.gov.ua/businesspartner - лучший сервис проверки контрагентов, клиентов, конкурентов в Украине от Налоговой службы страны. Позволяет проверять юридическое лицо не только по собственным данным налоговой службы, но и другим открытым базам данных государственных порталов Украины. В России такого пока нет.
https://rosreestr.ru/wps/portal/cc_information_online – справочная информация по объектам недвижимости в режиме он-лайн от Федеральной службы государственной регистрации, кадастра и картографии.
http://www.nomer.org/moskva/ – телефонная база г.Москвы. Содержит адреса и телефоны всех московских квартир, в которых установлен телефон, и не только МГТС.
http://www.nomer.org/ - телефонный справочник городов России и СНГ
http://spravkaru.net/ – онлайн телефонный справочник по городам и регионам России.
http://www.info4help.com/ - телефонный справочник городов России (не проверялась, платная)
http://www.voditeli.ru/ - база данных о водителях грузовых автомашин, создана с целью выявления "хронических" летунов, алкоголиков, ворья и прочих.
http://telbase.spb.ru/ - Адресная и телефонная база Санкт-Петербурга (не проверялась, платная)
http://tapix.ru -Телефонный справочник городов России и бывших республик СССР (не проверялась, платная)
http://rossvyaz.ru/activity/num_resurs/registerNum/ – полезный поисковик, позволяющий определить оператора по номеру или фрагменту номера телефона оператора, месторасположение и т.п. За наводку спасибо Vinni.
http://www.rospravosudie.com/ – поисковик-сервис по судебным решениям в России. Содержит все опубликованные судебные решения, список судей Российской Федерации, а также список действующих адвокатов. По каждому судье можно посмотреть списки его решений. Предоставляет статистику преступлений по регионам. Является некоммерческим проектом.
http://www.salyk.kz/ru/taxpayer/interaktiv/Pages/default.aspx – официальный портал Налогового комитета Министерства финансов республики Казахстан. Располагает рядом удобных сервисов, включая реестр плательщиков НДС, поиск налогоплательщиков в республике и проч.
https://focus.kontur.ru/ - лучший в Рунете по соотношению цены и качества сервис проверки клиентов, контрагентов и т.п. , пользуясь официальными источниками статистики. Наряду с получением данных по отдельной организации позволяет в качестве дополнительной опции искать аффилированные между собой организации, а также пересечение по генеральным директорам, собственникам и т.п.
Федеральная Информационная Адресная Система – позволяет установить наличие или отсутствие любого адреса в любом месте в стране. Если точно такого адреса нет, то система выдаст наиболее близкие.
http://alexandr-sel.livejournal.com/33499.html#cutid1 – исчерпывающая и структурированная база ресурсов для проверки компаний на территории Республики Беларусь.
http://fellix13.livejournal.com/6683.html – необходимый набор ресурсов для проверки конрагентов на Украине от Сергея Коржова.
http://mbcredit.ru/ – в группу компаний Cronos входят ЗАО МБКИ, которое предоставляет качественные бизнес-справки и в режиме он-лайн осуществляет проверку кредитных историй по любым компаниям и персоналиям по конкурентным ценам , а также многое другое. Цены вполне конкурентные.
ttp://cases.pravo.ru/ – картотека арбитражных дел. При помощи сервиса вы получаете доступ к любому делу в любом арбитражном суде. Достаточно указать известные вам параметры. Искать надо при помощи правой колонки. Поиск можно вести по участникам дела (название организации или ИНН), по фамилии судьи, по номеру дела, фильтровать по датам.
http://www.gcourts.ru/ – поисковик и одновременно справочник от Yandex по судам общей юрисдикции. Позволяет искать по номерам дел, ответчикам, истцам, отслеживать прохождение дел по всем инстанциям. Просто неоценимый инструмент для безопасников и разведчиков.
https://service.nalog.ru/debt/ – сервис «Узнай свою задолженность» позволяет пользователям узнавать не только свою задолженность, но осуществлять поиск информации о задолженности по имущественному, транспортному, земельному налогам, налогу на доходы физических лиц, граждан РФ.
http://www.law-soft.ru/ – информация о предприятиях, находящихся в стадии банкротства, обобщается из «Коммерсанта», «Российской газеты». Информация с 2007 года по настоящее время. Через расширенный поиск Yandex отлично ищется по сайту.
http://egrul.nalog.ru/ – отсюда можно почерпнуть сведения, внесенные в Единый Государственный Реестр Юридических Лиц
http://www.e-disclosure.ru/ – сервер раскрытия информации по эмитентам ценных бумаг РФ.
http://www.fssprus.ru/ – картотека арбитражных дел Высшего Арбитражного Суда Российской Федерации
http://www.mgodeloros.ru/register/search/ – база данных должников, в которой зарегистрированы все физические и юридические лица как частного, так и публичного права (кроме государственных и органов местного самоуправления, а также тех субъектов, имущество которых сдано в ипотеку или в заклад), в отношении которых начата процедура принудительного исполнения.
http://rnp.fas.gov.ru/?rpage=687&status=find – Реестр недобросовестных поставщиков ФАС РФ
Портал услуг - портал услуг Федеральной Службы Государственной Регистрации, Кадастра и Картографии, где можно получить сведения о земельной собственности и расположенной на ней недвижимости.
http://services.fms.gov.ru/info-service.htm?sid=2000 – официальный сайт Федеральной миграционной службы России, где можно получить информацию о наличии/отсутствии регистрации того или иного гражданина на территории РФ и некоторую иную информацию.
http://www.notary.ru/notary/bd.html - нотариальный портал. Содержит список с координатами всех частных практикующих нотариусов России и нотариальных палат. Для зарегистрированных пользователей доступна судебная практика нотариусов и файловый архив. База обновляется ежедневно.
http://kad.arbitr.ru/ – он-лайн картотека Арбитражного Суда Российской Федерации. Чрезвычайно полезна при умелом использовании для конкурентной разведки.
http://allchop.ru/ - Единая база всех частных охранных предприятий
http://enotpoiskun.ru/tools/codedecode/ - Расшифровка кодов ИНН, КПП, ОГРН и др.
http://enotpoiskun.ru/tools/accountdecode/ - Расшифровка счетов кредитных организаций
http://polis.autoins.ru/ - Проверка полисов ОСАГО по базе Российского союза автостраховщиков
http://www.mtt.ru/ru/defcodes/ - Коды мобильных операторов. Очень удобный поиск.
http://www.vinformer.su/ident/vin.php?setLng=ru - Расшифровка VIN транспортных средств
http://www.vinvin.ru/about.html - Проверка VIN транспортных средств по американским БД "CARFAX" и "AutoCheck"
http://www.stolencars24.eu/ - Проверка на угон проверка по полицейским базам данных Италии, Словении, Румынии, Словакии и Чехии, а также по собственной базе данных (без ограничения количества запросов)
http://www.autobaza.pl/ - Проверка на угон в Италии, Словении, Литве (не более 3 запросов в сутки с одного IP)
http://www.alta.ru/trucks/truck.php - Расчет таможенных платежей при ввозе автомобилей из-за границы
http://kupipolis.ru/ - Расчет КАСКО, ОСАГО
http://ati.su/Trace/Default.aspx - Расчет расстояний между населенными пунктами по автодорогам
http://www.garant.ru/doc/busref/spr_dtp/ - Штрафы за нарушение Правил дорожного движения онлайн
http://fotoforensics.com/ - Сервис для проверки подлинности фотографии, выявление изменений метаданных и т.п.
http://mediametrics.ru/rating/ru/online.html - Онлайн сервис по отслеживанию популярных тем в социальных сетях и СМИ
http://poiskmail.com/ Поисk чeлoвeкa по емейлу
http://socpoisk.com/search/ -поиск людей
http://radaris.ru/ -поиск людей
http://pervoiskatel.ru/ -поиск людей
http://spys.ru/vk/ - Проверить ID скрытого пользователя Вконтакте, просмотр закрытой станицы Vkontakte
http://pasport.yapl.ru/search.php - Сайт по пробиву серии номера пасспорта,регион ,год выдачи документа
https://огрн.онлайн/ - удобный ресурс для поиска аффилированных компаний у конкретных юр./физ.лиц и многое другое.
https://www.a-3.ru/pay_gibdd - Штрафы ГИБДД - онлайн проверка и оплата. По номеру машины и другим данным.
http://services.fms.gov.ru/info-service.htm?sid=2000 - Проверка действительности паспорта гражданина РФ Главное управление по вопросам миграции МВД России - Проверка по списку недействительных российских паспортов
https://service.nalog.ru/inn-my.do - Узнай свой ИНН
http://www.russianpost.ru/resp_engine.aspx?barCode=12 - Отслеживание почтовых отправлений Почта России.
EasyFinance.ru - Контроль личных расходов и доходов
http://www.rossvyaz.ru/activity/num_resurs/registerNum/ - Как достоверно узнать по коду или номеру телефона, какому оператору связи принадлежит этот номер и в каком регионе Федеральное агентство связи (Россвязь) - Выписка из реестра Российской системы и плана нумерации
http://www.creditnet.ru/search/?type=adv - Узнать данные про фирму и директора и ИНН и ОГРН и т.д. по названию фирмы Поиск — НКБ
http://www.ispark.ru/ru-ru/ - Узнать по ФИО, какие на человеке фирмы Электронный магазин СПАРК – информация по российским компаниям
http://in-drive.ru/vinstealing.html- Авто проверить на угон в РФ
http://rospravosudie.com/ - Про всех юристов, судей и т.д. Суды, адвокаты и судебные решения - все здесь, 100+ миллионов решений - РосПравосудие
http://lawyers.minjust.ru/Lawyers - Реестр адвокатов России Онлайн
http://notaries.minjust.ru/Notaries - Реестр нотариусов онлайн
http://www.fskn.gov.ru/pages/main/attention/index.shtml - Онлайн розыск ФСКН с ФОТО
http://www.banki.ru/banks/memory/?utm_source=google - Прекратившие существование банки
https://service.nalog.ru/debt/ - Узнай свою задолженность
http://www.fssprus.ru/iss/ip/ - Банк данных исполнительных производств судебных приставов
http://avto-nomer.ru/search - По государственному регистрационному номеру можно найти фото автомобиля по России
http://egrul.nalog.ru - Единый государственный реестр юридических лиц
http://www.kartoteka.ru/ - Бесплатно узнать ведёт фирма деятельность или нет
https://www.bindb.com/bin-database.html - Сервис проверки банковских карт - по первым 6 цифрам номера показывает тип карты
https://focus.kontur.ru - Быстрый поиск организаций и ИП по ИНН, ОГРН, адресу, наименованию, ФИО

Полезные боты 

@SafeCallsBot — бесплатные анонимные звонки на любой номер телефона

@GetFb_bot — бот находит Facebook


fth.so - бесплатный сервис с множеством бд  Minecraft ( можно найти почту и айпи жертвы )

 haveibeenpwned.com — проверка почты на наличие в слитых базах
 emailrep.io — найдет на каких сайтах был зарегистрирован аккаунт использующий определенную почту
 dehashed.com — проверка почты в слитых базах
 @Smart_SearchBot — найдет ФИО, дату рождения и адрес с телефоном
 intelx.io — многофункциональный поисковик, поиск осуществляется еще и по даркнету
 @mailsearchbot — ищет по базе, дает часть пароля
 @info_baza_bot — покажет из какой базы слита почта, 2 бесплатных скана
 leakedsource.ru — покажет в каких базах слита почта
 mostwantedhf.info — найдет аккаунт skype
OSINT SITE:

Поиск по USERNAME/NICKNAME:
- https://namechk.com/

Поиск по EMAIL:
- https://haveibeenpwned.com/
- https://hacked-emails.com/
- https://ghostproject.fr/
- https://weleakinfo.com/
- https://pipl.com/
- https://leakedsource.ru/
- Приложение "Skype"

Поиск по номеру телефона:
- https://phonenumber.to
- https://pipl.com/
- Приложение "GetContact"
- Приложение "NumBuster"
- Приложение "Truecaller" или сайт https://www.truecaller.com/
- http://doska-org.ru/
- Приложение "Skype"

Общий поиск по соц. сетям, большой набор разных инструментов для поиска:
- http://osintframework.com/

Поиск местоположения базовой станции сотового оператора:
- http://unwiredlabs.com
- http://xinit.ru/bs/

Получение фотографий из соц. сетей из локального района (по геометкам):
- http://sanstv.ru/photomap



@Eye_OfGod_bot - Нормальный платный бот в тг, функционал и прайс сами чекните

@AvinfoBot — найдет аккаунт в ВК

vkpt.info (t) — мониторинг деятельности пользователя, поиск старых друзей, покажет, кому ставит лайки, все комментарии пользователя, скрытые друзья

Мощный инструмент для пробива по Number - https://github.com/sundowndev/PhoneInfoga

grep.app — поиск в репозиториях GitHub

Facebook
Если вы узнали Facebook ID через сервисы по типу lampyre.io, нужно узнать по этому ID страницу.Об этом писалось на одноименном посте на стаковерфлоу.
Ссылка - https://stackoverflow.com/questions/12827775/facebook-user-url-by-id
Сервисы: graph.tips
whopostedwhat.com
lookup-id.com (Узнать айди аккаунта фейсбук)

Так же можно искать ID аккаунта в гугл, тем самым получив больше зацепок.
@usersbox_bot (Найдет аккаунты VK, у которых указан данный Facebook)


Общий поиск по соц. сетям, большой набор разных инструментов для поиска:
http://osintframework.com/


Восстановление:

Ebay (https://signin.ebay.com/ws/eBayISAPI.dll?SignIn) — signin.ebay.com/ws/eBayISAPI.dll?SignIn
PayPal (https://www.paypal.com/authflow/password-recovery) — paypal.com/authflow/password-recovery
Mail.ru (https://account.mail.ru/recovery/) — account.mail.ru/recovery
Twitter (https://twitter.com/account/begin_password_reset) — twitter.com/account/begin_password_reset
VK.com (https://vk.com/restore) — vk.com/restore
Facebook (https://www.facebook.com/login/identify?ctx=recover) — facebook.com/login/identify?ctx=recover


munscanner.com (https://munscanner.com/dbs/) — поиск по реестрам компаний разных стран

infobel.com — найдет номер телефона, адрес и ФИО

На этом пожалуй все, доксинг 1 лвл окончен. Мануал был написан Слайзом ( Slize Redwise - @slizegod )
"""))            
            input("Нажмите ENTER...")

        elif choice == "42":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
Всех приветсвую, это мануал по доксингу 2-ому лвлу от Слайза.
Связь - @slizegod

Начнем

2-ой лвл доксинга не такой уж и простой но не такой уж и сложный

Можно начать с того что сперва вам нужно выбрать цель которую вы собираетесь задеанонимизировать.

Выбрав цель вы приступаете анализировать его страницу в Вк или Телеграм да бы увидеть зацепку которая вас приведет к разоблачению.

Откат страницы в вк - @vkhistoryrobot
Откат аккаунта телеграм - глаз бога или же @telesint

Благодаря откату можно увидеть ошибки которые допустила ваша жертва, в вк это может быть номер в био 
а в телеграмме это может быть имя или город в чатах для общения.

Ближе к обучению 

1. Формирование задач
 На этом этапе нужно четко понимать что нужно получить в конечном итоге. Это могут быть, например, ники, которые использует цель. Или нужно пробить абсолютно всю информацию о человеке в интернете. Как правило, ключевыми данными для отправки служат номера телефонов, адреса электронной почты, ники или зацепки в социальных сетях.
Этап 2. Планирование
Личные (социальные сети, блоги, сайты, никнеймы и т.д.).
Государственные (реестры, базы, суды, налоги, пограничные базы, базы дипломов, база недействительных паспортов и т.д.).
Внешние источники (друзья, знакомые, СМИ, работодатели, рекомендации).
 Очень важно визуализировать. Для этого лучше всего использовать XMind, MindMap, Maltego или другие подобные приложения. Для каждой цели нужно делать свою дорожную карту.
Сбор информации
Этот этап самый трудоёмкий, но в основном он реализуется с помощью набора софта и онлайн-сервисов. Подходя к этому этапу у вас есть должна быть какая-нибудь предварительная информация. Например, вы знаете, что человек использует в качестве пароля фамилию своей первой учительницы. И, допустим, она есть у нашей жертвы в друзьях во ВКонтакте. Это существенно сужает круг и становится ясно куда нужно смотреть в первую очередь.
Но иногда такой информации нет и нужно искать абсолютно всё. Сначала лучше начать с имени, фамилии и никнейма. Дальше можно раскручивать и искать телефон, список друзей, строить связи в социальных сетях и форумах. Но как показывает практика, почти все результаты поиска базируются на трех вещах: номер телефона, электронная почта и никнейм.

 Я собрал подборку сайтов и ботов по различным данным:

Поиск по Nickname:
@maigret_osint_bot-найдет аккаунты с таким ником среди 2000+ сайтов, дает самый точный результат @StealDetectorBOT-покажет часть утекшего пароля
 @SovaAppBot-найдет аккаунты с похожим ником среди 500+ сайтов
 Maigret (t) — найдет аккаунты с таким же ником среди 2000+ сайтов
namecheckup.com — найдет искомый ник на сайтах
instantusername.com — найдет искомый ник на сайтах
 suip.biz — найдет искомый ник на 300+ сайтах, работает очень медленно, дождитесь ответа
 namechk.com — найдет искомый ник на сайтах и в доменах
 sherlock (t) — найдет искомый ник на сайтах
whatsmyname.app — найдет искомый ник на сайтах
 boardreader.com — найдет искомый ник на форумах
 leakedsource.ru — найдет искомый ник на сайтах
 yasni.com — автоматический поиск в интернете
 social-searcher.com — найдет упоминания в соц. сетях и на сайтах
 socialmention.com — найдет упоминания ника
 Поиск по Номеру Телефона:
@Quick_OSINT_bot — найдет оператора, email, как владелец записан в контактах, базах данных и досках объявлений, аккаунты в соц. сетях и мессенджерах, в каких чатах состоит, документы, адреса и многое другое
 @clerkinfobot — бот берет данные из приложения getcontact, показывает как записан номер телефона в контактах
 @dosie_Bot — как и в боте uabaza дает информацио о паспорте только польностью, 3 бесплатные попытки
 @find_caller_bot — найдет ФИО владельца номера телефона
@get_caller_bot — поиск по утечкам персональных данных и записным книгам абонентов, может найти ФИО, дату рождения, e-mail
@get_kolesa_bot — найдет объявления на колеса.кз
 @get_kontakt_bot — найдет как записан номер в контактах, дает результаты что и getcontact
@getbank_bot — дает номер карты и полное ФИО клиента банка
@GetFb_bot — бот находит Facebook
 @Getphonetestbot — бот берет данные из приложения getcontact, показывает как записан номер телефона в контактах
@info_baza_bot — поиск в базе данных
@mailsearchbot — найдет часть пароля
@MyGenisBot — найдет имя и фамилию владельца номера
 @phone_avito_bot — найдет аккаунт на Авито
 @usersbox_bot — бот найдет аккаунты в ВК у которых в поле номера телефона указан искомый номер
 avinfo.guru — проверка телефона владельца авто, иногда нужен VPN
 fa-fa.kz — найдет ФИО, проверка наличия задолженностей, ИП, и ограничения на выезд
 getcontact.com — найдет информацию о том как записан номер в контактах
 globfone.com — бесплатные анонимные звонки на любой номер телефона
 mirror.bullshit.agency — поиск объявлений по номеру телефона
 mysmsbox.ru — определяет чей номер, поиск в Instagram, VK, OK, FB, Twitter, поиск объявлений на Авито, Юла, Из рук в руки, а так же найдет аккаунты в мессенджерах
 nuga.app — найдет Instagram аккаунт, авторизация через Google аккаунт и всего 1 попытка
 numberway.com — найдет телефонный справочник
 personlookup.com.au — найдет имя и адрес
 phoneInfoga.crvx.fr — определят тип номера, дает дорки для номера, определяет город
 spravnik.com — поиск по городскому номеру телефона, найдет ФИО и адрес
 spravochnik109.link — поиск по городскому номеру телефона, найдет ФИО и адрес
 teatmik.ee — поиск в базе организаций, ищет номер в контактах
 truecaller.com — телефонная книга, найдет имя и оператора телефона
 boardreader.com — поисковик по форумам, ищет и по нику
 dumpedlqezarfife.onion — найдет почту с паролем
 instantusername.com — проверка по сайтам и приложениям

Поиск по Email:
@Quick_OSINT_bot — найдет телефон, как владелец записан в контактах, базах данных и досках объявлений, аккаунты в соц. сетях и мессенджерах, в каких чатах состоит, документы, адреса и многое другое
 @info_baza_bot — покажет из какой базы слита почта, 2 бесплатных скана
 @last4mailbot — бот найдет последние 4 цифры номера телефона клиента Сбербанка
@mailsearchbot — ищет по базе, дает часть пароля
 @StealDetectorBOT — найдет утекшие пароли
 @GetGmail_bot — бот найдет адрес почты Gmail к которой привязан искомый email, 2 бесплатных результата и бесконечное число попыток
 cyberbackgroundchecks.com — найдет все данные гражданина США, вход на сайт разрешен только с IP адреса США
dehashed.com — проверка почты в слитых базах
 ghostproject.fr — проверка почты в слитых база
 emailrep.io — найдет на каких сайтах был зарегистрирован аккаунт использующий определенную почту
emailsherlock.com — автоматический поиск, найдет к каким сайтам привязан адрес почты
 haveibeenpwned.com — проверка почты в слитых базах
 intelx.io — многофункциональный поисковик, поиск осуществляется еще и по даркнету
 leakedsource.ru — покажет в каких базах слита почта
eakprobe.net — найдет ник и источник слитой базы 
 mostwantedhf.info — найдет аккаунт skype
 pwndb2am4tzkvold.onion — поиск по базе hwndb, реализован поиск по паролю
 pipl.com — поиск людей, адресов, телефонов по почте и др.
 recon.secapps.com — автоматический поиск и создание карт взаимосвязей
 reversegenie.com — найдет местоположение, Первую букву имени и номера телефонов
 scylla.sh — поисковик по базам утечек, найдет пароли, IP, ники и многое другое, в поле поиска введите email: и после e-mail адрес, например email:mail@email.com
 searchmy.bio — найдет учетную запись Instagram с электронной почтой в описании
 spiderfoot.net — автоматический поиск с использованием огромного количества методов, можно использовать в облаке если пройти регистрацию

 Поисковики одно из самых важных, что есть в OSINT.
 Not Evil — Ищет там, куда Google, «Яндексу» и
 другим поисковикам вход закрыт в принципе.
 Yacy|https://yacy.net — децентрализованная поисковая система
 работающая по принципу сетей P2P
 Searchcode|https://searchcode.com/ — поиск по коду в открытых репозиториях
 Publicwww|https://publicwww.com/ — поиск по исходному коду страниц, можно искать
 ники, почты, трекеры, кошельки, адреса сайтов и т.д.
 Kribrum|https://kribrum.io/ — поиск по социальным сетям
 Occrp|https://aleph.occrp.org/ — поиск по базам данных, файлам, реестрам компаний и т.д.
 Boardreader|http://boardreader.com/ — поисковик по форумам
 Wolfram  Alpha |https://www.wolframalpha.com/ — вычислительно-поисковая система
Secapps|https://hss3uro2hsxfogfq.onion.to/ — автоматический поиск и создание карт взаимосвязей
Clearnet:
shodan.io
 lampyre.io
 pipl.com
 Haystack 
 DDG 
 VisiTOR 
 OnionLand 
 Phobos 
 Tor66 
 Dark Search
 Google Onion 
 ExcavaTOR 
 Ahima 
 Gdark
 Sentor
Abiko 
 TOR Search  
 Submarine 
 Search demon 
 HD Wiki 
 Torch
 Onion Search
 Dark video 
 Avax
 Underdir 
 OLD 
 Deep web links 
 Dark Eye 
 The Hidden Wiki  
 Uncensored Hidden Wiki
 Onion Links 
 LDO 
 Tor wiki
 Raddle 
 Dread

 Определяем геолокацию по почте:

Для того, чтобы узнать местоположение интересующего вас человека, зная только адрес его почты, уже давно существует множество утилит, инструментов и программ.
 Сегодня же мы решили обратить ваше внимание на инструмент GetNotify. Он является абсолютно бесплатным, но весьма эффективным инструментом для отслеживания местоположения человека с помощью электронной почты.
 Сам по себе сервис работает на основании принципа добавления невидимого изображения (т.е трекера) в исходящие письмо, поскольку гугл разрешает редактировать исходных ход любого отправляемого письма.
 Таким образом, после открытия письма, скрытое изображение загружается с сервера GetNotify и выдает вам IP адрес жертвы.

 https://www.getnotify.com/

 Лучшие OSINT инструменты
 Если какой-то сервис не работает зайдите с Tor Browser

 Сервисы:
https://gofindwho.com - Поиск по Соц Сетям, Ф.И, Нику, Email, Номер телефона.Очень хороший сервис СОВЕТУЮ
 fssp.online - поиск задолженности по СНИЛС, ИНН, СТС, номеру ИП, ВУ и паспорта, поиск бесплатный
 mmnt.ru - найдет упоминания в документах
 rfpoisk.ru - базы данных городов связка И.Ф+ГОРОД+СТРАНА
Telefon Stop-list - поиск номера и по всем другим ресурсам.
 http://telkniga.com - вбиваем ФИО для получения адреса прописки 
https://bases-brothers.ru/ - поиск номера в объявлениях
 https://mirror.bullshit.agency/ - поиск объявлений по номеру телефона
 https://www.infobel.com/fr/world -  найдет номер телефона, адрес и ФИО
 teatmik.ee - поиск в базе организаций, ищет номер в контактах
 pimeyes.com/en/ - Поиск по Лицу
 mysmsbox.ru - определяет чей номер, поиск в Instagram, VK, OK, FB, Twitter, поиск объявлений на Авито, Юла, Из рук в руки, а так же найдет аккаунты в мессенджерах
 personlookup.com.au - найдет имя и адрес
 https://rusfinder.pro/vk/user/id12345 - Сохранёная Информация об аккаунте вместо 12345 вставьте айди человека
 https://ruprofile.pro/vk_user/id12345 - Сохранёная Информация об аккаунте вместо 12345 вставьте айди человека

 Телеграм Боты:
 @UniversalSearchBot - Поиск по Telegram, Vk, Номеру Телефону, Email.Это не копия Глаза Бога.Даёт бесплатно 7 попыток пробива.
 @TgAnalyst_bot - находит номер телефона, старое имя аккаунта, логин, IP адрес и устройство.Поиск только по Telegram ID, который состоит из цифр. Узнать ID можно в @userinfobot или @CheckID_AIDbot 
 @pimeyesbot - найдет фото лица в Интернете и даст прямую ссылку на фото
 @vkfindface_bot - найдет аккаунт в VK, поиск не точный
 @SEARCHUA_bot - 1 раз бесплатно выдает досье на гражданина Украины где есть паспорт, адрес проживания, ФИО, автомобили, родственники, email, номера телефонов и много другого
 @GetDomruBot - находит часть адреса, email и весь номер лицевого счета клиента Domru по номеру телефона
 @SangMataInfo_bot - история изменения имени аккаунта
 @eyeofbeholder_bot - бот подсказывает интересы человека по его аккаунту Telegram, дает бонус каждому новому пользователю, который можно потратить на 1 поиск
 @last4mailbot - бот найдет последние 4 цифры номера телефона клиента Сбербанка
 @find_caller_bot - найдет номер телефона По Ф.И.О
 @HimeraSearch_bot - даст адреса и телефоны, ИНН и СНИЛС, инфо о недвижимости и транспортных средствах, контакты родственников и друзей, места работы и многое другое.
 @MyGenisBot — найдет имя и фамилию владельца номера

 Думаю, это много кого заинтересует, так как по профилю Вк можно узнать о человеке многое. 
Его фотографии, записи и список друзей могут дать нам крайне много полезной информации.
Однако стоит отметить, что следующий способ работает только в том случае, если номер привязан к странице.
 Добавляем номер телефона, который мы хотим пробить в контакты нашего смартфона.
 Следом, открываем приложение "Вконтакте" и переходим на свою страницу.
 Открываем список друзей
 После этого вас предупредят, что все номера вашего справочника будут использованы и отправлены на сервер для поиска.
 Думаю, понятно, что для этих действий лучше использовать не свой основной телефон, дабы не пропалить все свои контакты.
После того, как Вы нажмете «да» вы получите список аккаунтов людей (тех что были в ваших контактах), среди которых есть наша цель.

Мануал был написан Слайзом ( Slize Redwise - @slizegod )
"""))            
            input("Нажмите ENTER...")

        elif choice == "43":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
Я хотел бы поблагодарить вас за то, что вы выбрали мой мануал для прочтения. Я научу вас буквально всему, что вам нужно
знать о докcинге. Я Слайз ( Slize Redwise) связь со мной - @slizegod
 
Первым делом вам нужно понять что произвести деанонимизацию возможно на любого члена общества, если человек позаботился о своей анонимности и замел следы который он оставил ранее,
то вы можете попытаться найти ошибку из за которой он находиться под угрозой, ведь каждый человек допускает ошибки - это нормально. Порой из за таких ошибок грубо говоря человек покидает интернет.
Что бы не быть под угрозой в интернет обществе, вам следует очистить все следы вплоть до удаления страниц< смены номеров и отдельный девайс для 'работы' 

 Что такое Doxing?
 
Doxing - – это раскрытие частной информации о человеке без его ведома или согласия. Это может включать адрес, работу, номер телефона, фотографии и многое другое. Социальные сети упростили доксинг и разрушили любую концепцию анонимности. Которая, как можно было бы подумать, существует. Сразу хочу вам сообщить о том что если вы деанонимизируете киберпреступников будь это доксер или лжеминер и сдаете данные в полицию то 
вам соответственно ничего не будет, так же если вы используете навыки доксинга с целью отпугнуть вашего обидчика будь это тролль или кто-то другой то это тоже караться законом не будет. Доксинг карается законом в том случае если же вы найденную информацию постите на всеми известный Doxbin. Ну мы же тут собрались не по закону действовать, верно?) Постить так называемые 'пасты' ( паста - в доксинге означает информация собранная в специальный шаблон ) можно не только в Doxbin, но еще и в другие источники которые я оставлю в конце мануала.

 Как же совершить успешный Dox?


Для успешного доксинга необходимо иметь время, но не всегда. Успешный доксинг может зависить не от времени но еще и от навыков, как раз таки про навыки я вам сегодня и расскажу. Максимум навыком понадобиться в том случае если же жертва имеет базовую анонимность, для успешного доксинга вам нужно анализировать каждую новую полученнную информацию о жертвве и доставать с нее новую и новую. Ведь доксинг - цепь. Почему? А потому что доксинг заключается в сборе информации с одной зацепки другую а с другой уже следущую.

 #1 -  Добывание  IP обидчика

Самый простой способ - Айпи логгер - всеми известный способ достать айпи обидчика, но многие не догадываются что благодаря айпи можно узнать очень много инфомарции.
Для того что бы узнать айпи обидчика самый легкий способ посадить его на ссылку соц-инженерией которую вы сделали на сайте и сократили.
Ссылка для создания айпи логгера - https://iplogger.org
Ссылка для сокращения ссылки айпи логгера - https://kurl.ru/

Сложный способ достования айпи адресса обидчика это инструмент wireshark
Ссылка на скачку - https://www.wireshark.org/download.html
Подробное использование и установку вы можете глянуть на ютубе.
Скачиваем Wireshark, открываем его и в фильтре обязательно указываем нужный нам протокол - STUN.
нажимаем на "лупу" (найти пакет) и видим, как у нас появится новая строка с параметрами и поисковой строкой. Там выбираем параметр строка.
В строке пишем XDR-MAPPED-ADDRESS.
включаем Wireshark и звоним через Telegram. Как только пользователь ответит на звонок, тут же у нас начнут отображаться данные и среди них будет IP адрес юзера, которому звонили.
чтобы понять, какой именно IP нам нужен, жмём уже в настроенном поисковике Найти, ищем в строке XDR-MAPPED-ADDRESS а то, что идёт после него и есть нужный нам IP
После получения айпи обидчика мы идем его использовать в разных целях

 #2 - Использование IP обидчика 

Ip адрес жертвы - очень важный момент в доксинге если нету основных зацепок, благодаря айпи адресу можно узнать много информации благодаря которой вы сократите себе поиски в значительном размере
Прикреплю пару сайтов для добычи информации 
https://www.shodan.io/ 
https://whatismyipaddress.com/ip-lookup
https://ipinfo.io/tools/map
https://www.iptrackeronline.com/
Прогнав айпи адресс жертвы по этим сайтам будет уже весомая информация по которой можно двигаться дальше.

#3 - Isp doxnig

Проверка подлинности у интернет-провайдера. Здесь вы начинаете узнавать, как найти действительно личную информацию
о цели, просто используя ее IP-адрес. Используйте их IP-адрес, чтобы связаться с их провайдером
 и найти номер провайдера. Я приведу список
инструментов в нижней части этого раздела. Это общедоступные инструменты, поскольку doxing ISP является общедоступным. Интернет-провайдер
doxing может предоставить вам множество информации о цели, начиная от их имени и
адреса и заканчивая данными их кредитной карты и SSN в файле. Это смертельно опасная тактика, и
лучше всего, если вы используете интернет-провайдера, которого трудно найти, если же вы хотите избежать воздействия со стороны интернет-провайдера.
Совет: Как вам избежать проверки интернет-провайдером? Скрывайте свой IP любой ценой. Вот как вы
избегаете доксинга от интернет-провайдера.
Совет X2: Вот пример того, как выглядит доксинг от интернет-провайдера.
Сотрудник интернет-провайдера: Здравствуйте, чем мы можем вам помочь? Это Сара.
Вы: Привет, Сара, это Том, вообще-то я сам работаю на этого интернет-провайдера, и мне было
интересно, не могли бы вы поискать клиента в одном из наших инструментов для меня. Мой инструмент
сильно глючит, и по какой-то причине у меня не работает Интернет. Мне много не нужно
, клиент связался со мной через чат поддержки, и мне нужен номер, чтобы перезвонить ему
, и имя. Остальное я могу посмотреть в одном из наших инструментов.
Сотрудник интернет-провайдера: Жаль это слышать. Позвольте мне просто посмотреть IP-адрес в нашем главном
инструменте. Минутку, пожалуйста.
*Несколько минут спустя*
Хорошо, вот номер телефона клиента, связанный с IP-адресом, и его
полное имя. Это все?
Вы: Да, мэм. Спасибо, Сара. Удачной смены.
Обычно этого достаточно. Подключение к интернет-провайдеру может быть либо действительно простым (интернет-провайдер
подключился к Comcast IP несколько недель назад, получил последние четыре SSN), либо действительно сложным
(несколько дней назад не удалось подключиться к TWC-провайдеру, потребовалось около четырех попыток). Лучше всего, если у вас
достаточно глубокий голос и звучание
Обычно это все, что требуется. Подключение к интернет-провайдеру может быть либо действительно простым (интернет-провайдер
подключился к Comcast IP несколько недель назад, получил последние четыре SSN), либо действительно сложным
(несколько дней назад не удалось подключиться к TWC-провайдеру, потребовалось около четырех попыток). Лучше всего, если у вас
достаточно глубокий голос и вы будете звучать правдоподобно (больше коучинга для женщин). Все, что
требуется, - это практика и правильное знание инструментов, чтобы получить некоторую живую поддержку.
Совет X3: Если вы потерпите неудачу с одним человеком, не переживайте по этому поводу. Просто подождите несколько минут или часов
и попробуйте обратиться к другому сотруднику службы поддержки. Некоторых интернет-провайдеров действительно трудно найти, в то время
как некоторые безумно просты.
Совет X4: Вот список инструментов интернет-провайдера. Да, это инструменты, к которым у вас может быть доступ
, потому что сам по себе ISP doxing является общедоступным, и я сомневаюсь, что вы о нем не слышали
. В любом случае, это необходимые инструменты и информация для тех случаев, когда вы
общаетесь с кем-то через интернет-провайдера. Они значительно упрощают работу интернет-провайдера.
They make ISP doxing a lot easier.

AT&T - http://www.att.com/
U-verse Support: 1-800-288-2020
Employee IDs - md905c
• Systems: G2, CCTP, SystemX, Clarify, Telegence, MyCSP, Phoenix,
Torch, CSR Admin, CTI, Agent Verification System, CCC Tool, DLC, C-Care
Sky - http://www.sky.com/
Sky Tech Support: 0-844-241-1653
• Systems: Cloud
Cox - http://ww2.cox.com/residential/home.cox
Cox Support: 877-891-2899
• Systems: Polaris (IP), iNav, edgehealth, Icon, IDM, ICOMS, SL2
Charter - https://www.charter.com/
Charter Support: 713-554-3669
• Systems: Sigma (Ask for this for lookup), IRIS
Comcast - http://www.comcast.com/
Comcast Support: 1-800-934-6489
• Systems: ACSR, Comtrac, CSG, Einstein, Grand-slam (Ask for this for
lookups), Vision
Time Warner - http://www.timewarnercable.com/
Time Warner Support - 212-364-8300
• Systems: Real, Unify (Ask for this for lookups)
Road Runner - http://www.rr.com/
Road Runner Support: 1-866-744-1678
• Systems: Real, Unify
Verizon - http://www.verizonwireless.com/
Verizon Support: 1-800-837-4966
• Systems: Coffee
Items that are capable for look up:
Name on file:
DOB on file:
SSN on file:
Phone on file:
Address on file:
ISP Account #:
Primary Account Email:
Credit Card on File:

Вот что вы получаете в ответе интернет провайдера если все прошло успешно.

#4 - Поиск по имени обидчика

Использование имени цели также очень полезно. Если у вас есть их имя, то вы, возможно, сможете узнать, где они живут, какой у них номер телефона, родственники и т.д. что
действительно могло бы быть полезно в доксе. Мы собираемся искать цели на официальных
страницах и других сайтах, поскольку многие люди не думают удалять свою информацию на
Белые страницы или просто не знают как. Их невежество будет их ошибкой.
По имени можно достать много чего, зная город, если же город вам не известен то следуйте пунктам  1  и 2 что бы узнать город и что-то большее.

Поиск Соц-сетей по имеющимся данным
https://bigbookname.com/search#
https://rocketreach.co/
https://my.mail.ru/my/search_people

На самом деле поиск по имени и доставание верной информации - одно из времязатратных дел.


#5 - Поиск по нику 

Я рекомендую вам скопировать псевдоним жертв в поисковики, такие как http://www.pipl.com, чтобы найти их аккаунты/профили в социальных сетях. 
Вы также можете получить их настоящие имена с этого сайта, я предпочитаю вручную искать профиль жертв в FACEBOOK, зайдя на http://facebook.com и выполнив поиск по настоящим именам жертв таким образом. 
После того, как у вас есть их профиль в FACEBOOK, вам следует перейти в раздел друзей, чтобы найти профиль их родителей в FACEBOOK, выполнив поиск фамилии (только в том случае, если жертве не исполнилось 18 лет). 
Как только вы найдете профиль родителей на FACEBOOK, вы сможете найти их имя  на http://www.whitepages.com, чтобы найти их номер телефона. Если у вас есть их полное имя, их деанонимизация может быть проще, но не на 100%, 
так как многие люди могут иметь то же имя, что и ваша цель Вам следует получить IP-адрес вашей цели,что бы вы могли сделать поиск по городу, данный поиск получиться более точным. 

Второй способ это всеми известный глаз бога, введите туда ник жертвы произведите поиск  по миру и возможно вам выдаст номер телефона жертвы. Мы плавно подходим к поиску по номеру

 
#6 - Поиск по номеру телефона 

Поиск по номеру телефона один из самых главных шагов в деанонимизации.

Поиск регистраций по сайтам - https://epieos.com/

Тот же поиск по сайтам где был привязан номер но уже в виде тулса - https://github.com/megadose/ignorant/

Поиск компаний - https://www.find-org.com/

Поиск утечек - https://odyssey-search.info/

Для быстрого поиска по браузера что бы найти где светился номер и на каких сайтах к примеру в вк, воспользуйтесь
intext:7999999999 ( вместо цифр используйте номер обидчика) таким способом у вас есть шанс найти упоминания номера телефона
на различных сайтах. К примеру возьмем ВК очень часто люди оставляют номер в комментариях либо же постах.
AVinfoBot (r) – делает отчет где есть данные из социальных сетей, недвижимости,
автомобилей, объявлений и телефонных книжек. Нужно пригласить другой аккаунт для
отчета

 getcontact.com (r) — выдает информацию о том как записан номер в контактах

@OffThisContactBot — поиск в утечках, ищет как записан номер в контактах,
большая база контактов, бесплатно подключите свой бот

truecaller.com (r) — телефонная книга, ищет имя и оператора телефона

avinfo.guru (r) — проверка телефона владельца авто, иногда нужен VPN

spravnik.com — поиск по городскому номеру телефона, найдет ФИО и адрес

m.ok.ru — показывает часть номера телефона, email, фамилии и полностью город с
датой регистрации, используй во вкладке инкогнито

smartsearchbot.com — бот находит ФИО, email, объявления, бесплатный поиск не
доступен для новых пользователей

@phone_avito_bot — дает ссылку на аккаунт Авито с подробной информацией
list-org.com — найдет организацию в РФ
места работы, контакты, а при регистрации можно указать любую российскую
организацию

find-org.com — найдет компанию в РФ

SaveRuData — покажет, полный адрес, имя, все из сервиса Яндекс Еда, СДЕК,
траты на еду за 6 месяцев, иногда работает через VPN

x-ray.to (r) — в утечек найдет имя, аккаунты, адреса, почту

@probei_ru_bot — даст ФИО, email, адрес регистрации, другие номера телефонов

@telegaphone_bot — найдет детали заказов в доставке еды, поиск в утечке

ресторанов 2-Берега и Вкусные Суши

bbro.su — найдет имя аккаунта на Авито и его объявления
приложения GetContact

@Zernerda_bot — ищет в двухсот слитых базах, находит адреса, имена, аккаунты и
много другого, бесплатный поиск после первого запуска бота

@declassified_bot — найдет почту, имена, адреса, авто

@detectiva_bot — выдаст вккаунт ВК, ОК, адреса, почту, утечк


#6 - Поиск по почте обидчика 

Использование электронной почты цели - удивительная вещь при выполнении doxing. 
Выполнение поискас помощью электронной почты, честно говоря, упрощает выполнение doxing. Вы можете использовать адрес электронной почты цели для множества целей.
Поиск Facebook -
Вы можете получить доступ к Facebook вашей цели по электронной почте. Это занимает несколько шагов и совсем не сложно.
1. Перейдите на страницу Facebook.com
2. Выберите опцию “Забыли свой пароль?”
3. В поле в середине страницы укажите адрес электронной почты получателя.
4. В нем должно быть указано имя цели, ее фотография, а иногда даже могут
быть указаны последние 4 цифры ее номера.
5. Используйте имя, которое они вам только что дали, и / или фотографию и поместите их в dox. Мы
воспользуемся ими позже.
Совет: Вы также можете использовать https://www.facebook.com/search.php?q = (электронная почта здесь), чтобы найти их Facebook.
Совет X2: Это также может работать с номером телефона, следовательно, ввод номера телефона также является операцией
Как говорилось раннее по фейсбуку можно найти много чего интернесного.

#7  - Поиск по фото
Иногда использовать изображение при копировании может быть сложно, но это может дать хорошие результаты. 
Есть два способа получить информацию из фотографий. Первый метод, который я объясню, заключается в использовании поисковой системы для поиска изображения в Интернете,
 а другой метод покажет вам, как получить exif-данные из изображения.
Поиск по изображению
Это похоже на поиск в Google, но вместо этого используется изображение. Есть два сайта, которые могут это сделать. 
Я перечислю их оба, но в своем объяснении я объясню, как использовать tineye. Они действительно эффективны и могут дать лучшие зацепки по целям. 
Допустим, у вас есть их фотография в Skype, и это та же самая фотография, которую они использовали на Facebook, как только вы выполните поиск по этой фотографии на одном из этих сайтов и найдете ее на их Facebook, 
все готово. У вас будет их название, которое может привести к тоннам информации.
Теперь давайте перечислим сайты, которые мы можем использовать для этого.
https://www.tineye.com / - “Проиндексировано 11,8 миллиардов изображений, и их число растет” https://images.google.com / - Это Google, черт возьми.


#8 - Поиск по Telegram

Telegago — найдет упоминание аккаунта в каналах, группах, включая приватные, а
так же в Telegraph статьях
lyzem.com — найдет упоминание аккаунта в группах и каналах
 @usinfobot — по ID найдёт имя и ссылку аккаунта, работает в inline режиме, введите
в поле ввода сообщения @usinfobot и Telegram ID
 cipher387.github.io — покажет архивированную страницу, даст 20+ прямых ссылок на
сайты веб архивы, поиск по ссылке на аккаунт
 tgstat.com — поиск по публичным сообщениям в каналах, найдет упоминание
аккаунта
 @SangMataInfo_bot — история изменения имени аккаунта
@TeleSINT_Bot — найдет группы в которых состоит пользователь
@creationdatebot — примерная дата создания аккаунта, бот принимает username,
для поиска по ID можно переслать сообщение от искомого пользователя
@MySeekerBot — поисковик по иранским каналам
TelegramOnlineSpy (t) — лог онлайн активности аккаунта, скажет когда был в сети
 Exgram — найдет упоминание аккаунта, это поисковая система на основе Яндекса,
поиск по 17 сайтам-агрегаторам, находит в Telegraph статьях, контактах, приватных и
публичных каналах с группами
 Commentgram — найдет упоминание аккаунта, поиск в комментариях к постам в
Telegram, работает через Google
 Commentdex — найдет упоминание аккаунта, поиск в комментариях к постам в
Telegram, работает через Яндекс
 @UniversalSearchRobot — по ID найдёт базовые адреса почты в сервисе Etlgr,
статус бана пользователя ботом ComBot, число блокировок, заблокированные
сообщения и дату начала бана, архивное имя и аватар аккаунта
 smartsearchbot.com — бот находит ФИО, бесплатный поиск не доступен для новых
пользователей
 @kruglyashik — канал с базой из 500K круглых видео-сообщений из русскоязычных
групп, в поиске по каналу введите имя пользователя или #ID123456789 где 123456789
ID аккаунта
@TgAnalyst_bot — находит номер телефона, старое имя аккаунта, логин, IP и
устройство, местами могут быть ложные данные, первый поиск без регистрации, если
её пройти, то сливается ваш номер телефона
глазбога.рф — найдет часть номера телефона, историю изменения ссылки
аккаунта
 @clerkinfobot — дает номер телефона
UsersBox.org — бот, по нику найдет номер телефона, бесплатный доступ 14 дней
после первого запуска бота
 @TuriBot — выдает по ID имя пользователя аккаунта Telegram, отправь боту
команду /resolve + ID
 @eyeofbeholder_bot — даёт интересы аккаунта, а платно выдаст историю
изменения имени, номер телефона, группы и ссылки которые публиковал
пользователь
 @regdatebot — выдаст примерную дату регистрации аккаунта, отправьте боту
числовой ID аккаунта или перешлите сообщение
 @QuickOSINT_Robot — найдет номер телефона, группы, id и ссылку аккаунта,
поиск по нику или ID аккаунта, всего 3 бесплатных запроса для новых аккаунтов
 @ki_wibot — найдет номер телефона в иранской утечке Telegram
 app.element.io (r) — найдет сохранённую копию аккаунта по ID, это аватарка и имя,
после регистрации, нажми на +, и выбери "начать новый чат", введи id в поиск
 @OffThisContactBot — найдет номер телефона, почту, имя, для поиска создай и
подключи свой тг-бот
 @Zernerda_bot — по ID находит телефон и ник аккаунта Telegram, бесплатный
поиск после первого запуска бота
 @declassified_bot — выдаст имена, телефон и почту
 @TeleScanOfficialBot — найдет группы в которых состоял пользователь, историю
изменения имени, номер телефона
Поиск через URL
 https://etlgr.me/conversations/123456789/subscription — найдет сохраненное имя
аккаунта и статус подписки на @etlgr_bot, можно подставить к ID @etlgr.com и получить
Email адрес, замени 123456789 на ID аккаунта
https://intelx.io/?s=https/t.me/USERNAME — найдет упоминание на сайтах и в слитых
базах, замените USERNAME на имя пользователя
Как узнать по ID пользователя Telegram какие приватные группы он создал?
Берем ID пользователя Telegram, например - 188610951
Переводим тут из текста в 32 битный hex. Получается 0b 3d f9 87
 То что получилось тут переводим в base64, получается Cz35hw, где w надо убрать,
т.е должно остаться первые 5 символов.
Составляем ссылку по которой будем искать.
Все приватные ссылки который создаст этот пользователь будут начинаться так:
t.me/joinchat/Cz35h — Это не полная ссылка в приватную группу, а только её начало
Поиск полной ссылки на группу
 Для DuckDuckGo и Yahoo
"joinchat/Cz35h..." — вставьте в поиск эту фразу заменив Cz35h на то что у вас
получилось
 Для Yandex
inurl:joinchat/Cz35h — вставьте в поиск эту фразу заменив Cz35h на то что у вас
получилось
 Для Google
"joinchat/Cz35h" — вставьте в поиск эту фразу заменив Cz35h на то что у вас
получилось
Через URL
https://web.archive.org/web/*/t.me/joinchat/Cz35h/* — найдет запись в интернет архиве,
замените Cz35h на то что у вас получилось
 https://web.archive.org/web/*/telegram.me/joinchat/Cz35h/* — найдет запись в интернет
архиве, замените Cz35h на то что у вас получилось



#9 - Куда выкладывать свои работы? 

Вы можете разместить dox на нескольких сайтах, чтобы человек был доступен всем в
Интернете, кто ищет его информацию. Лучше всего указать свой телеграмм  в dox, прежде чем публиковать их. Публикация dox может вызвать у объекта массу стресса из-за того, что люди
будут преследовать его. Ниже есть раздел о размещении dox с указанием сайтов
, где его можно разместить, чтобы другие могли увидеть его и использовать в своих интересах, например,
для продвижения своего dox или даже для преследования его. Вы помогаете другим получить dox объекта, они помогают вам преследовать его, беспроигрышная ситуация.

https://pastebin.com/
https://doxbin.com/

Прежде чем выкладывать работу, старайтесь как можно красивее оформить пасту.
====================
Dropped by
====================
Reason for Dox:
====================
*Personal Information:
Full Name:
Phone Number:
DOB:
Email:
Picture:
Alias:
====================
*Location Information
Address:
Area Code:
Zip:
City:
State:
Country:
Continent:
====================
*IP Information:
IP Address:
ISP:
Hostname:
VPN:
====================
*Social Media Accounts:
Twitter:
Facebook:
Steam:
Instagram:
====================
Dropped by
====================


#10 - Итог
 
Если же вы не нашли информацию в одном боте/сайте то ищите в другом, каждый бот/сайт пополняет каждый день базы данных
как вариант вам зайти тупо через некоторое время и попробовать заново. Не стоит завышать себя перед другими ведь если вдруг вас найдут, будет уже не до завышений самооценки, а люди на которых вы выебывались, будут смеяться xD

Всегда если же вы не можете найти информацию возьмите отдых а после же к вам на светлую голову придет мысль как можно найти, у меня так было не раз

Всегда думайте наперед ибо если же вы будете смотреть только вниз вы не сможете предвидеть обстановку которая вас ждет.


Мануал был написан Слайзом ( Slize Redwise ) cвязь со мной - @slizegod

Хорошего вам времяпровождения!
"""))            
            input("Нажмите ENTER...")

        elif choice == "44":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Мануал по OSINT (Open Source Intelligence) - Часть 1

Что такое OSINT? OSINT (Open Source Intelligence) — это процесс сбора, анализа и интерпретации информации из общедоступных источников для использования в разведывательных целях. В отличие от закрытых источников (например, разведывательных агентств или платных баз данных), OSINT включает в себя открытые ресурсы: интернет, публичные записи, новости, социальные сети, форумы и прочее.

1. Источники данных для OSINT:

Поисковые системы: Google, Yandex, Bing — это основные инструменты для начала поиска информации.

Социальные сети: Facebook, Instagram, Twitter, LinkedIn, Telegram и другие платформы, где можно найти личные данные, геолокацию, фотографии и сообщения.

Публичные базы данных: Регистры компаний, судебные записи, госзакупки.

Форумы и блоги: Специализированные форумы, Reddit, Quora, где можно найти информацию о людях, событиях или даже интересные инсайты.

Вики: Википедия и вики-сайты, которые содержат объективные и проверяемые данные.

Open Data: Открытые данные от правительств, научных организаций или крупных компаний.


2. Инструменты для сбора данных OSINT:

Maltego — мощный инструмент для визуализации связей между объектами.

Shodan — поисковик для обнаружения устройств, подключенных к интернету.

TheHarvester — инструмент для сбора информации о доменах, IP-адресах, e-mail и социальных сетях.

SpiderFoot — автоматизированный инструмент для анализа доменов и IP.

OSINT Framework — каталог онлайн-ресурсов для проведения OSINT.


3. Виды информации, которые можно получить через OSINT:

Данные о человеке: Имя, фамилия, телефон, адрес электронной почты, фотографии, местоположение.

Данные о компании: Официальные регистрационные данные, связи с другими компаниями, бухгалтерские отчеты, суды и дела.

Геолокация: Местоположение пользователей в социальных сетях, фотографии с GPS-метками, данные о перемещениях.

Сетевые данные: IP-адреса, домены, DNS-записи, логи доступа.

Новости и события: Последние события, видео, новости по интересующей теме.


4. Основные методы поиска:

Поиск по ключевым словам: Начните с поиска по ключевым словам или фразам в Google или других поисковиках.

Поиск по изображению: Используйте Google Images или TinEye для поиска изображений и их источников.

Поиск по меткам (hashtags): Ищите посты в социальных сетях, используя хэштеги.

Использование расширений браузеров: Например, расширения для поиска по изображениям или получения метаданных веб-страниц.

Мониторинг социальных сетей: Анализируйте профили и посты в Twitter, Instagram или Facebook с помощью инструментов для автоматизации (например, Twint для Twitter).


5. Законодательные аспекты OSINT: В различных странах существуют законы, которые регулируют сбор и использование открытой информации. Важно помнить о следующих принципах:

Конфиденциальность: Не стоит использовать информацию, нарушая чьи-то права на частную жизнь.

Законность: Все действия должны быть в рамках закона, избегайте незаконного доступа к данным.

Этика: Соблюдайте этические нормы при использовании информации, полученной через OSINT. """))            
            input("Нажмите ENTER...")
            
        elif choice == "45":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Мануал по OSINT (Open Source Intelligence) - Часть 2

6. Обработка и анализ данных OSINT:

После того как вы собрали данные, необходимо провести их обработку и анализ. Это ключевая часть работы OSINT-аналиста. Для этого можно использовать несколько подходов:

Фильтрация данных: Не все собранные данные полезны. Для начала нужно отфильтровать мусор.

Группировка: Сгруппировать информацию по категориям: личные данные, геолокация, связи, источники.

Кросс-сверка: Используйте несколько источников для проверки достоверности собранной информации.

Тематический анализ: Анализируйте информацию в контексте конкретной задачи (например, расследование инцидента, мониторинг угроз).


7. Использование анализа связи (Link Analysis): Инструменты, такие как Maltego, могут помочь выявить скрытые связи между людьми, организациями и событиями. Например, вы можете анализировать связи между учетными записями в социальных сетях или связями между IP-адресами и доменами.

8. Данные с геолокацией: Работа с геоданными имеет ключевое значение для некоторых типов OSINT-расследований. Например:

Фото с GPS-метками: С помощью метаданных (EXIF) можно извлечь данные о местоположении.

Twitter и Instagram: В постах и фотографиях могут содержаться геотеги.

Географический анализ: Программы типа QGIS или Google Earth могут помочь в более глубоком анализе геоданных.


9. Применение AI в OSINT: Совсем недавно, искусственный интеллект начал активно внедряться в области OSINT. Он может помочь в:

Обработке больших объемов данных: Использование машинного обучения для выявления паттернов в данных.

Анализе текстов и изображений: Применение технологий для обработки текста и визуальных данных, например, автоматическое распознавание лиц или объектов на изображениях.

Автоматизации поиска: Создание ботов, которые могут собирать информацию по определенным запросам в реальном времени.


10. Стратегии защиты от OSINT: Знание методов OSINT помогает не только расследовать, но и защищаться от возможных угроз. Вот несколько рекомендаций:

Минимизируйте информацию в социальных сетях: Не размещайте свои личные данные или фотографии с точной геолокацией.

Используйте псевдонимы: Применяйте различные ники в интернете для создания анонимности.

Защищайте свои устройства: Использование VPN, шифрование связи и надежные пароли помогают избежать утечек данных.

Мониторинг: Регулярно проверяйте свои данные в интернете, чтобы понять, что о вас известно.


11. Примеры успешного применения OSINT:

Рассследование инцидентов в кибербезопасности: Аналитики используют OSINT для выявления уязвимостей и угроз.

Применение в правоохранительных органах: С помощью OSINT расследуются преступления, находят потерянных людей или собирают доказательства.

Бизнес-разведка: Компании используют OSINT для мониторинга конкурентов или оценки рисков.


Заключение: OSINT является мощным инструментом для сбора информации и анализа, но для успешной работы важно знать не только технические аспекты, но и правовые и этические ограничения. Использование OSINT требует внимательности, умения анализировать большие объемы информации и соблюдения законов.
 """))                        
            input("Нажмите ENTER...")
            
        elif choice == "46":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
                 ЧТО НЕОБХОДИМО СДЕЛАТЬ

1. Удалите все Российские приложения. Все
говорят про сливы Гугла и Майкрософта, но
это - пендосы, а до русского человека ближе
дойдет рука русских силовиков. ВКонтакте-
собирает полную информацию о вас,
отслеживает ваши действия, и передвижения,
все переписки - хранятся, и при удалении
сообщения открою секрет, ты не удаляешь их
с ВКонтакте, просто появляется своего рода
функция "скрытия", а так удаленные
сообщения, и медиа контент доступны всем
пользователям при наличии ссылки . Не
желательно использовать Киви даже для
повседневных покупок, ищите аналоги
2. Используйте ВПН. Только отбросы
используют полностью бесплатные ВПН. ВПН -
вычислительная мощность, которая
обрабатывается на другом конце света.
Никому нет дела до того, чтобы с вами
"бесплатно" делиться этим ресурсом, по этому
бесплатные ВПН зарабатывают на сливе
данных. Так-же некоторые бесплатные ВПН
бывают опасней, чем отсутствие их в целом,
так как через него обрабатывается каждый
вас запрос, и к конченным впн сервисам
обратиться легче, а так-же информации на вас
будет если не больше, то одинаково что и без
ВПН.
Нормальные впн - Протон, NordVPN , у Протона
есть бесплатная версия. Там доступно всего 3
страны, однако это уже будет повышать
эффективность
3. Использовать Тор. Топ сам по себе не
анонимен, соответственно он бы не
развивался при полной анонимности, однако,
грамотная настройка приватности, и
включение ВПН вместе с тором - делает его
отличным браузером для поиска информации
4. Удалите все свои аккаунты из социальных
сетей. Посмотрите в интернете, как это
делается. Это вызовет явное подозрение, по
этому удалять необходимо не сразу, а
постепенно . Удаляйте любые упоминание,
попытайтесь стать на место обычного
пользователя, который не имеет никаких
связей с спец.службами - и постарайтесь
найти себя, ищите по номеру, ищите по ФИО,
ищите по вашему нику\юзеру. Если что-то
нашли - сразу удаляйте
5. Планка: "Телеграм". Задайте минимальную
планку для общения : приложения, с
приватностью не менее, чем телеграм. Из
этого следует, что вам необходимо удалить
такие средства общение, как Вайбер, Ватсапп,
и прочий шлак со своего устройства. С 2021 го
года, Ватсапп окончательно опозорился, и
теперь все ваши данные равносильно как и с
ВК- читаются, и полностью собираются.
Вообще никогда не трогайте сообщества
Марка(создатель фейсбука) - все они созданы
ради прибыли, и наживы над людьми
(Инстаграм, Фэйсбук, Мэссенджер) . Сама
компания часто подвергалась судебным
искам, по обвинению в сливе личных данных,
а сами хацкеры регулярно ищут там лазейки, и
используют их для вашего слива . НА ВАС
зарабатывают за просто так, благодаря вам -
кто-то сверху получает денюшку за просмотр
рекламы, или-же вас по умолчанию
используют для улучшения систем
рекомендаций, как-то так
6. Тик ток. Поставил бы его в 5 пункт, но он
отдельно заслуживает внимание. Помойка по
всем фронтам, которая кроме деградации
опять-же зарабатывает на использовании
твоих данных, которые могут передаваться в
высшие органы. Данные далеко не
ограничиваются "лайком" под клип, вовсе нет,
всё то что может собирать телефон с вас -
отчасти собирают и эти приложения, и
используя Тик Ток вы даете открытые двери в
ваш телефон. Так-же Тик Ток был добавлен в
Виндовс 11, а она в свою очередь является
провальной, и сливает даже снимок вашей
фотографии с того же ноутбука, даже когда вы
сами не включали камеру, якобы для
улучшение чего-то там
7. Снесите Виндовс. Виндовс - самая удобная
система, но она максимально смехотворна .
Официально, она стоит 300 долларов, и при
этом включает в себя огромнейший спектор
того, что можно на вас накопать. Понимайте,
что операционная система - это целая машина,
это не какой-то сайтик, или программка
(которые собирают минимальную
информацию о вас), нет, это по сути все ваши
действия, будь они в интернете, или за
какой-то игрой. Код Виндовс - полностью
закрыт, мало людей лишь знает, какие
масштабы хранит операционка. Тем не менее,
удалось выяснить такие вещи: виндовс
собирает на свои сервера абсолютно любую
клавишу, которую вы напечатали. Виндовс по
умолчанию интересуется, что вы гуглите для
заработка на более эффективной
продвижении рекламы, так-же Виндовс
собирает данные с вашей вебки, записывает
ваш микрофон, запоминает все посещения на
карте, и многое ещё. Банальная альтернатива -
Линукс . Линукс - свободное ПО, каждая
строка кода может рассматриваться вами, и
проверяться. Линукс не сложен в освоении, и
дистрибутивы полностью можно
настроить под себя, а так-же вам в свободных
"версиях" Линукса дают свободные ПО,
которые практически не собирают данных.
Тем не менее, дистрибутивы вроде Дебиана
или Убунту - не анонимны, их единственная
"анонимность" - проводя аналогию, это своего
рода "отсутствие камеры" в вашей квартире, а
так где находится ваша квартира, и прочее -
знать может каждый . По этому, есть
анонимные дистрибутивы(версии) Линукса:
Хвосты, Qubes Os, Gentoo, и это лишь то что я
могу вспомнить. """))            
            input("Нажмите ENTER...")   
            
        elif choice == "47":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
                         ЧТО НЕ СТОИТ ДЕЛАТЬ
                         
  1.Личные данные. Никак не давайте намека
на прежнего себя, старайтесь быть новым,
оригинальным. Вообще в таких случаях лучше
не писать в чате вообще, или как с последним
пунктом в предыдущем разделе - просто быть
чуть тихим, и спокойным
  2. Использование постоянной почты. Есть
временные почты, которые безопасны, и
никак не будут составлять ваш цифровой
например, например - @TempMail_org_bot ,
или веб-версия - https://temp-mail.org
  3. Использование Гет-Контакта. Полностью
сливное приложение, собственно их базы
данных номеров формируются за счёт
того, что вы устанавливаете его к себе на
телефон, а после разрешение доступа - оно
считывает все ваши контакты, и
добавляет к себе базу. Другими словами,
вы сами пополняете базу данных, и к
примеру из-за вас, при установке Гет
Контакта - ваш друг будет подписывать
под своим ФИО, или по каким-то
характеристикам, так как у вас в записной
книге было именно вот такое. Так-же
здесь можно обойтись другими приколами
- не записывать просто контакт под своим
именем, а запоминать номера, или делать
какое-то сокращение, которое точно бы не
спалило вашего друга, который вам
доверяет               
  4. Файлы . Не скачивайте файлы с
неизвестных источников, сидя на винде,
или на андроиде - вы легко можете
подхватить рандомный вирус удаленного
доступа
  5. Не скидывайте фотки файлом . Фотографии
хранят приколы, называемые "метаданными",
они могут содержать модель вашего
телефона, расширение камеры, дата
фотографии, местоположение фотографии,
время создания фотографии, диагональ, угол
наклона камеры, и прочие маленькие
параметры. По дефолту, в Телеграме
отображаются метаданные лишь в случае
отправки файлов, а не фотографий (да,
разница если что есть), по этому не делайте
этого, даже если это фотка вашего дома, или
созданная где-то в темноте - по
перечисленным параметрам ваш поиск будет
простым и не затруднительным, если вы один
раз случайно отправите фотку с вашей гео,
или любой другой информацией . """))            
            input("Нажмите ENTER...") 
            
        elif choice == "48":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
                        РЕКОМЕНДАЦИИ
                        
   
     0. Не ГУГЛИТЕ . Найдите через свободный
доступный браузер ссылку на Тор, после чего
используя его в связке с ВПН - ищите всё то,
что я описал выше, ибо даже так вы можете
быть подозреваемым в чём-то там
      1. Фэйк номер. Не так существенно иногда,
но настоятельно рекомендую юзать
фэйковый номер, который будет куплен за
15 рублей. Пример не самого "анонимного",
но качественного сервиса -
https://sms-activate.ru/en/           
Не желательно использовать номер своей страны, а так-же в любом случае делайте профиль закрытым
           2. Вечный ВПН . Чтобы ВПН не пропадал после
перезагрузки, на ПК и на телефоне вам надо
которая по Выключатель отключения, которая по дефолту есть в протоне. Так-же осмотритесь с рядом других настроек
        3. Поднятие серверов. Кроме ТГ есть
огромное количество анонимных сетей, но для
полной анонимности вам предлагают поднять
свои сервера, которые будут управляться
именно вами, без стороннего вмешательство.
Это - платно, но тем самым вы полностью
обеспечите себя. Рекомендуется так-же в этом
пункте: настроить прокси, создать сервер на
матриксе, и тому прочее """))            
            input("Нажмите ENTER...")   
            
        elif choice == "49":
            print(Colorate.Horizontal(Colors.green_to_white, f"""1. скачиваем proton vpn
все что будет делать дальше делаем через его покупные сервера, ОБЯЗАТЕЛЬНО КУПИТЬ ПОД@H_VioletПИСКУ, если делать без то вас могут найти
2. регаем временную почту через TempMail, вса покуп@H_Violetки оформляем через неё, полностью все, вообще везде
3. скачиваем виртуа@H_Violetлку Virtual xposed->x8sandbox->vphonegaga
4. в каждой виртуалке влючаем наш купленный proton vpn
5. сватать мы буд@H_Violetем именно через gmail
6. отправляем все сообщен@H_Violetия через gmail под proton vpn
------------
после каждого свата советую удалять все виртуалки и нигде не упоминать ваше дело
@H_Violet """))            
            input("Нажмите ENTER...")  
            
        elif choice == "50":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Что нам понадобится чтобы вызвать Гос службы на адрес человека?
1.Номер
2.Адрес
3.Новая сим-карта
4.Прокси
5.ВПН
6.Не детский голос
7.Или если у вас детский голос то меняйте в проге какой-то
8.Звоним в службу и говорим "Добрый день, случилась ситуация что меня оскорбил человек в интернете или просто была драка, он нанёс мне ущерб его адрес "Его адрес" "Его номер " "Его номер
9.Его заберают )
10.Если этот человек деанонер то заберают пк если вы сказали что этот человек сливает данные и делает заказы
11.Как узнать номер? Какого-то человека? Пробуйте ботов "Глаз бога" "Криптоскан" "Quick Osint bot" там же можно получить адрес иногда также есть другой способ достать адрес, например уже есть номер нам нужна база Яндекса или другой еды компании, то достоём базу и ищем по номеру, нашли по номеру в базе данных адрес и комментарий типо номер жены или кто заберёт заказ, и т.д
Достали адрес с базы данных
12.Вызывайте полицию нахуй 
13.Сносим обидчика

Теперь вы ультра мега сватер


Также есть способ для мелких если человек не имеет 18 лет

Анонимность как в первом способе

Второй способ для мелких

Звоним и говорим "Мне поступают угрозы с номера +79939383838  Адрес "Дом Пушкина 2 номер 3 подъезд 4 дом 18 этаж 8 квартира 67"
Или говорим "Данный человек собрал данные обо мне (докс) или (деанон)" Ему например 12 лет, т.д. Или что-то другое например "Данный человек поджог дом, покалечил сына, или что то другое, надо уметь пиздеть, запомните надо изменить голос, будьте анонимны сватеры!




Просьба мануал не сливать!
Сольешь пизды получишь.

Третий способ





Идёшь и покупаешь номер телефона от 3х лиц, они обычно дешовые и понадобится старый телефон который потом ты выбрасишь ведь по нему тебя могут вычислить. Данные которые ты получил вбиваешь на листок или ещё что-нибудь. Выезжаешь в тихое место ведь в людном месте тебя по камера ФСБ могут вычислить, и спец службы, и делаешь звонок. В целом желательно можно вшить ВПН к городу жертвы, или нахуярить себе прокси, Ещё нужно изменить голос через оператора, или другим иным способом, Возможно в какой-то степени есть какие-то сложности, но всё главное для безопасности!

Четвертый способ


Мануал по свату
1.Получите адрес дома ваших жертв.
2.Когда вы найдете адрес своей цели, поищите не чрезвычайную ситуацию для их округа или города.
3. как скрыть свою личность при звонке:Вы можете использовать textnow
(текст теперь работает только для Канады, США и Пуэрто-Рико),firertc
и другие приложения (при использовании убедитесь, что они подключены к сети VPN или общедоступной сети Wi-Fi)
4. при звонке измените свой голос, сделав это самостоятельно или используя сменщик голоса
5. как вызвать большой отклик при вызове заложников, а бомбы обычно работают, но делают
это убедительно

Ссылаясь на номер 3
1. настраивая текст сейчас, убедитесь, что вы не используете свой адрес электронной почты для регистрации
2. использовать электронную почту, например temp-mail.io temp-mail.org или yopmail.com


ВТОРОЙ МЕТОД МЕТОД ФБР
1. Получите адрес дома ваших жертв.
2. когда вы найдете адрес, сделайте номер с помощью textnow или firertc refer
наверх
3. при звонке убедитесь, что находитесь в сети VPN или публичной сети Wi-Fi
4. при звонке измените свой голос, сделав это самостоятельно или используя сменщик голоса
5. при звонке скажите, что человек бомбит школу
что-то подобное могло сработать
5. № ФБР 1202-324-3000




 """))            
            input("Нажмите ENTER...")   
            
        elif choice == "51":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Для сноса чужого телеграм канала, вам стоит ознакомиться со списком причин блокировки чужого канала Телеграмм.


•Пропаганда насилия
Из той-же серии – призывы к терроризму
•Незаконное распространение музыкальных произведений (песен, саундтреков и альбомов)
•Порнография
Из той-же категории контент эротического содержания
•Неоднократный спам (более 3-ех раз)
•Постоянное использование ботов в чате
телеграмм использование ботов
•Постоянная навязчивая самореклама в чате
•Использование на канале исполняемых файлов (АРК или EXE)
Из той-же категории – не делайте ссылки на исполняемые файлы. Две последние категории нежелательны из-за возможности быть замаскированным вирусом.
•Нарушение авторских прав. Здесь чаще всего «попадают под раздачу» каналы с загруженными фильмами. Ссылка на ролик ЮТУБ здесь вам в помощь.
Модераторы Телеграмм очень подозрительно относятся к каналам или чатам, где используется общение не на языке канала. То есть, если канал русскоязычный, а вы там общаетесь на условно китайском языке, то это уже повод поставить канал в серый список. Модераторам и администраторам Телеграмм такие каналы очень трудно, а иногда и невозможно модерировать.
•Ну и напоследок, не приветствуется массовое использование стикеров и гифок. Здесь тоже все просто, cтикеры или картинки с жестами понимаются в разных культурах по-разному. И если где-нибудь в России этот стикер будет означать приветствие, то где-нибудь в республике Зимбабве этот же стикер будет означать угрозу насилия.
Отдельной темой и поводом для блокировки стоит реклама услуг финансового характера.

•Любой аккаунт может быть заблокирован. Если использует принципы финансовых пирамид, так называемые схемы Левина Понци. То есть, клиентов заманивают высокими процентами или дивидендами, но полученные деньги не вкладываются, а с них выплачиваются проценты старым клиентам.
•Различные партнерские программы не приветствуются модераторами Телеграмм. То есть те аккаунты. В которых основная цель: получение процентов от каждого нового клиента компании, на которую стоит ссылка с аккаунта, могут попасть в вечный банн.
•Реферальные схемы, где есть посылы или обещания бесплатных денег или валюты.
•Ставки или схемы инвестиций любого рода
•Про «обнажёнку» и порнография я уже говорил
•Оскорбления и унижения группы людей. Группы людей могут быть разными, объединены по расовому признаку, религии, полу, возрасту, национальности и пр.
•Жестко модерируются аккаунты в которых выявлены факты притеснения
Канал блокируется, если в нем есть факты разглашения чужих личных данных. Это могут быть: ФИО, фото, адреса проживания и номера телефонов.


Дальше схема действий проста. Пишем модераторам на эту почту abuse@telegram.org. И излагаем конкретно факты нарушений правил телеграмм чужого канала. По опыту. Одной жалобы будет совершенно недостаточно для блокировки аккаунта. Создаём много левых почт, и пишем жалобы с них разделяя их по времени. Если таких жалоб будет несколько (число зависит от аккаунта). То в течении нескольких недель аккаунт может быть заблокирован.

Полной гарантии блокировки конечно нет. Но то что канал уже попадёт под наблюдение –это точно. И при последующих нарушениях с таким каналом точно не будут церемонится. В одиночку заблокировать канал Телеграмм достаточно трудно, но возможно."""))            
            input("Нажмите ENTER...")     
            
        elif choice == "52":
            print(Colorate.Horizontal(Colors.green_to_white, f"""by reyzov

Что такое сваттинг?

Сваттинг это:

Тактика домогательства, которая заключается во введении полиции в заблуждение так,
чтобы по адресу другого лица выехала штурмовая полицейская группа.
Это делается с помощью фальшивых сообщений о серьёзных правонарушениях, 
такие как закладки бомбы, убийство, захват заложников или другие подобные инциденты.

ALERT!Если вы живете в России,то не советую делать сват по России во избежании бутылки

Какие бывают способы исполнения сваттинга и его виды?

Способы исполения:
1.Телефония(skype)
2.Email(gmail,proton,yandex)

Какие бывают виды сваттинга?
Всё зависит от возраста жертвы,если вы не делаете просто эвакуацию.
т.e.
1.Опекой(меня бьют ,маму щас зарежут нахуй)
2.Мunup0BaHue(бомба в здании, спасайте задницы)
3.Вызов служб(пожар,газовая утечка)
4.Сказать что человек деанонер или сватер(заберут пк)
5.Угрозы от человека(типо этот хочет поджечь мой дом)
и т.д.

Стоит заметить,что нам нужны ДАННЫЕ жертвы,для разных способов они варьируются от номера+фио ,до просто номера

Как находить данные я учить не буду,но,помните,что если вы хотите кого-то сватнуть,то глаз бобика вам может и не помочь

                                                 ПРАКТИКА
Буду разбирать сначала способ сватом гмаилом,расскажу что да как,другие сервисы вроде протона иногда не отправляют,поэтому их не советую

1.Скачиваем Tor Browser(https://torproject.netcologne.de/ru/download/)
2.Скачиваем Mullvad VPN(https://mullvad.net/ru/download/vpn/windows),ключи можно найти на раздачах лолзгуру
3.Включаем прокси(Делаем следующее: Кликаем “Пуск” и открываем “Параметры”. Выбираем раздел “Сеть и Интернет”. Открываем пункт “Прокси-сервер” и перетаскиваем ползунок на “Вкл.”; Вводим IP-адрес и порт промежуточного сервера)
Бесплатные прокси можно найти на сайте: https://ru.proxy-tools.com/proxy?ysclid=llm9xarqgp366599394
4.Настраиваем Mullvad и Tor(поищите в инете хуле)
5.Создаем почту Гмаил с ФИ жертвы или с его именем,прим:(andreysmirnov@gmail.com,andreyukraine2008@gmail.com)
6.Выберите способ исходя от возраста жертвы и как вы хотите его наказать(лучше всего минирование)
7.Ищем под это все здание(или его адрес если выбрали 3 пункт),желательно искать Больницу с почтой,например: (киев,городская больница номер 4,clinik4@health.kiev.ua,адрес:03110, Киев, ул. Соломенская, 17.)
8.Ищем почты СМИ(не отправляйте в СБУ или ФСБ такие письма,это бесполезно,отправьте на почты мвд и СМИ),почты гос органов Украины тут:(https://ua.spinform.ru/adr.html?ysclid=llma3xhgyy21057100) или в резерве почт в тг(в поиске можно найти),почты сми украины:(http://www.ukr-biz.net/directory/17.htm)
9.Делаем текст и список почт,текст думаю все знают как делать,но самое главное обходить банворды прим:(3amuHup0Baл,Teppakt,3aл0жHuku и тд)
10.Рассылаем текст по почтам и готово!

Способ телефонией
1.Качаем муллад и делаем прокси как в первом способе
2.Качаем скайп(https://www.skype.com/ru/get-skype/)
ДЛЯ ЭТОГО СПОСОБА НУЖНЫ ДЕНЬГИ НА СКАЙП(700 рубликов где-то)
3.Покупаем сабку на номера мобильные+стационарные на месяц по какой стране будем делать
4.Качаем изменитель голоса(https://www.voicemod.net/) и настраиваем его(в ютубе есть ролики)
Проверить работает-ли войсмод можно тут:(https://online-voice-recorder.com/ru/?ysclid=llmaees9xc461425512)
5.Ищем номер сбу или мвд города жертвы и говорим подготовленный текст.
ПРОФИТ.

Мануал сделан @semerkin_swater
При распространении мануала указывайте автора!"""))            
            input("Нажмите ENTER...")  
            
        elif choice == "53":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Этот мануал был написан лично мной.
Для связи со мной:@SearchTooMe - Канал кибербезопасность / За слив дам пизды.
------------------------------------------------------------------------------------------------------------------------------------------------
Итак, начнем:

- Пробив по лицу:
• https://pimeyes.com/en
• https://www.digikam.org/
И еще findclone ну там платка но пиздатая тема.
------------------------------------------------------------------------------------------------------------------------------------------------
- Пробив по почте:
• https://tools.epieos.com/email.php - лучший сервис для пробива gmail почт, можно найти адрес, номер, аккаунты телеграм.
• https://www.emailsherlock.com/emailsearch
• https://emailrep.io/ 
• tg @last4mailbot - Может найти номер телефона по почте.


------------------------------------------------------------------------------------------------------------------------------------------------

- Пробив по IP:
• http://www.ip-score.com/
• https://www.securitylab.ru/software/274763.php - сканер безопасности для выявления в интернет-, интранет-
 и экстранет-сетях уязвимостей в установленных сетевых системах. 
Сканирует не только OS Windows и операционные системы Unix (Solaris, Linux, *BSD etc...),
 роутеры, файрволы и системные устройства, но и проверяет уровень безопасности
 NetBIOS, HTTP, CGI и WinCGI, FTP, DNS, уязвимость DoS, POP3, SMTP, LDAP, TCP/IP, UDP, реестра, 
сервисов, паролей, MSSQL, IBM BD2, Oracle, MySQL, PostgressSQL, Interbase, MiniSQL и многое другое.

------------------------------------------------------------------------------------------------------------------------------------------------

- Пробив по номеру телефона:
• SpravkaRU.Net
И добавлю радарфон но епта ссылки нема я потерял_)



 Ресурсы для Вконтакте:
 • Vk-photo.xyz дол­жен искать час­тные фото акка­унта, 
но база сай­та весь­ма мала, хоть там порой и попада­ются инте­рес­ные матери­алы
, вро­де фоток с дру­гими лич­ностя­ми или в мес­тах, информа­ция о которых пред­став­ляет инте­рес.
220vk - хелпует нормас.



- Сайты, которые находят информацию по конкретному запросу:

•. Search Carrot → кластерная поисковая система, определяет объекты или категории, связанные со словом в поисковом запросе.
• Board Reader → поисковик по закрытым форумам.
• Search Code → поиск по коду в открытых репозиториях.
• Swiss Cows → семантическая поисковая система.
• Intelx → найдет адреса электронной почты, домены, URL-адреса, IP-адреса, CIDR, адреса биткойнов, хэши IPFS и т.д.
• Public WWW → поиск по коду исходной страницы, вы можете искать по никнеймам, почте, трекерам, кошелькам, адресам веб-сайтов и т.д.
• Psbdmp → поиск по pastebin.
• Kribrum → поисковая система в социальных сетях.
 
​- Узнаем ФИО владельца электронной карты:

• bincheck.io
• binchecker.com
• bincheck.org
• freebinchecker.com
• binlist.io
• binlist.net

- Пробив, долги, данные:
• http://fssprus.ru/iss/ip/ (Получим задолженности субьекта).





------------------------------------------------------------------------------------------------------------------------------------------------



Для начала начнем с простого конечно вы все слышали о таком сайте как 220VK через который можно узнать кого скрывает твоя жертва и не только...

Следующее что мы тебе советуем это купить подписку на VK.watch (очень полезный сайт через который можно дохуя чего узнать по типу смененных данных пользователя)


Если на странице есть настоящее ебло пользователя ,но ты сомневаешься в его валидности советую пойти на сайт "https://findclone.ru/" ,на нем ты сможешь 100% убедиться валидное имя или нет.(конечно сайт не бесплатный но можно схитрить,создаая новый аккаунт вам все время будет доступно сделать 1 пробив по лицу)
,но если вдруг ты не можешь оплатить подписку на этом сайте то есть его бесплатная копия не такая ахуенная но все же, "https://search4faces.com/"

Есть и такие ебучие особи которые закрывают свои страницы но тебе просто необходимо чекнуть его друзей,для таких ушлепков создан сайт "https://online-vk.ru/"

Иногда ты думаешь как узнают твои соц.сети которые ты не палил так вот ,это благодаря сайту "https://checkusernames.com/" на данном сайте вы можете без проблем найти аккаунты личности зная его ник.


Если ты хочешь узнать IP-adress человека,о блять просто кинь ему ебучий iplogger.org,но если ты уже нашел его айпишник и тебе нужно узнать где он проживает тебе помогут данные сайты:

• https://whatismyipaddress.com/
• http://www.ipaddresslocation.org/
• https://lookup.icann.org/
• https://www.hashemian.com/whoami/

https://rusfinder.pro/vk/user/id********* (здесь цифровой ID) - узнать данные указанные при регистрации аккаунта ВКонтакте.
Если ничего старого нет, обновите страницу и быстро делайте скрин области. С новорегами не работает.

http://archive.fo - просмотреть web-архив страницы. Редко помогает.

(Ну все это были способы для того что бы найти не аноним чела,теперь приступим к самому сладкому)

Предупреждаю без слитой информации на анонимного пользователя вы с шансом 90% нихуя не найдете,можете мне не писать в личку прл это.

Для начала советую как правило пробить его ники на следующих сайтах(Старые или нынешнии ID в соц.сетях,ники в играх и т.п.)

* https://namechk.com/
* https://checkusernames.com/
* https://www.peekyou.com/username - по ник-нейму выдаст почты не всегда валидные

Далее я советую вам поискать в сервисам по поиску информации в ok 

* https://ok.ru/search?st.mode=Users&st.vpl.mini=false - лучший способ, это искать в поиске через друзей он тут самый доступный
* https://online-vk.ru/ - покажет скрытых друзей 
* https://ok.city4me.com - шпион для данной соц сети

Если у тебя есть почта твоего обидчика ты можешь пробить ее на наличие слитых паролей ip или же номера телефона на данном сайте

*lampyre.io
Но есть версия попроще и бесплатных пробивов доступно тоже больше это бот в телеграмме @QUICK_Osint_bot

Так же если страница жертвы созданна 15-17 года то с шансом 70% что она есть в базе данных, проверить можно это в телеграмм боте @EyeGodsBot(так же по малейшей информации бот может вывести на настоящие,старые аккаунты в различных соц.сетях)

Или же я посоветую тебе найти даже по микроскопической инфе такое что не найдут хуесос в погонах.

*intelx.io -Поиск осуществляется по URL,IP,почты,номер телефона,некоторая информация осуществляется по поиску в даркнете


Если же ты узнал IP-adress человека и хочешь его побесить то ты можешь ему устроить бесплатную DDos аттаку:

* Сайт - https://quezstresser.in
 В первой строчке "Target IP" - пишем IP жертвы.
 Во второй строчке "Target Port" - пишем 80.
 В третей строчке "Time" - пишем 300. (300 = 5 минут).
 В четвёртой строчке выбираем "NTP".
 Максимальное время DDOS - 5 минут, тоесть 300 секунд. Больше ставить не получится.
 Если будет какая либо ошибка , на подобие "15/15", пробуйте ещё раз и ещё раз, пока не получится.

Дада,ты видел сверху довольно не мощные пробивы по номеру телефона и прочей хуйне,но я могу тебе скинуть кое что помощнее 

* https://www.peekyou.com/username - по ник-нейму выдаст почты не всегда валидные
* https://www.peekyou.com - по таким данным как (ФИ) выдаст возможные аккаунты почты и т.д
* https://tineye.com - проверяем фото конфидициальное или нет
* https://dehashed.com - сервис поиска по различным данным
* https://github.com/sundowndev/PhoneInfoga - мощный пробив по номеру
* https://github.com/sherlock-project/sherlock - мощный пробив по ник-нейму
* https://github.com/s0md3v/Photon - сильный кравлер, большая выгрузка информации с сайта

Пробивы по почтам:
* https://ghostproject.fr
* https://account.lampyre.io/data-lookup


Так же ебать я тебе солью ахуенных телеграмм ботов:

* @phone_avito_bot - пробив по номеру, выдаст Avito
* @Quick_OSINT_bot - различные серверные пробивы по данным критериям (почте, номеру, номеру машины, ip-адресу, паспортным данным, по Telegram и т.п)
+analog @EyeGodsBot
+analog @AvinfoBot
* @HowToFind_bot - бот который может посоветовать различные Telegram каналы спомагательные для деанонимизации
+analog @osint_mindset
* @deanonym_bot — с помощью данного бота можно узнать номер любого пользователя Telegram
* @getfb_bot - при помощи номера сможем найти аккаунт в Facebok
* @GetYandexBot - пробив по почте выдает различные данные
* @GetPhone_Bot - пробив по номеру выдает различные данные
* @LBSE_bot - пробив по номеру мы получим (mcc, mnc, imci, msc)
* @InfoVkUser_bot - производит анализ профиля vk.com
* @usersbox_bot - пробив по номеру
* @maigret_osint_bot - выдает ссайты где пользователь регистрировался с указанным ник-неймом
* @packetSkamer_bot - поддельные скрины перевода денег различные системы переводов
* @mnp_bot - пробив по номеру
* @xinitbot - бот который напичкан многими функциями связанными с телефоном
* @egrul_bot - пробив по критериям (паспортные данные, фио) покажет бизнесные цели
* @info_baza_bot - найдет в базе данных, бот на украинском
* @numberPhoneBot - кто звонил, пробив по номеру
*@BusinkaBusya - хороший селлер, рекомендую (Пробив Solaris)
*@GetGmail_bot - Полезнейший инструмент, способный узнать ФИ по почте Gmail
*@AvinfoBot - помогает узнать владельца автомобиля по госномеру, проверить историю продажи автомобиля, проверить автомобиль на участие в ДТП и многое другое.

Так же ты можешь по IP-adress'у узнать что устанавливала твоя жертва по типу порнхаба и другой хуеты:

* https://iknowwhatyoudownload.com/ru/link/

Позиционирует себя как поиск, обеспечивающий максимальную приватность и конфиденциальность. Система не собирает никаких данных о пользователе, не хранит логи (нет истории поиска), использование файлов cookie максимально ограничено, браузер выдаст вам всю самую подробную информацию о том что вы ищите, работает оцень быстро, так же рекомендую.

* https://duckduckgo.com

Три самых популярных форума-библиотек которые ты можешь юзать для саморазвития в этой сфере и ее ближних сферах(взлом, пробив, дрочка на камеру)
*https://xss.is/
*http://probiv.one/
*https://rutor.wtf/

Если вам нужно найти номер человека ва потребуется:
1.Спросить — один из самых действенных способов.Можно спрашивать как у самой жертвы(мол товар купить или на лечение кинуть), так и у ее друзей, на которых у вас уже есть инфа для шантажа.
2.Попросить донашналертс(если жертва юзает Qiwi Nickname)
3.https://rutor.wtf/threads/probiv-socialnyx-setej-poisk-akkauntov-po-nomeru-telefona.13273/

Обширное количество методов поиска дополнительной информации
Номер телефона - @clerkinfobot (getcontact)
Так же есть один из мощнейших пробив сейлер

https://rutor.wtf/forums/detektiv-kolombo-probiv-po-vsem-strukturam.177/

Если ты каким-то раком достал паспортные данные какого-то животного то ты можешь проверить его валидность вот тут -> http://services.fms.gov.ru/info-service.htm?sid=2000
После чего достаем ИНН (Если узнали паспортные данные) -> https://service.nalog.ru/inn.html 


Навыки построения графа взаимосвязей
https://codeby.net/threads/maltego-instrukcija-dlja-instrumenta-razvedki-na-osnove-otkrytyx-istochnikov.67691/

Основой для будущего сканера было решено выбрать крупную базу данных уязвимостей Vulners от российских разработчиков. Этот проект включает в себя обширную коллекцию сведений об уязвимостях систем на базе Linux и предлагает RESTful API для удобного взаимодействия с последней. Одной из ключевых особенностей проекта является возможность проведения «удаленного» аудита безопасности Linux-хоста.

https://vulners.com/vscanner/scan


Далеко ходить не потребовалось — сам агрегатор предлагает ряд программных продуктов для упрощения работы со своей БД, в том числе:
vulners-scanner – Proof-of-Concept аудита безопасности Linux, демонстрирующий возможности API Vulners.com;
vulners-agent – агент для Linux-сервера, позволяющий проводить сканирование по планировщику cron;
nmap-vulners – NSE-скрипт для Nmap, позволяющий выявить угрозы безопасности, исходя из информации, полученной от сервисов, которые запущенны на открытых портах исследуемого хоста;
api – средство разработчика, представляющее из себя враппер веб-API Vulners.com в виде подключаемого модуля для Python (доступен для установки через PyPI).


Ошибка <h1>503 Bad Gateway</h1> на DonatePay/DonationAlerts.
Если пользователь использует донат-сервисы, вы можете попытаться узнать его номер сделав ошибку через просмотр кода элемента на странице оплаты. Работает по сей день.

https://zhuteli.rosfirm.info - одна из баз данных адресов. Многих городов нет, ищем по районному центру



1. Имя (без фамилии) + город (районный центр/поселок/село) + дата рождения (число).
2. ИФ + город (путем отсеивания результатов).
3. Город (районный центр) + полная дата рождения.
4. Поиск родственников по фамилии (если известен возраст, в фильтрах ставим возраст ОТ по арифметической формуле 18+(полный возраст жертвы), далее поиск в друзьях странных имен, ников (если не удается найти старые страницы по настоящим данным).
5. Идентификатор канала на YouTube в Google (позволяет узнать старое название канала).






Советик от меня цепляйтесь за все ебанна рот.
Человек где-то но допустит ошибку...это человеческий фактор ищите капайте епта)))
Давайте мужики, всем удачи)."""))            
            input("Нажмите ENTER...")       
            
        elif choice == "54":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Как остатся анонимным?

Для начала,надо принимать не киви ,а Д/А ( DonateAlerts ) ,от туда скидывать на киви.

Советую покупать на сайтах страницы за 1 рубль т.к от рубля нечего не потеряете,а номер который привязан на страницу - не ваш.

Если на странице когда-то были одноклассники,то они отображаются на сайте 220vk.com.

Советую вам ставить фейковое Ф.И, это усложнит работу.

Матере поставьте девечью фамилию,а свои старые страницы удалите.

Очень хорошая вещь - диз инфа к примеру все друзья должны вас называть к примеру Миша 
,все подумают ,что это реальное имя.

Отключите геолокацию ( Если вы включите, то там будет писаться ваш адрес тем самым вас могут вычислить + найти вашу школу )

Так-же не советую вам менять с реальной фамилии на фейквую т.к в "Яндексе/google" можно посмотреть изначальную.

Также помимо DonationAlerts можно принимать qiwi-копилку.

Ссылка на канал - @onion_soft
"""))            
            input("Нажмите ENTER...")    
            
        elif choice == "55":
            print(Colorate.Horizontal(Colors.green_to_white, f"""manual выполнен для overx

писал воид

ТЕРМИНЫ

Деанон – (ударение на «о») это срыв покровов анонимности с автора какого-нибудь блога в этих ваших интернетах. Само слово «деанон» является обрезанной версией слова «деанонимизация», которое означает лишение анонимности и раскрытие чьей-либо, ранее скрытой, личности.

Доксинг – это раскрытие в сети идентифицирующей информации о ком-либо, такой как настоящее имя, домашний адрес, место работы, номер телефона, финансовая и другая личная информация. Впоследствии эта информация распространяется без разрешения жертвы.

Начнем с основы intext , как она работает?

intext:internetreference 
intext:internetreference site:telegram.web (сайты могут быть любые , я взял в пример)

1. Дает упоминание в интернете этого никнейма который я указал в примере.
2. Дает упоминание никнейма на указанном сайте.

основные боты для докса

@clerkinfobot
@UniversalSearchRobot
@UsersSearchBot
@getcontact_real_bot
@Quickosintfast_bot
@telesint_bot
@kolibri_osint_bot
@UsersSearchBot
@usinfobot
@Doufucbot
@Douccuiccbot
@detectiva_bot
@PasswordSearchBot
@UniversalSearchBot
@StealDetectorBOT
@last4mailbot
@info_baza_bot
@get_caller_bot
@dosie_Bot
@eyeofbeholder_bot
@clerkinfobot
@TeleSINT_Bot
@fuckeddb
@freedomf0x
@usinfobot
https://saverudata.online/
https://r23.fssp.gov.ru/iss/ip
https://legalacts.ru/
https://www.nalog.gov.ru/
@kolibri_osint_bot
@Qsta_bot
@clerkinfobot
@clerkinfobot
@get_caller_bot
@Getphonetestbot
http://avinfo.guru
http://getcontact.com
http://mirror.bullshit.agency
http://numberway.com
http://mirror.bullshit.agency
http://mysmsbox.ru
http://phoneInfoga.crvx.fr
http://spravnik.com
http://teatmik.ee
http://truecaller.com


https://saverudata.online/ - Пробив по номеру, фамилии, почты может найти адрес/имя/фамилию и прочее. Так-же проверяет на базу клиентов ВТБ.
https://r23.fssp.gov.ru/iss/ip (включая под-ресурсы данного гос. ресурса)
https://legalacts.ru/ (включая под-ресурсы данного гос. ресурса)
http://www.consultant.ru/ (включая под-ресурсы данного гос. ресурса)
https://docs.cntd.ru/ (включая под-ресурсы данного гос. ресурса)
https://egrul.nalog.ru/index.html (включая под-ресурсы данного гос. ресурса)
https://nalog.ru/ (включая под-ресурсы данного гос. ресурса)
https://www.nalog.gov.ru/ (включая под-ресурсы данного гос. ресурса)
https://www.tinkoff.ru/ (включая под-ресурсы данного ресурса)
https://zachestnyibiznes.ru/ (включая под-ресурсы данного гос. ресурса)
@usersbox_bot - Хороший бот, аналогичен сайту выше, но баз там больше, и найти информации так-же можно больше. (Можно получить бесплатный премиум через меня, если надо скажи. А так там пробник на 7 дней дают)
@maigret_osint_bot - Пробив по никнейму
@kolibri_osint_bot - Идеальный бот, аналог ГБ. Бесплатно раздают на время бета теста (3 месяца вроде).
@glazIX_bot - Стандартный глазик, зеркало от пидорасов извини, своё лень было делать.
@Qsta_bot - Хороший бот, правда платный. Но дают пару запросов, я лично чекаю сообщения со страницы вк в нём в группах и т.д. для компромата, охуенный короче бот
@getcontact_real_bot - Бот для пробива по GetContact (5 запросов в день :( )
@ibhldr_bot - Пробив по чатам ТГ
├ @clerkinfobot — бот берет данные из приложения getcontact, показывает как записан номер телефона в контактах
├ @dosie_Bot — как и в боте uabaza дает информацио о паспорте только польностью, 3 бесплатные попытки
├ @find_caller_bot — найдет ФИО владельца номера телефона
├ @get_caller_bot — поиск по утечкам персональных данных и записным книгам абонентов, может найти ФИО, дату рождения, e-mail
├ @get_kolesa_bot — найдет объявления на колеса.кз
├ @getbank_bot — дает номер карты и полное ФИО клиента банка
├ @GetFb_bot — бот находит Facebook
├ @Getphonetestbot — бот берет данные из приложения getcontact, показывает как записан номер телефона в контактах
├ @info_baza_bot — поиск в базе данных
├ @mailsearchbot — найдет часть пароля
├ @MyGenisBot — найдет имя и фамилию владельца номера
├ @phone_avito_bot — найдет аккаунт на Авито
├ @SafeCallsBot — бесплатные анонимные звонки на любой номер телефона с подменой Caller ID
Ресурсы для пробива
├ lampyre.io — программа выполняет поиск аккаунтов, паролей и многих других данных
├ avinfo.guru — проверка телефона владельца авто, иногда нужен VPN
├ fa-fa.kz — найдет ФИО, проверка наличия задолженностей, ИП, и ограничения на выезд
├ getcontact.com — найдет информацию о том как записан номер в контактах
├ globfone.com — бесплатные анонимные звонки на любой номер телефона
├ mirror.bullshit.agency — поиск объявлений по номеру телефона
├ mysmsbox.ru — определяет чей номер, поиск в Instagram, VK, OK, FB, Twitter, поиск объявлений на Авито, Юла, Из рук в руки, а так же найдет аккаунты в мессенджерах
├ nuga.app — найдет Instagram аккаунт, авторизация через Google аккаунт и всего 1 попытка
├ numberway.com — найдет телефонный справочник
├ personlookup.com.au — найдет имя и адрес
├ phoneInfoga.crvx.fr — определят тип номера, дает дорки для номера, определяет город
├ spravnik.com — поиск по городскому номеру телефона, найдет ФИО и адрес
├ spravochnik109.link — поиск по городскому номеру телефона, найдет ФИО и адрес
├ teatmik.ee — поиск в базе организаций, ищет номер в контактах
└ truecaller.com — телефонная книга, найдет имя и оператора телефона

Пробив через Восстановление доступа
├ ICQ — icq.com/password/ru
├ Yahoo — login.yahoo.com/?display=login
├ Steam — help.steampowered.com/ru/wizard/HelpWithLoginInfo
├ Twitter — twitter.com/account/begin_password_reset
├ VK.com — vk.com/restore
├ Facebook — facebook.com/login/identify?ctx=recover
├ Microsoft — account.live.com/acsr
└ Instagram — instagram.com/accounts/password/reset


"ПРОБИВ ПАСПОРТА"
https://www.reestr-zalogov.ru/search/index - Пробив по ФИО, может выдать паспорт если есть кредит с залогом. Так-же можно пробить через VIN.


NNB - @The_NoNameBot (дает полезную инфу) 

https://eyeofgod.space/ (Актуальный глаз бога искать здесь, ибо его вечно банят) 

@EmailPhoneOSINT_bot - Получаем ФИ, почту, регион 

@phone_avito_bot - проверяем авито акич

@getcontact_real_bot - работу гет контакта, знаете

@usinfobot - получаем тг айди 

@TgAnalyst_bot - если акич попал в бд телеграмма, выдаст айпи, номер, девайс

@UniversalSearchBot - по мануалу который даст бот после пробива по номеру, узнаете вк аву

LBSG.net, Collection 1, StockX.com, 8Tracks.com, Wishbone.io, DailyQuiz.me, Zynga.com, Wattpad.com

databases.today — архив баз банков, сайтов, приложений

@basetelega — утечки, компании, парсинг открытых источников

ebaza.pro (r) — есть email, телефонные номера, физ. лица, предприятия, базы доменов и другие

hub.opengovdata.ru — Российские базы статистики, росстата, архивы сайтов, финансы, индикаторы, федеральные органы власти, суды и т.д

@freedomf0x — утечки сайтов, приложений, гос. структур

@leaks_db — агрегатор публичных утечек

@BreachedData — утечки сайтов, приложений, соц. сетей, форумов и т.д.

@opendataleaks — дампы сайтов школ, судов, институтов, форумов по всему миру

@fuckeddb — дампы сайтов, приложений, социальных сетей, школ, судов, институтов, государственных ресурсов, форумов по всему миру

@gzdata — китайские сайты и приложения 

AVinfoBot (r) – делает отчет где есть данные из социальных сетей, недвижимости, автомобилей, объявлений и телефонных книжек. Нужно пригласить другой аккаунт для отчета

getcontact.com (r) — выдает информацию о том как записан номер в контактах

truecaller.com (r) — телефонная книга, ищет имя и оператора телефона

avinfo.guru (r) — проверка телефона владельца авто, иногда нужен VPN

spravnik.com — поиск по городскому номеру телефона, найдет ФИО и адрес

m.ok.ru — показывает часть номера телефона, email, фамилии и полностью город с датой регистрации, используй во вкладке инкогнито

smartsearchbot.com — бот находит ФИО, email, объявления, бесплатный поиск не доступен для новых пользователей

list-org.com — найдет организацию в РФ

odyssey-search.info (r) — сыщит ФИО, объявления Avito, автомобили, документы, места работы, контакты, а при регистрации можно указать любую российскую организацию

find-org.com — найдет компанию в РФ

 

Пробив по ID/Юзеру телеги

Telegago — найдет упоминание аккаунта в каналах, группах, включая приватные, а так же в Telegraph статьях

lyzem.com — найдет упоминание аккаунта в группах и каналах

cipher387.github.io — покажет архивированную страницу, даст 20+ прямых ссылок на сайты веб архивы, поиск по ссылке на аккаунт

tgstat.com — поиск по публичным сообщениям в каналах, найдет упоминание аккаунта

@SangMataInfo_bot — история изменения имени аккаунта

@TeleSINT_Bot — найдет группы в которых состоит пользователь

@creationdatebot — примерная дата создания аккаунта, бот принимает username, для поиска по ID можно переслать сообщение от искомого пользователя

@MySeekerBot — поисковик по иранским каналам

TelegramOnlineSpy (t) — лог онлайн активности аккаунта, скажет когда был в сети

Exgram — найдет упоминание аккаунта, это поисковая система на основе Яндекса, поиск по 17 сайтам-агрегаторам, находит в Telegraph статьях, контактах, приватных и публичных каналах с группами

Commentgram — найдет упоминание аккаунта, поиск в комментариях к постам в Telegram, работает через Google

Commentdex — найдет упоминание аккаунта, поиск в комментариях к постам в Telegram, работает через Яндекс

глазбога.рф — найдет часть номера телефона, историю изменения ссылки аккаунта

@clerkinfobot — дает номер телефона

@usersbox_bot — по нику найдет номер телефона, бесплатный доступ 14 дней после первого запуска бота

@TuriBot — выдает по ID имя пользователя аккаунта Telegram, отправь боту команду /resolve + ID

@eyeofbeholder_bot — даёт интересы аккаунта, а платно выдаст историю изменения имени, номер телефона, группы и ссылки которые публиковал пользователь

 
 Quick_OSINT_bot — найдет оператора, email, как владелец записан в контактах, базах данных и досках объявлений, аккаунты в соц. сетях и мессенджерах, в каких чатах состоит, документы, адреса и многое другое

 @clerkinfobot — бот берет данные из приложения getcontact, показывает как записан номер телефона в контактах

 @dosie_Bot — как и в боте uabaza дает информацио о паспорте только польностью, 3 бесплатные попытки

 @find_caller_bot — найдет ФИО владельца номера телефона

 @get_caller_bot — поиск по утечкам персональных данных и записным книгам абонентов, может найти ФИО, дату рождения, e-mail

└ @usersbox_bot — бот найдет аккаунты в ВК у которых в поле номера телефона указан искомый номер

└ @EyeGodsBot Платный. Поиск по ФИО, фото, по номеру авто, ВК, ОК, по телефону, по мылу, по телеге, по адресу и прочая прочая. Не реклама, делюсь тем чем пользуюсь сам.

└ @info_baza_bot
 

Поиск через URLh

ttps://my-medon.aviasales.ru/list?key=tg:123456789 — найдет подписки на авиабилеты, замените 123456789 на ID аккаунтаh

ttps://etlgr.me/conversations/123456789/subscription — найдет сохраненное имя аккаунта и статус подписки на @etlgr_bot, можно подставить к ID @etlgr.com и получить Email адрес, замени 123456789 на ID аккаунта

https://intelx.io/?s=https/t.me/USERNAME — найдет упоминание на сайтах и в слитых базах, замените USERNAME на имя пользователя


Поиск по почте:

1. haveibeenpwned.com — проверка почты в слитых базах

2. emailrep.io — найдет на каких сайтах был зарегистрирован аккаунт использующий определенную почту

3. dehashed.com (r) — проверка почты в слитых базах

4. intelx.io — многофункциональный поисковик, поиск осуществляется еще и по даркнету

5. @info_baza_bot — покажет из какой базы слита почта, 2 бесплатных скана

6. leakedsource.ru — покажет в каких базах слита почта

7. mostwantedhf.info — найдет аккаунт skype

8. email2phonenumber (t) — автоматически собирает данные со страниц восстановления аккаунта, и находит номер телефона

9. spiderfoot.net (r) — автоматический поиск с использованием огромного количества методов, можно использовать в облаке если пройти регистрацию

10. @last4mailbot — бот найдет последние 4 цифры номера телефона клиента Сбербанка

11. searchmy.bio — найдет учетную запись Instagram с электронной почтой в описании

12. AVinfoBot (r) — найдет аккаунт в ВК

13. account.lampyre.io (t, r) — программа выполняет поиск по аккаунтам в соц. сетях и мессенджерам и другим источникам

14. ГлазБога.com (r) — найдет фото из аккаунтов пользователя 

15. @StealDetectorBOT — поисковик по базам утечек, найдет частть пароля и источник утечек

16. cyberbackgroundchecks.com — найдет все данные гражданина США, вход на сайт разрешен только с IP адреса США

17. holehe (t) — инструмент проверяет аккаунты каких сайтов зарегистрированы на искомый email адрес, поиск по 30 источникам

18. tools.epieos.com — найдет Google ID, даст ссылки на профиль в Google карты, альбомы и календарь, найдет к каким сайтам привязана почта, профиль LinkedIn

19. @UniversalSearchBot — найдет профили на Яндекс, в сервисах Google, утекшие пароли, социальные сети, адрес регистрации, номер телефона, био, Gmail адрес и прочее

20. grep.app — поиск в репозиториях GitHub

21. @PasswordSearchBot — выдает пароли

22. Checker

@PhoneLeaks_bot - найдет в каких базах слит номер

@infobazaa_bot - найдет в слитых базах фио, адрес.



Некоторые полезные инструменты доксинга

www.whois.net

www.pipl.com

www.tineye.com

www.geobytes.com/iplocator.html

www.whitepages.com

www.118.com

www.knowem.com

http://www.spokeo.com/username-search

http://www.zabasearch.com/advanced.php

http://www.ip-address.org/lookup/ip-locator.php

skypegrab.net

http://www.proxyornot.com

https://ssndob.so

whoisology.com

indexeus.com

netcraft.com

shodan.com

intelx.io

http://www.checkusernames.com/

www.myspace.com

www.bebo.com

facebook.com/

instagram.com/

allinurl: //google.com/

www.wink.com

www.123people.com

www.zabasearch.com

http://ip-score.com/checkip

http://iknowwhatyoudownload.com/ru/peer/

http://htmlweb.ru

http://getipintel.net

🌎Поиск пастебина 🌎

🍎Политики🍎

🔘 Инструменты анализа URL 🔘

https://www.virustotal.com/gui/

https://www.urlvoid.com/

https://urlscan.io/

https://exchange.xforce.ibmcloud.com/

https://zulu.zscaler.com/

https://umbrella.cisco.com/

https://www.hybrid-analysis.com/

🔘 Инструменты анализа IP: 🔘

https://exchange.xforce.ibmcloud.com/

https://www.ipvoid.com/

https://umbrella.cisco.com/

🔘 Дополнительную информацию об IP и URL (дата создания, местоположение, организация) можно найти на 🔘

http://cqcounter.com/whois/

http://domainwhitepages.com/

http://whois.domaintools.com/

Доксинг:

1: Имя пользователя (псевдоним)

http://namechk.com/

http://knowem.com/

http://www.namecheckr.com/

http://checkusernames.com/

http://usersherlock.com/

https://www.usersearch.org/

⚡️ DOX ANY GMAIL [ИМЯ, ЖИВОЕ МЕСТОПОЛОЖЕНИЕ, ФОТОГРАФИИ, УСТРОЙСТВА, КАЛЕНДАРЬ] (ИСТОЧНИК) ⚡️

Хочу начать с того, что этот инструмент был сделан не мной.

Этот инструмент позволяет получить следующую информацию об учетной записи Gmail:

Имя владельца

Последний раз профиль редактировался

Google ID

Если это аккаунт Hangouts Bot

Активированные сервисы Google (YouTube, Фото, Карты, News360, Hangouts и т. Д.)

Возможный канал на YouTube

Возможные другие имена пользователей

Общедоступные фотографии

Модели телефонов

Прошивки телефонов

Установленное ПО

Обзоры Google Maps

Возможное физическое местонахождение

События из Google Календаря

https://github.com/mxrch/GHunt

Скачать:

https://sql.gg/upload/e4b6aa3c-d20c-493d-ad77-3d6d51381ee6

Социальная информация

1. haveibeenpwned.com - проверка просочившихся баз данных

2. emailrep.io - найти сайты, на которых был зарегистрирован аккаунт по электронной почте

3. dehashed.com - проверка почты в просочившихся базах данных

4. @Smart_SearchBot - найдите полное имя, DoB, адрес и номер телефона

5. pwndb2am4tzkvold.onion - поиск в pwndb, также поиск по паролю

6. intelx.io - многофункциональная поисковая система, поиск ведется также и в даркнете

7. @mailsearchbot - поиск по базе, выдает пароль частично

8. @shi_ver_bot - взломанные пароли

9. @info_baza_bot - показать с какой базы просочилась почта, 2 бесплатных сканирования

10. leakedsource.ru - покажите, из какой базы просочилась почта

11. mostwantedhf.info - найти аккаунт в скайпе

12. email2phonenumber (t) - автоматически собирает данные со страниц восстановления аккаунта и находит номер телефона.

13. spiderfoot.net (r) - автоматический поиск с использованием огромного количества методов, инструмент доступен в облаке с регистрацией

14. reversegenie.com - поиск местоположения, первой буквы имени и телефонных номеров

15. searchmy.bio - найти инстаграм-аккаунт с адресом электронной почты в описании

17. leakprobe.net - найдет ник и источник утечки базы данных.

18.) Получите информацию fb по электронной почте

Создать страницу в фейсбуке

Перейти на страницу диспетчера ролей

(https: //www.facebook.com/ (your-page-id) / settings /? tab = admin_roles или, например,

Введите адрес электронной почты человека, которого вы пытаетесь доказать

Имя и фамилия целей будут показаны под полем, затем просто найдите их на facebook и продолжайте свое путешествие в доксинг.

Архивы

https://archive.org/index.php

https://www.archive-it.org/

http://aad.archives.gov/aad/series-list.jsp?cat=GS29

Социальные сети

http://www.yasni.com/

http://socialmention.com/

http://www.whostalkin.com/

http://www.linkedin.com/

http://www.formspring.me/

http://foursquare.com/

https://about.me/

https://profiles.google.com/

http://blogger.com

https://twitter.com/

http://www.facebook.com/

https://deviantart.com

http://xanga.com/

http://tumblr.com/

http://myspace.com/

http://www.photobucket.com/

http://www.quora.com/

http://www.stumbleupon.com/

http://www.reddit.com

http://www.digg.com

http://www.plixi.com

http://pulse.yahoo.com/

http://www.flickr.com/

Номера телефонов

http://www.freecellphonedirectorylookup.com

http://www.numberway.com/

http://www.fonefinder.net

http://www.whitepages.com/reverse-lookup

http://www.anywho.com/reverse-lookup

http://www.yellowpages.com/reversephonelookup

http://www.spydialer.com/

http://www.intelius.com/reverse-phone-lookup.html

truecallerapp.com

IP-адреса

http://www.infosniper.net/

http://ip-lookup.net/

https://www.whatismyip.com/ip-whois-lookup/

http://whatstheirip.com

http://getthierip.com

Skype Resolvers

http://skypegrab.net/resolver.php

http://www.skresolver.com/index.php

http://resolvethem.com/

https://www.hanzresolver.com/skype2

https://skype-resolver.org/

http://mostwantedhf.info/

http://orcahub.com/skyperesolver.php

https://booter.xyz/skype-resolver/

http://cstress.net/skype-resolver/

http://iskyperesolve.com/

https://ddosclub.com/skype-resolver/index.php

Поиск по базе данных

http://skidbase.io/

haveibeenpwned.com

Leakedsource.com

WHOIS / Веб-сайт

https://www.whois.net/

http://whois.icann.org/en

https://who.is/

http://www.whois.com/whois

http://www.whois.com/

http://www.statsinfinity.com/

Изображения

http://www.tineye.com/

http://saucenao.com/

http://www.photobucket.com/

https://images.google.com/?gws_rd=ssl

IP2Skype

http://skypegrab.net/ip2skype.php

https://resolvethem.com/ip2skype.php

http://www.skresolver.com/ip-to-skype.php

http://mostwantedhf.info/ip2skype.php

https://www.hanzresolver.com/ip2skype

http://skype2ip.ninja/ip2skype.php

https://pkresolver.nl/ip2skype.php

http://www.chromeresolver.info/IP2Skype.php

 Email2Skype

http://mostwantedhf.info/email.php

http://www.skresolver.com/email-to-skype.php

https://www.hanzresolver.com/emaillookup

https://resolvethem.com/email.php

http://freetool.tk/email2skype.php

http://skypegrab.net/email2skype.php

Skype2Lan

http://www.skresolver.com/skype-to-lan.php

Skype2Email

http://skypegrab.net/skype2email.php

https://pkresolver.nl/skype2email.php

Поиск адреса MAC

http://www.coffer.com/mac_find/

http://www.whatsmyip.org/mac-address-lookup/

http://www.macvendorlookup.com/

http://macaddresslookup.org/

http://aruljohn.com/mac.pl

Lat / Long

http://www.latlong.net/

http://itouchmap.com/latlong.html

http://stevemorse.org/jcal/latlon.php

EXIF данные

http://exif-viewer.com/

http://metapicz.com/#landing

http://www.verexif.com/en/

http://www.findexif.com/

http://www.prodraw.net/online-tool/exif-viewer.php

http://exifdata.com/

 Регистраторы IP и скреппер

https://grabify.com

https://iplogger.com

http://blasze.com/

# не # пиять # содержание # Кали

Другое

http://www.abika.com/

http://www.freeality.com/

http://radaris.com/

http://twoogel.com/

http://www.advancedbackgroundchecks.com

http://www.spokeo.com/

http://www.peekyou.com/

http://yoname.com/

https://www.linkedin.com/

http://www.yellowpagesgoesgreen.org/

http://aad.archives.gov/aad/series-list.jsp?cat=GS29

http://www.numberway.com/uk/

https://www.vinelink.com/vinelink/initMap.do

http://www.jailbase.com/en/sources/fl-lcso/

http://publicrecords.onlinesearches.com/

https://www.Intelius.com/

http://www.zoominfo.com/s/#search

http://skipease.com/

https://www.advancedbackgroundchecks.com

http://www.PublicRecordsNow.com

🌎Другие новинки 2021 года🌎

Общий поиск:

Google

Ага. Однако убедитесь, что вы знаете своих операторов, чтобы извлечь из этого максимум пользы.

Bing

Хорошо, над Bing много высмеивают, поскольку он «также работает» рядом с Google, но у него есть несколько замечательных функций. Здесь работают многие операторы из Google, но я действительно понимаю, что только у Bing есть IP: для поиска других веб-сайтов на том же IP (развлечение с перекрестными ссылками на общем хосте).

Информация о сети, домене и маршрутизации

Большая часть этой страницы посвящена поиску информации о людях из социальных сетей, а не из сетевых. Однако иногда знание того, кто владеет сетью / доменом / IP-адресом, является отличным местом, поэтому начните, и люди оставляют в своих записях Whois вещи, которые могут выявить много полезных потенциальных клиентов. Сайтов, предлагающих такие услуги, очень много, но я остановлюсь только на своих любимых.

РобТекс

Хотя интерфейс, на мой взгляд, немного странный, это отличный сайт для выполнения обратного DNS-поиска по IP-адресам, захвата контактов Whois и поиска другой общей информации об IP или доменном имени.

ServerSniff

Этот какой-то странный мяч. Многие сайты предлагают информацию Whois, этот посвящен более экзотическим инструментам. Вам действительно нужно просто поиграть с ним, чтобы найти все его функции. Иногда бывает сложно вспомнить, какой вариант есть где. Вот лишь некоторые из инструментов: трассировки ICMP и TCP, информация SSL, отчеты DNS и имена хостов на общем IP. Если вы не хотите использовать прокси-сервер и не хотите, чтобы ваш IP-адрес отображался в журналах цели, было бы хорошо, если бы они провели некоторую разведку.

Ищу анкеты на человека

OSINT BOOKMARKLETS v0.2

Классная страница от Will Genovese, где вы можете автоматически искать информацию о телефоне, IP, хосте, электронной почте, серийном номере, имени и адресе.

Отличный сайт для поиска адресов и обозначения семейных отношений.

Семейное древо сейчас

Отличный сайт для поиска адресов и обозначения семейных отношений.

Корни лося

Отличный сайт, особенно для этих подсайтов

которые отлично подходят для определения семейных отношений при возникновении вопросов по сбросу пароля.

Расширенная проверка фона

Для поиска адресов и родственников это бомба. До сих пор это не подводило меня в поиске почтовых адресов, если у меня есть смутное представление о том, где кто-то живет.

Подглядывать за тобой

Интерфейс чистый, и хотя он ведет на платные сайты, он, по крайней мере, сначала дает вам реальную информацию. Кажется, я припоминаю, что раньше было лучше.

Луллар

Найдите человека, используя электронную почту | имя | имя пользователя. Возвращается не так много результатов, как на других сайтах, но то, что он дает, приятно чистое, без каких-либо проблем со всеми платными сайтами.

Проверить имена пользователей

Хорошо, должен сказать, что мне нравится этот сайт. Возможно, он не задумывался как сайт для профилирования, но он хорошо справляется с этой задачей. Мы все говорим о том, что повторное использование паролей является проблемой, но для профилирования кого-то повторное использование имени пользователя - вот где это. Этот сайт позволяет выполнять поиск по 160 сайтам социальных сетей, чтобы узнать, не используется ли псевдоним. Оттуда вы можете вручную увидеть, что находится в профиле людей на этих сайтах. Экономит время, стихи проверяя наличие учетной записи на каждом сайте самостоятельно, но вам еще предстоит много работы после этого.

KnowEm

Подобно проверке имен пользователей выше, но утверждает, что проверяет более 500 сайтов, чтобы узнать, занято ли данное имя пользователя.

я ищу

Раньше это был Спок («Единая точка контакта (по) ключевому слову»). Не уверен, когда это изменилось, я предполагаю, что это после того, как Intelius купил их. Вы можете искать по Имя | Телефон | Emai | Имя экрана. Думаю, неплохо для поиска родственников. Как только вы найдете имя по имени пользователя, вам следует сделать шаг назад и также поискать его, так как результаты сильно различаются. Кажется, в основном это побуждает людей платить деньги Intelius.

Пипл

Вы можете выполнить поиск по имени | электронной почте | имени пользователя | телефону и найти похожие результаты. Результаты могут быть очень шумными, со ссылками на кучу платных сайтов (Spokeo, Intellus и т. Д.), Но если вы готовы разбираться в чуши, это довольно приятно. Мне нравится то, что он показывает из публичных записей, профилей Amazon и социальных сетей.

123 человек

Как и все вышеперечисленное. Ссылки на множество других ресурсов, некоторые платные, а некоторые нет.

Spokeo

Хорошо, у Spokeo есть несколько хороших функций макета, но это информационная дразня. Он часто сообщает «эй, я кое-что нашел», но за результаты нужно платить. Как и преступление, я не плачу. Тем не менее, это может быть хорошей отправной точкой, которая приведет вас в другое место. Например, если вы знаете, что у кого-то есть профиль в Facebook, вы можете просто перейти на Facebook.

WebMii

Позволяет искать людей по имени или ключевому слову (попробуйте имя пользователя в качестве ключевого слова).

Информация о масштабировании

Кажется, неплохо найти, где кто-то работает. Интересно, сколько информации только из LinkedIn, а сколько из других источников? Если смотреть на них бок о бок, Zoom Info, кажется, дополняет детали другими источниками.

Географическое расположение

Карта Android

Если у вас есть MAC-адрес маршрутизатора (такое случается), у Сэми есть инструмент, который пытается определить его местоположение на основе того, что знает Google. Похоже, что Google использует телефон Android для распределенного wardrive, чтобы дополнить свои данные об автомобилях для просмотра улиц.

Приложения Bing Map

Приложения для карт - это неплохое дополнение, но вам понадобится SilverLight, и они не кажутся стабильными, если вы не используете Internet Explorer (см. Рисунок). Взгляните на приложение карты Twitter.

Карта Twitter

Также приятно видеть, откуда люди пишут твиты, но не так красиво и полно, как приложение Bing.

Мне повезло использовать это, чтобы найти адреса и соседей.

Google картинки

Я полагаю, что большинство людей знают об изображениях Google, но знаете ли вы, кто может загружать изображения (или перетаскивать их), чтобы получить аналогичные результаты? Подходит для поиска профилей под разными именами. Tin Eye похожа, но, похоже, не так много.

Оловянный глаз

Вы когда-нибудь находили чью-то фотографию и задавались вопросом, существует ли она где-нибудь еще? Tin Eye - это плагин для браузера, который позволяет выбрать картинку и найти похожие в Интернете, даже те, которые были серьезно проданы. К сожалению, база данных кажется маленькой. Я надеюсь зайти в профиль социальной сети, щелкнуть правой кнопкой мыши изображение, имя пользователя которого я знаю только, а затем найти другие профили с настоящим именем и более подробной информацией. До сих пор это было в основном полезно для выяснения, «кто этот актер / модель», но, возможно, в будущем это будет лучше.

Открытая книга

Должен любить людей, которые оставляют комментарии в Facebook открытыми для всего мира. Даже если один человек осведомлен о конфиденциальности, его друг может не быть и не может комментировать его.

Открыть поиск по статусу

Open Book, кажется, больше не существует, и Open Status Search кажется следующим лучшим вариантом.

Пик Туман

Может найти что-то хорошее, может найти то, что ранит вас на всю жизнь.

Белые страницы Найдите соседей

Может быть полезно, если вам нужно обратиться к кому-нибудь поблизости.

Ясни

Мне очень повезло, если я использовал это для сбора информации о людях.

Archive.org Wayback Machine

Иногда кто-то бросает свои документы, но удаляет их. Wayback Machine может помочь вам найти удаленную информацию.

Читатель Доски

Может быть, человек публикует сообщения на каких-то форумах с заданным именем пользователя? Может привести к полезной информации.

OMGili

Другой поиск по доске, как указано выше.

Инструменты

Хорошо, это не веб-сайты, а чертовски полезные инструменты, которые черпают из веб-ресурсов.

Мальтего

Отличный инструмент, и мне нравится, как он рисует связи между сущностями, такими как имя, домен, адреса электронной почты и т. Д., Что хорошо для построения карты разума того, как все взаимосвязано. Я по-прежнему предпочитаю делать что-то вручную, чтобы устранять ложные срабатывания и интерпретировать данные. Вам, вероятно, придется зарегистрироваться для получения ключей API, чтобы получить от него максимальную пользу.

NetGlub

Когда-нибудь это может стать заменой Maltego с открытым исходным кодом, но сейчас кажется почти невозможным приступить к работе.

Foca

Я действительно копаюсь в этих инструментах. Он может выполнять поиск распространенных форматов документов с помощью Google и других поисковых систем, а затем загружать их для извлечения метаданных. Прекрасный.

https://www.elevenpaths.com/labstools/foca/index.htmlCree.py

Отличный инструмент для геолокации / отслеживания пользователей Twitter / Foursquare. Не только извлекает координаты напрямую из сообщений, но также может извлекать их из данных EXIF в изображениях, на которые они ссылаются.

http://intelx.io/

http://haveibeenpwned.com/

http://ekata.com/

http://dehashed.com/

http://whitepages.com

http://thatsthem.com

http://emailrep.io/

https://github.com/khast3x/h8mail

https://github.com/Cat-Linux/BeaverRecon

▬ι═ I ═S═ P══TOOLS═════ι▬▬

AT&T - http://www.att.com/

Служба поддержки U-verse: 1-800-288-2020

Идентификаторы сотрудников - md905c

• Системы: G2, CCTP, SystemX, Clarify, Telegence, MyCSP, Phoenix,

Torch, CSR Admin, CTI, система проверки агентов, CCC Tool, DLC, C-Care

Небо - http://www.sky.com/

Служба поддержки Sky: 0-844-241-1653

• Системы: Облако

Кокс - http://ww2.cox.com/residential/home.cox

Поддержка Cox: 877-891-2899 • Системы: Polaris (IP), iNav, edgehealth, Icon, IDM, ICOMS, SL2

Устав - https://www.charter.com/

Чартерная поддержка: 713-554-3669

• Системы: Sigma (запросите это для поиска), IRIS

Comcast - http://www.comcast.com/

Служба поддержки Comcast: 1-800-934-6489

• Системы: ACSR, Comtrac, CSG, Einstein, Grand-slam (Спросите об этом для

поиски), видение

Тайм Уорнер - http://www.timewarnercable.com/

Служба поддержки Time Warner - 212-364-8300

• Системы: Real, Unify (Спросите об этом для поиска)

Дорожный бегун - http://www.rr.com/

Служба поддержки Road Runner: 1-866-744-1678

• Системы: Real, Unify

Verizon - http://www.verizonwireless.com/

Служба поддержки Verizon: 1-800-837-4966

▬▬ι═══════ ﺤ -═══════ι▬▬

Предметы, которые можно найти:

Имя в файле:

Дата рождения:

SSN в файле:

Телефон в досье:

Адрес в файле:

Номер учетной записи интернет-провайдера:

Адрес электронной почты основного аккаунта

REGARDS = @ its_me_kali

INSTAGRAM OSINT

Osintgram - это инструмент OSINT в Instagram. Osintgram - это ответвление https://github.com/LevPasha/Instagram-API-pythonи https://github.com/woj-ciech/OSINT/tree/master/insta.

Я не беру на себя ответственность за использование этого инструмента.

Osintgram предлагает интерактивную оболочку для анализа учетной записи Instagram любого пользователя по его нику. Ты можешь получить:

- информация Получить информацию о цели - адресаты Получить все зарегистрированные, адресованные целевыми фотографиями - подписчики Получить целевых подписчиков - подписаться Получить пользователей, за которыми следует цель - хэштеги Получить хэштеги, используемые целью - лайки Получить общее количество лайков публикациям цели - комментарии Получить общее количество комментариев к сообщениям цели - tagged Получить список пользователей, помеченных целью - photodes Получить описание фотографий

цели - фотографии Загрузить фотографии пользователя в папку вывода - подписи Получить подписи к фотографиям пользователя - mediatype Получить тип сообщений пользователя (фото или видео) - propic Загрузить изображение профиля пользователя - истории Загрузить пользователя истории

Установка

Fork / Clone / Загрузите этот клон репогита https://github.com/Datalux/Osintgram.git

Перейдите в каталог cd Osintgram

Запустите pip3 install -r requirements.txt

Создайте подкаталог configmkdir config

Создайте в config папку файл: username.conf и напишите свой логин в Instagram.

Создайте в config папку файл: pw.conf и напишите пароль своего аккаунта в Instagram.

Запустите сценарий main.py python3 main.py <целевое имя пользователя>

Обновление

Запустите git pull в каталоге Osintgram

🍊🍊Другой инструмент🍊🍊

Установка

git clone https://github.com/sc1341/InstagramOSINT.git

cd InstagramOSINT

pip3 install -r requirements.txt

Использовать

python3 main.py –username ИМЯ ПОЛЬЗОВАТЕЛЯ

Instagram OSINT

Обратите внимание, что InstagramOSINT.py предназначен для импорта в качестве модуля python, он предназначен для использования в пользовательских приложениях, а не для запуска из командной строки.

Использование API InstagramOSINT.py

Это полезно при попытке применить эту кодовую базу к любым проектам. API действительно прост в использовании и использует функции Python, чтобы упростить его использование, например индексацию.

Примеры:

из InstagramOSINT import * instagram = InstagramOSINT (username = ’USERNAMEHERE’) print (instagram.profile_data) print (instagram [‘Username’]) instagram.print_profile_data () instagram.save_data () instagram.scrape_posts ()

FB OSINT 

OSINT для аккаунта Facebook

1. graph.tips - позволяет посмотреть, как публикации ставят лайки пользователя

2. whopostedwhat.com - поиск сообщений в Facebook.

3. fb-the sleep-the stats (t) - отслеживает онлайн / офлайн статус людей, вы можете получить точную информацию о времени их сна.

4. lookup-id.com - будет ID аккаунта

5. keyhole.co (r) - анализ аккаунта, без проверки почты и телефона при регистрации, вводите любые данные, 7 дней бесплатно

6. archive.org - показать заархивированную версию аккаунта

7. @ usersbox_bot - бот найдет аккаунты ВКонтакте с желаемым логином в поле facebook @GetPhone_bot - найдет номер телефона в своей базе данных. Поиск по URL 1. https://www.facebook.com/browse/fanned_pages/?id=USERID - найдет лайки пользователя, заменит на идентификатор учетной записи 2. https://facebook.com/friendship/USERID/USERID - общие друзья, общие записи будут быть отображенными и фотографии, а также любые другие связанные данные, такие как родные города, школы и т. д., заменить на идентификатор учетной записи 3.facebook: <Login>

ID ПОЛЬЗОВАТЕЛЯ

ID ПОЛЬЗОВАТЕЛЯ

https://facebook.com/browse/mutual_friends/?uid=USERID&node=USERID - найдет общих друзей, у которых есть общедоступные списки друзей; если у одного из искомых пользователей есть общедоступный список друзей, замените USERID идентификатором учетной записи

Поиск по URL

4. https: //my.mail.ru/fb/USERID - найдет аккаунт в Моем Мире, замените USERID в ссылке на ID аккаунта.

дополнение:
Мощный инструмент для пробива информации по номеру(мультисервисы)Ф

https://github.com/sundowndev/PhoneInfoga

Sherlock
Самый мощный известный мне инструмент по пробиву ника

https://github.com/sherlock-project/sherlock

Photon
Очень сильный кравлер(Выгрузка информации с сайтов)

https://github.com/s0md3v/Photon

Библия пентестера
Крупнейший сборник информации по пентесту, что тебе пригодится в будущем.Информация на английском, и информации настолько дохуя, что эге по английскому языку ты сдашь на нехуй делать.

https://github.com/blaCCkHatHacEEkr/PENTESTING-BIBLE

Если же тебе это нахуй не интересно, держи материал с этой библии для OSINT

4500 гугл дорков — https://sguru.org/ghdb-download-list-4500-google-dork..

OSINT Ресурсы 2019 — https://medium.com/p/b15d55187c3f

OSINT Тулкит — https://medium.com/@micallst/osint-resources-for-2019..

Визуализация информации OSINT — https://medium.com/hackernoon/osint-tool-for-visualiz..

Instagram OSINT — https://medium.com/secjuice/what-a-nice-picture-insta..

Наилучший сборник OSINT
https://github.com/jivoi/awesome-osint

СЛОЖНЕЙШИЙ ИНСТРУМЕНТ SPIDERFOOT(Lampyre Lighthouse на стероидах)
https://github.com/smicallef/spiderfoot

Для тебя это будет заданием — поставить эту хуету, и подключить все бесплатные API

Общий OSINT GitHub топик
https://github.com/topics/osint


мануал писал воид (унпакинг уберешь ты гей)
"""))            
            input("Нажмите ENTER...") 
            
        elif choice == "56":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
пр брохи, бесплатный мануал по сносу телеграм каналов совместо 


И так начнем с того что вы сможете снести телеграм канал только в нескольких случаях:
1:  Блокируются каналы, связанные с проституцией и распространениям порнографии. Такие каналы часто маскируются под более безобидными названиями, например: «Поиск Спонсора», «Содержанки», «Знакомства 18+». 


2: Ложные минирования, сливы паспортных данных, сливы номеров и так далее


3: Призывы насилию, экстремизму, фашизму и разжигание межнациональной розни.


4: В Телеграме также встречаются каналы с пиратским контентом. Эти сети чаще всего банят по жалобам правообладателей. Под санкции попадают распространители фильмов, музыки, компьютерного софта.


5: Канал также может быть заблокирован за накрутку пользователей. Если на новую группу подписывается большое количество участников, это может расцениваться как использование нечестных методов продвижения или специальных программ. Агрессивная накрутка приводит не только к бану, но и списанию подписчиков. Кроме того, не приветствуется указание на сторонние сайты, даже если контент интересен подписчикам канала.


ЗА ВАШЕ СКАЗАНОЕ ВАС ЗАБАНЯТ БЕЗ ВОЗРАТНО 






ПЕРЕЙДЕМ К ОСНОВОЙ ЧАСТЕ ДАННОГО МАНУАЛА. КАК СНЕСТИ КАНАЛ НАХУЙ


Существует несколько способов, я покажу самые основные:
№1


Тг канал можно забанить по письму на почту телеграма: 
желательно перед началом сноса создайте рандомную почту на какое-то имя и фамилию, например alexdevis@gmail.com


После этого можете приступать к написанию письма, здесь предложу текст человека который снёс GostTypes 


почты на который отправляете письмо: 
DMCA@telegram.org
ceo@telegram.org
abuse@telegram.org
support@telegram.org




Тема сообщения: Канал нарушает правила Telegram 


Текст сообщения: 


Здравствуйте! Я Шарапов Григорий Анатольевич хочу пожаловаться на Telegram-канал@ghostypes в котором были опубликованы мои персональные, паспортные данные без моего согласия на их обработку и дальнейшее распростронение! Так-же в канале оскорбляются не выдуманные персонажи и при этом канал в открытом доступе!! Прошу заблокировать данный канал, благодарю за внимание и надеюсь на вашу помощь


Посты с нарушениями


Мои паспортные данные опубликованные без согласия на их обработку и распростронение: 'сюда вставляем ссылку на сообщение'


Паспортные данные 2: 'сюда вставляем ссылку на сообщение'




Публикация мобильного номера пользователя Telegram без его согласия 2: 'сюда вставляем ссылку на сообщение'




Ложное тиНИРОВАНue: 'сюда вставляем ссылку на сообщение'


Ложное muHupoBaHue 2: 'сюда вставляем ссылку на сообщение'


Администратор канала Здесь оставляем юзер нейм владельца канала 


Если не забанили, то отправьте тот же самый текст только на английском 








Многие задаются вопросом зачем писать muНИРОАHue, а не просто минирование, да все просто если вы напишите минирование то сообщение улетит в спам, если оно улетит в спам то телеграм его просто не увидит и не забанит канал.






Способ 2
№2


Переходите по ссылке https://telegram.org/support




И пишите тот же самый текст который я дал сверху. 


Если вдруг не получился не один способ попробуйте последний 
заходите в Твиттер и пишите в ЛС на этот ник @telegram ПИШИТЕ НА АНГЛИЙСКОМ, А ТО ОНИ ПРОИГНОРИРУЮТ




Ну что бесплатный мануал подошёл к концу, поэтому всем удачи сносить бомжей"""))            
            input("Нажмите ENTER...")  
            
        elif choice == "57":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
Для начала находим сервис накрутки.

Делаем пост у себя на левой странице и Указываем любую ссылку, например ссылку на картинку.

Дальше просим жертву зарепостить ваш пост, тут уже в помощь Социальная Инженерия.

Когда он репостнул, редактируйте пост и ссылку меняйте на сайт накрутки.

Оба ака снесут.
"""))       
            input("Нажмите ENTER...")    
            
        elif choice == "58":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
Мануал по сносу Telegram аккаунта
Что бы сносить аккаунт, нужно иметь нарушения, сейчас я подробно распишу, за что можно снести акк.
Нарушение правил Telegram: 
1. Угрозы, Буллинг
2. Продажа запрещенных услуг (сваттинг, деанон)
Алгоритм действий:
1. Пишем на почту поддержке Telegram:  DMCA@telegram.org , или же - abuse@telegram.org
2. В сообщении пишем по шаблону:
Здравствуйте, данный телеграмм аккаунт:
@nickname
Продает услуги деанонизации личности и сваттинг:
скриншоты прилагаются в письме
Фото с угрозами минирования зданий:)
(скриншоты) 
Угрозы и буллинг:
(скриншоты) 
Прошу Вас заблокировать данный аккаунт, за нарушение правил."""))            
            input("Нажмите ENTER...")
            
        elif choice == "59":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
Зайдите в свой профиль и выберите пункт «Настройки». Пролистайте страницу, зайдите в раздел «Помощь». Нажмите «Ок» и «Начать». Далее «Хочу сообщить о проблеме…» и «Сообщить о нарушении». Описанный способ позволяет получить доступ к чату с волонтерами и подробным FAQ, в котором описано, как заблокировать аккаунт Телеграм другого человека. Жалобы должны быть обоснованными и содержать явные свидетельства нарушений правил мессенджера. Согласно FAQ, о спаме рекомендуется сообщать на e-mail техподдержки abuse@telegram.org. Жалобы о нарушении авторских прав принимаются модераторами по адресу dmca@telegram.org.

пишем следущий текст: 

здравствуйте уважаемая поддержка телеграмм,хочу пожаловаться на пользователя 
его айди: (айди жертвы) 
его юзер: (если есть) 
дело в том что он нарушает правила телеграмм, он продает услули деанона, занимается терроризмом , а еще хочу сообщить что он оскорбляет чужие личности.Прошу вас принять меня, спасибо !

мануал написал Евгений парадайсов
тг @policehouse"""))            
            input("Нажмите ENTER...")    
            
        elif choice == "60":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
• Способы by — Алексей Ошибкин. 
• https://vk.com/myznation 
x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x 
Чтобы ликвидировать страницу ВКонтакте нам надо: 
• полностью изучить страницу жертвы. 
x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x 
Теперь я вам опишу причины блокировки страницы ВК. 
• продажа способов накрутки лайков ВК. 
• продажа услуг DDoS атак или методов. 
• продажа услуг сноса, взлома страниц ВК, YouTube. 
• продажа услуг деанонимизаций. 
• угрозы в личных сообщениях. 
x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x 
Если на странице есть одно из выше причин, делайте следуещее. 
• Переходим по ссылке — https://goo.gl/nn6tbb. 
Пишем тех. поддержке: 
• Здравствуйте, тех поддержка ВКонтакте. Хочу пожаловаться на одну персону (ссылка). 
• Дело в том, то что он продаёт услуги DDoS атак, а так-же методы DDoS атак. 
• Ссылка на заметку с продажей DDoS методов и услуг: (ссылка на заметку). 
• А так-же скриншоты: 
После этого, жертву на 100% снесут. 
x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x 
• Переходим по ссылке — https://goo.gl/nn6tbb. 
Пишем тех. поддержке: 
• Здравствуйте, тех поддержка ВКонтакте. Хочу пожаловаться на одну персону (ссылка). 
• Дело в том, то что он продаёт услуги накрутки лайков. 
• Ссылка на заметку с продажей услуг накрутки лайков: (ссылка на заметку). 
• А так-же скриншоты: 
После этого, жертву на 75% снесут. 
x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x 
• Переходим по ссылке — https://goo.gl/nn6tbb. 
Пишем тех. поддержке: 
• Здравствуйте, тех поддержка ВКонтакте. Хочу пожаловаться на одну персону (ссылка). 
• Дело в том, то что он продаёт услуги взлома/блокировки страниц, групп ВК. 
• Ссылка на заметку с продажей услуг взлома/блокировки страниц ВК (ссылка на заметку). 
• А так-же скриншоты: 
После этого, жертву на 100% снесут. 
x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x 
• Переходим по ссылке — https://goo.gl/nn6tbb. 
Пишем тех. поддержке: 
• Здравствуйте, тех поддержка ВКонтакте. Хочу пожаловаться на одну персону (ссылка). 
• Дело в том, то что он продаёт услуги деанонимизаций, а это не законно. 
• Ссылка на заметку с продажей услуг деанонимизаций (ссылка на заметку). 
• А так-же скриншоты: 
После этого, жертву на 50% снесут. 
x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x 
• Переходим по ссылке — https://goo.gl/nn6tbb. 
Пишем тех. поддержке: 
• Здравствуйте, тех поддержка ВКонтакте. Хочу пожаловаться на одну персону (ссылка). 
• Дело в том, то что он угрожал мне в личных сообщениях, а это не законно. 
• А так-же скриншоты: 
После этого, жертву на 35% снесут. 
x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x 
Вот и все, я не даю 100% гарантии на то, что вы сможете ликвидировать страницу жертвы. 
x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x 
• Способы by — Алексей Ошибкин. 
• https://vk.com/myznation 
x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x"""))            
            input("Нажмите ENTER...")    

        elif choice == "61":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
Добрый день Агент! 
Хочу пожаловаться на человека. 


Данный пользователь (ссылка) 
Сливает данные людей из личных переписок а в правилах указано что человек должен в тайне хранить и не предоставлять другим пользователям и третьим лицам ставшие ему известные в результате общения с другими пользователя, ну как я вижу пользователь перешёл грани и нарушил правила сайта. 
Ссылка на запись о которой идёт речь:
Прошу вас принять меры и необходимость заблокировать!

Здравствуйте, Агент Поддержки. 
Хочу вас расказать про данное сообщество
(ссылка) 
Это сообщество занимается не легальными онлайн играми то есть так называемое "Казино".
Прошу проверить данное сообщество и применить меры. 
Хорошего дня.

Здраствуйте Агент! 
Хотел пожаловаться вам на одно сообщество! 

Данное сообщество (ссылка) 
Создала группу для объединения троллей сайта ВКонтакте для унижение и оскорбление личностей людей а это может привести что маленьких детей начнут оскорблять и это может привести к плачевным действиям прошу вам принять меры и заблокировать группу. 
Ссылка на запись о которой идёт речь:

Добрый день Агент! 


Данное сообщество (ссылка) 
Продает дд сервера и спам бота
а это уже запрещено делать на сайте ВКонтакте читаем пункт 5.3.7. Пользователю запрещено использовать программные обеспечения и осуществлять действия направленные на нарушение нормального функционирования Сайта и его серверов или персональных страниц пользователей. 
Прошу вас заблокировать группа за продажу таких ботов и серверов для них! 
Ссылка на запись о которой идёт речь:

Добрый день Агент! 


Данное сообщество (ссылка) 
Продает дд сервера и спам бота
а это уже запрещено делать на сайте ВКонтакте читаем пункт 5.3.7. Пользователю запрещено использовать программные обеспечения и осуществлять действия направленные на нарушение нормального функционирования Сайта и его серверов или персональных страниц пользователей. 
Прошу вас заблокировать группа за продажу таких ботов и серверов для них! 
Ссылка на запись о которой идёт речь:

Здраствуйте уважаемый Агент Поддержки! 

Данная группа занимается продажей всяких услуг а по правилам социальной сети ВКонтакте запрещено 5.3.13 ну за исключением случаев, когда такие действия были прямо разрешены у соответствии условиями отдельного разрешение Администрацией. 

Ссылка на запись о которой идёт речь:
Прошу проверить и принять меры.

А5.3.9. использовать без специального на то разрешения Администрации Сайта автоматизированные скрипты (программы) для сбора информации на Сайте и(или) взаимодействия с Сайтом и его сервисами

Здравствуйте уважаемая тех поддержка сайта ВКонтакте!
Можете проверить ip пользователей и их активность. На странице есть подозрение, что страницы зарегистрированы на виртуальные номера, которые продаются за 15 рублей, а пунктом 5.2 сказано, что нужно регистрироваться на свой личный номер, который привязан к паспорту, а это уже нарушение правил социальной сети ВКонтакте пожалуйста примите меры.
Ссылки на страницы:
(ссылка)
(ссылка)
(ссылка)
Данные страницы постоянно в онлайн, если проверить их ip я более уверен, что созданы они для спама и флуда.

Здравствуйте Агент технической безопасности ВКонтакте! 
Можете проверить айпи пользователей. 
Есть подозрение что профили зарегистрированные на виртуальные номера которые стоят на сим онлайне 10 рублей 
В правилах сказано что пользователь в праве иметь одну персональную страницу это указано в пункте 5.2. Это нарушение правил сайта использовать страницы не на свой номер и не на личный номер который привязан к паспорту. 
Ссылки на странице о которых идёт речь:
Прошу вас проверить айпи этих профилей и принять меры и заблокировать.

Добрый день Агент! 
Можете пожалуйста проверить айпи этого человека (ссылка) 
Есть подозрение что пользователь создал дополнительные профили а правилах этого нельзя делать в пункте 5.2 сказано что человек должен иметь одну персональную страницу. 
Ссылки на страницы человека:
Прошу принять меры при необходимости """))            
            input("Нажмите ENTER...")            
                                    
        elif choice == "62":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Телеграмм канал @ummyprogs
Для сноса страницы вк нам потребуется подать жалобу, заходим сюда https://vk.com/support?act=new&from=h&id=8842 
Если у жертвы в товарах есть способ накрутки вк, пишем: "Здраствуйте, данный человек, продаёт способы накрутки вк, прошу принять меры."
Если нет, то просто пишем в лс почему ты меня кинул, далее делаем скрин кидаем жертву в чс, и скрин где вы писали что данный человек вас кинул отправляем в тех.поддержку и ждем бан страницы. Телеграмм канал @ummyprogs
"""))            
            input("Нажмите ENTER...")
            
        elif choice == "63":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
получаем логи с телеграмма

Вам нужны следующие данные жертвы 

1. Номер ( на который привязан аккаунт )
2. Юз 
3. Айди аккаунта
-----------------------------------------
пишите что вы из фсб и этот человек преступник вам нужна информация о нем для дальнейших действий 
почты куда можно написать:

ceo@telegram.org

DMCA@telegram.org

abuse@telegram.org

sms@telegram.org

sticker@telegram.org

topCA@telegram.org

recover@telegram.org

support@telegram.org

security@telegram.org
----------------------------------------- 
после этого вам дадут файл с логом вашей жертвы где будет 100% айпи адрес жертвы и другая полезная инфа
"""))
            
        elif choice == "64":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Аккаунты можно взломать в таких соц сетях как
1. Вконтакте
2. Телеграм
----------------------------------------------
             что надо сделать?
для начала нам понадобится работа доксера который должен предоставить нам вот такую инфу
1. Паспорт
2. Фио
3. Номер
и еще могут спросить другую инфу желательно получить ваще все что есть.
Дальше смотрим какой оператор у жертвы. Пишем/звоним и говорим следующее

текст: Здравствуйте я потерял доступ к сим карте на которой был зарегестрирован аккаунт с моими личными данными и важной информацией. Прошу предоставить мне доступ к аккаунту, в данный момент я нахожусь в другом городе и звоню с телефона друга.
(дальше у вас спрашивают инфу. Вы ее даете и оператор обязан дать вам зайти на аккаунт).

вы получили аккаунт далее чтобы у вас не забрали этот аккаунт обратно, вам нужно сорвать все сессии (если сессия не срывается попробуйте еще раз или подождите 24 часа вам дадут ее сорвать)
------------------------------------------------ 
готово, вы с аккаунтом жертвы"""))            
            input("Нажмите ENTER...")  
            
        elif choice == "65":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
Тут я укажу проги которые достаточно хорошо выполняют свою работу а именно ддос.

1. *LOIC* скачать можно тут: http://sourceforge.net/projects/loic/

2. *HOIC* скачать можно тут: http://sourceforge.net/projects/highorbitioncannon/

3. *XOIC* скачать можно тут: https://appnee.com/xoic/

4. *RAVEN-STORM* скачать можно тут: https://github.com/Tmpertor/Raven-Storm
---------------------------------------------------------------------------
спомощью этого сайт теслы конечно не снесешь но какой нибудь простенький доксбин на денек положить можно."""))            
            input("Нажмите ENTER...")      
            
        elif choice == "66":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
проги для генерации вирусов 

1. BvG прекрасная прога для создания простеньких вирусов от слабых до тех которые снесут комп вашей жертве -  https://yadi.sk/d/kO06p0H9fdWah

2. Generator [~ By_doc ~] скачать можно тут  https://yadi.sk/d/XjIuCpnrgnanM
----------------------------------------------------------------------------
 этого будет вам достаточно для того чтобы пранкануть друга или наказать врага"""))            
            input("Нажмите ENTER...")   
            
        elif choice == "67":
            print(Colorate.Horizontal(Colors.green_to_white, f"""вас заклебал определенный человек?
так сделайте ему мощный рейд лички.
----------------------------------
Manual by Memfis
----------------------------------
Заходим в чатики стандофф/роблокс/бравл/блок страйк и тд и пишем такой текст
текст: этот человек бесплатно дает по (от 1 до 30) (название игровой валюты голда/робуксы и тд) каждому кто напишет ему (текст который детишки должны писать) вот его личка ( юз жертвы ) 

после этого детишки начнут люто спамить вашей жертве."""))            
            input("Нажмите ENTER...")     
            
        elif choice == "68":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
Хочу поделится схемой угона username в Телеграме. Многие о нем слышали, я и сам давно знал про это, но не придавал вниманию, пока сам не столкнулся с данной ситуацией.

Есть способ как сам Телеграм может передать вам почти любой username. Для этого нужно иметь с данным именем аккаунты в других соц сетях, достаточно будет Twitter и Instagram. Регистрируйтесь с нужным с вам username в данных соц сетях, создаете мнимую деятельность от лица какой-то компании, достаточно будет 2-3 недели публиковать посты, показать что аккаунты живые. Далее пишите в тех поддержку Телеграм сообщение, что хотите присвоить себе имя, так как ваша компания уже ведет деятельность в других соц сетях. Через некоторое время без лишних вопросов вам спокойно передают нужное вам имя.

Столкнулся сам с такой проблемой, получив от Телеграм сообщение, что мой username успешно передали другим в связи с политикой компании. За место моего имение *username* добавили *username_mv*. Хорошо, что вовремя заметил и успел везде на форумах оповестить и поменять контакты. Посмотрел аккаунты с моим именем в других соц сетях и удивился, как телеграм вообще может совершать такие действия. Там были рецепты еды, с корявым текстом и левыми фотографиями блюд, не было даже описание и аватарки на аккаунтах.

Поняв, что вернуть ничего не удасться, сменил контакты на форумах и смирился, что будут новые. Решил для предотвращения такой ситуации в дальнейшем зарегистрировать с моим username аккаунты в других соц сетях, и с удивлением обнаружил, что они уже заняты. Написал в тех поддержку Телеграма, объяснив ситуацию, буду ждать от них ответа и готовится снова менять везде контакты.

Поэтому предупреждение для всех, что бы не отдать свое имя мошенникам, которые в дальнейшем смогут от вашего лица обмануть людей на деньги и испортить вашу деловую репутацию, в спешном порядке займите вашим username другие соц сети. Явление может иметь массовый характер и отрабатывать аккаунты многих крупных продавцов, может быть, уже по вашему имени написано письмо в тех поддержку и оно ожидает трансфера третьи руки.

*СПОСОБ НЕ ЯВЛЯЕТСЯ НОВЫМ, ОН РАБОТАЕТ УЖЕ ДАВНО, НО КРАЙНЕ ШИРОКУЮ ОГЛАСКУ НАЧАЛ НАБИРАТЬ ОТНОСИТЕЛЬНО НЕДАВНО*
Agramus - я позаимствовал данный материал, я не его создатель."""))            
            input("Нажмите ENTER...")    
            
        elif choice == "69":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
1) Нужно знать виртуальный номер жертвы ОБЯЗАТЕЛЬНО 
2) нужно узнать у человека *жертвы* в
каком сервисе он приобретал этот
виртуальный номер
3) пишем поддержке данного сервиса или бота где он покупал данный виртуальный номер это *Здравствуйте, это ФСБ ведётся расследование и нам нужно у вас узнать с какого номера телефона был приобретён этот виртуальный номер *вирт номер* готово!"""))            
            input("Нажмите ENTER...")                                                                                       
        elif choice == "70":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
Для поиска по ID и юзернейму аккаунта Telegram

1. Telegago (https://cse.google.com/cse?q=+&cx=006368593537057042503:efxu7xprihg) — поиск каналов и групп, включая приватные, а так же поиск в Telegraph статьях
2. lyzem.com — поисковик аналогичный buzzim
3. @usinfobot — по ID найдёт имя и ссылку аккаунта, работает в inline режиме, введите в поле ввода сообщения @usinfobot и Telegram ID
4. cipher387.github.io (https://cipher387.github.io/quickcacheandarchivesearch/) — покажет архивированную страницу, даст 20+ прямых ссылок на сайты веб архивы, поиск по ссылке на аккаунт
5. tgstat.com (https://tgstat.com/ru/search) — поиск по публичным сообщениям в каналах
6. @SangMataInfo_bot — история изменения имени аккаунта
7. @TeleSINT_Bot — найдет группы в которых состоит пользователь
8. @creationdatebot — примерная дата создания аккаунта, бот принимает username, но не работает поиск по ID. Для поиска по ID можно переслать сообщение от пользователя
9. @MySeekerBot — поисковик по иранским каналам
10. @get_kontakt_bot — найдет номер телефона аккаунта, бот принимает username и ID
11. TelegramOnlineSpy (https://github.com/Forichok/TelegramOnlineSpy) (t) — лог онлайн активности аккаунта
12. Exgram (https://yandex.ru/search/site/?text=%22HowToFind%22&searchid=2424333) — поисковая система на основе Яндекса, поиск по 17 сайтам-агрегаторам, находит Telegraph статьи, контакты, приватные и публичным каналы с группами
13. Commentgram (https://cse.google.com/cse?cx=006368593537057042503:ig4r3rz35qi) — поиск в комментариях к постам
14. Commentdex (https://yandex.ru/search/site/?text=%22HowToFind_bot%22&searchid=2444312) — поиск в комментариях к постам
15. ⚡️@UniversalSearchBot — по ID найдёт базовые адреса почты в сервисе etlgr, статус бана пользователя ботом combot, число блокировок, заблокированные сообщения и дату начала бана
16. smartsearchbot.com — бот находит ФИО, бесплатный поиск не доступен для новых пользователей
17. @kruglyashik — канал с базой из 500K круглых видео-сообщений из русскоязычных групп, в поиске по каналу введите имя пользователя или #ID123456789 где 123456789  ID аккаунта
18. @TgAnalyst_bot — находит номер телефона, старое имя аккаунта, логин, IP и устройство, местами могут быть ложные данные, первый поиск без регистрации, если её пройти, то сливается ваш номер телефона
19. глазбога.рф — найдет часть номера телефона, историю изменения ссылки аккаунта
20. @clerkinfobot — дает номер телефона """))            
            input("Нажмите ENTER...")   
            
        elif choice == "71":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Хочешь быть довольно анонимным? - Тебе поможет наш способ.
В этом мануале, я расскажу как вам писать от имени бота и вообще иметь к нему доступ.

Для начала: заходим в BotFather [Бот в телеграме].
Создаем своего бота и копируем токен.
Дальше заходим в Play Market и скачиваем Telegraph или же BG ram.
Нажимаем "Вход по токену бота", вставляем ваш токен, готово!
Теперь вы на один шаг стали анонимней!

Автор мануала - t.me/grupareiderov"""))            
            input("Нажмите ENTER...")    
            
        elif choice == "72":
            print(Colorate.Horizontal(Colors.green_to_white, f"""***********************************************
*         _   _   _   _   _   _   _           *
*        / \ / \ / \ / \ / \ / \ / \          *
*       ( K | O | M | A | P | O | B )         *
*        \_/ \_/ \_/ \_/ \_/ \_/ \_/          *
*     Manual for Detect Protect GlazBoga      *
*    Telegram: https://t.me/komarovv_perehod  *
***********************************************

Многих бесит этап анонимности, в лице установки "защиты данных" в сервисе глаз бога, однако нашелся способ его обойти.

Как и в мануалах по вытягиванию логов, используем бота @OCMT_bot, приобретая подписку за 3$.

1. Тема письма: "Статья по которой можно осудить жертву"
2. Текст письма: "Шаблон Ниже"
3. Support
4. mvd.ru
5. gov@gb.community, antipov@gb.community, law@gb.community

Шаблон:

"Здравствуйте. На данный момент расследуются массовые дела о кибер преступности в Республике Крым.

Мы хотим узнать, данные человека который скрыл их в вашем боте , его Telegram аккаунт - @username [id]

Если вы согласны, то просим предоставить информацию на нашу гражданскую почту [email], для завершения дела.

Надеемся на сотрудничество, ожидаем ответа.

На нашу почту в течении дня должен придти текстовый файл, в котором будут результаты с глаза бога о жертве без скрытия данных."""))            
            input("Нажмите ENTER...")     
            
        elif choice == "73":
            print(Colorate.Horizontal(Colors.green_to_white, f"""===== Подготовка =====
Для начала решите с каким товаром вы будете иметь дело (для наглядного примера я буду использовать - [iPhone]), желательно чтобы вы разбирались в этом товаре и могли быстро и оперативно отвечать на все вопросы жертве. Когда товар выбран - нужно найти fullpack фото этой вещи или же сделать самому, как делаю я. Если вы не смогли найти какое-либо фото, допустим IMEI для iPhone, на помощь приходит Google и немного Photoshop (можно даже использовать веб-версию, не столько важно)
[Если брать iPhone нужно иметь - 6 фото самого аппарата (со всех сторон); IMEI; коробку с 2 сторон; чек; 2 скрина с самого телефона - Батарея и Об устройстве. Обычно на этом заканчиваются вопросы у жертвы, больше они ничего не требуют, но я дополнительно делаю фото, где iPhone лежит на листе бумаги и далее каждый день, с помощью PS, пишу на листочке сегодняшнее число, так больше доверия]
Далее стоит выбрать город, где будет проходить продажа. Многие берут Москву или же Санкт-Петербург, но я считаю так - там слишком большая конкуренция и стоит рассмотреть другие варианты, НО не берите во внимание мелкие области, пример Владимирская обл. Вы спросите - А почему? Все просто, вся область 300км, жертвы будут отказываться от сделки, так как можно доехать до любого конца области за короткий срок.
Выбор пола относительно важен, но мое мнение что девушкам доверяют больше, они мало в чем разбираются, если жертва будет тоже девушкой - можно найти темы для совместного разговора, что играет вам на пользу + иногда можно подавить на жалость :3
===== Создание аккаунта и объявления =====
Что нам потребуется - аккаунт (Avito, Youla, OLX); аккаунт WhatsApp. Есть 2 хороших сайта, которые помогу нам создать данные аккаунты - https://5sim.net/ и https://simsms.org/. Советую использовать 5SIM, но очень часто там нет номеров, поэтому приложил его аналог, но цены там выше на пару рублей. Думаю с регистрацией и прочем не возникнет проблем...
Что касается объявлений - тут нет рамок. Все зависит от вашей фантазии. НО есть ряд правил:
1) Не выставлять много фото(3-4 фото хватит с головой) и фото с информацией о товаре.
Почему? Так мы вызываем интерес у жертвы, да и нужно будет написать в ЛС для полной информации, что по сути нам и нужно.
2) Не делайте очень низкую цену.
Если средняя цена товара 25 000 рублей, то ваша цена должна быть в районе 18 000 - 22 000. Так это не выглядит наебом, да и можно списать скидку на срочную продажу или же какие-то другие проблемы.
3) Не пишите подробные описания. Хватит поверхностности.
[Не восстановлен, не ломался. Все документы. Остальное в ЛС]
===== Общение на Торговой площадке =====
Тут есть 2 стратегии общения - активная и пассивная. Что в моем понимание активное общение - полное доминирование в диалоге. Не слушать жертву, торопить, грубить, затыкать и прочее. Такое мне не по душе, поэтому я даже не буду заострять на этом внимание. Перейдем сразу в пассивному общению. Основные правила:
1) Всегда быть вежливый. 
2) Стараться войти в положение жертвы.
3) Давать как можно подробную информацию.
Преступим к одной из важных частей - перевод диалога в WhatsApp. Как же это сделать грамотно и красиво? Все просто создайте спрос. Человек попросил у вас рассказать о товаре? Не вопрос, скажите что могу отправить все фото и рассказать обо всем, но вот почему-то тут не отправляются фотографии и нужно как-то этот момент решить. Ваше решение проблемы - WhatsApp. Главное не предлагать переход в WhatsApp с ходу, можно спугнуть человека, а нам этого не нужно.
===== Общение в WhatsApp и оплата =====
И так, жертва уже у вас в WhatsApp. Что же дальше? Пользуемся всеми вашими навыками социальное-инженерии. Я обычно стараюсь войти в доверие, предлагаю какие-то бонусы за покупку, интересуюсь его доходами, предлагаю скидки и вообще интересуюсь жизнью жертвы. Когда жертва уже будет согласна на покупку, следует аккуратно намекнуть на - Авито/Юлу/Боксберри/Сдек/ПЭК/Почта РФ доставку. Пример сообщения:
Извините, я живу в 120км от города. Я могу либо приехать через 2-3 дня для личной встречи, или же можно как-то доставкой. Доверять в интернете опасно сейчас, может Avito/Youla/Боксберри/Сдек/ПЭК/Почта РФ/OLX доставкой? Тем более что сейчас коронавирус...
Если жертву не нравиться Avito/Youla/Боксберри/Сдек/ПЭК/Почта РФ/OLX  доставка, кормим его завтраками, ибо он может кинуть жалобу и будет БАН на Avito/Youla/OLX, а этого желательно не получать. Если же он дал согласие, говорим что сделаем ему скидку на доставку, и просим его подождать, делается это для отправки ему ссылки и чтобы он не оплатил на прямую на сайте. Далее заходим на Торговую площадку - меняем цену и копируем ссылку. Делаем ссылку через бота, который закреплен в главной конфе. Скидываем жертве и ждем, если что-то идет не по плану - включайте воображение :)
P.S. - Если оплата прошла успешно, придумайте причину отмены заказа:
Не пришли данные
Другой человек предложил больше
Другое
Просим жертву сделать возврат средств. Спросите как? Все очень просто. Открываем ссылку на оплату - СКАМ или оригинал не имеет значение. Доходим до этого момента.
Ссылка на возврат делается автоматически в боте, копируем ее и скидываем ее жертве. Главное будьте вежливы и извинитесь перед человеком, мол не ваша вина вы должны меня понять. Ждем когда он оплатит, если оплаты нет - блокируем.
Удачных залетов и больших выплат.



Манула @whxchanger
Манула @whxchanger
Манула @whxchanger
Манула @whxchanger"""))            
            input("Нажмите ENTER...")     
            
        elif choice == "74":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Ресурсы
├ databases.today (https://web.archive.org/web/20190409132908/https://cdn.databases.today) — слитые базы, из них  есть большие, ссылка на архивированную версию сайта
├ raidforums.com — ссылки на скачивание разных баз с 1995 года
├ Базы данных (https://t.me/basetelega) — множество бесплатных баз
├ ebaza.pro — Бесплатные базы с email,  телефонами предприятий и физ. лиц.
├ phreaker.pro — большое разнообразие баз, начиная от номеров домофонов до данных банков
├ xss.is — список баз, 3,5B записей, 52 базы
└ hub.opengovdata.ru — каталог и хранилище открытых данных России"""))            
            input("Нажмите ENTER...")    
            
        elif choice == "75":
            print(Colorate.Horizontal(Colors.green_to_white, f"""И тааакс... Сегодня у нас мануал по верификаии киви кошелька. 
Всего пару действий и у тебя вериф.кошиль. 
Для начала нам нужен номер, его можно взять вот тут https://give-sms.com/ , стоит копейки (20 деревянных) ( Нет,это не реклама)
 Как только купили номер и зарегали киви, берём данные для верифа. А откуда берём ? А вот от сюда https://www.reestr-zalogov.ru/state/index (не реклама) Открываем ссылку, переходим во вкладку "Найти в реестре", выбираем "По информации о залогодателе", физ лицо. 
Тут нам необходимо заполнить только ФИО (больше ничего не нужно) Как только придумали фио, нажимаем найти. 
Нам открывается база всех физ.лиц которые только есть в реестре. 
Листаем вниз, и открываем последнию страницу. Видишь "Номер уведомления о возникновении залога" нажимай на цифорки под этой надписью. У нас открывает окно со всеми даннымы, дата рождения,место рождения,пасс и прочая инфа. Вот от сюда мы берём всё нужные нам данные, и регаем киви для своих целей. Весь материал представленный выше, используется только для ознакомления, и не призывает к каким либо действиям. 
Автор DemonSoft, ответственность за действия читателей не несёт."""))            
            input("Нажмите ENTER...")       
            
        elif choice == "76":
            print(Colorate.Horizontal(Colors.green_to_white, f"""Как узнать ID любого человека в Telegram?⁠⁠
13 октября 2024
Для сбора данных об аккаунте Telegram нам требуется ID пользователя, но аккаунт может не иметь логина и нет возможности переслать сообщения, а ставить неофициальные клиенты совсем не хочется.

Добавляем бот в меню -https://t.me/asmico_attach_bot?startattach
сюда. Переходим в диалог c тем, чей ID вы хотите узнать, нажимаем Прикрепить и выбираем TestAttach.
В самом низу страницы нам доступен массив данных в формате JSON, в котором есть ID данного пользователя."""))            
            input("Нажмите ENTER...")                       
            
        elif choice == "77":
            print(Colorate.Horizontal(Colors.green_to_white, f"""
Как скрыть всю информацию в боте «Оракул», пишем поддержке @sluzhba_poderzhki_bota.

Здравствуйте, хотел бы спросить, как скрыть данные в боте Оракул?

Вам напишут, чтобы кинуть номер и юзернейм телеграм-аккаунта, и кидаем, через минут 5 ваши данные в боте оракул исчезнут

             manual by @WeirdToom             """))            
            input("Нажмите ENTER...")                        
            
        elif choice == "78":
            print(Colorate.Horizontal(Colors.green_to_white, f"""

Как скрыть данные в боте LeakOsint. 

Переходим в сам бот, нажимаем /start, и вам кидает: 🕵 I can search for almost anything. Just send me your request.

Внизу есть 5 кнопок, 5 меню, переходим в него, там есть тоже кнопки, нам нужно выбрать Delete yourself или удалить себя, выбираем удалить почту, так как номер удалить нам не удастся, нам кидают специальный емайл remove_me_emhb-dg@mailforspam.com, после получения своего емайла пишем в через почту, в котором зарегистрирована утечка, и отправляем любое письмо, и всё

             manual by @WeirdToom             """))            
            input("Нажмите ENTER...")    

            
        elif choice == "79":
            print(Colorate.Horizontal(Colors.green_to_white, f"""ХЗ"""))            
            input("Нажмите ENTER...")                                      